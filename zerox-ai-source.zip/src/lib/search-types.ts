import type { SearchResultEntry, SearchProgressStep } from './types'

export type SearchResult = SearchResultEntry

export interface SearchResponse {
  query: string
  results: SearchResult[]
  /** which backends contributed */
  source: 'ddg-html' | 'ddg-ia' | 'wikipedia' | 'mixed' | 'none'
  /** duckduckgo instant answer abstract, if any (great for definitions) */
  abstract?: string
  abstractUrl?: string
  /** how long the search took, in ms */
  tookMs: number
  /** which backends actually returned results */
  backendsHit: string[]
}

export type { SearchProgressStep }
