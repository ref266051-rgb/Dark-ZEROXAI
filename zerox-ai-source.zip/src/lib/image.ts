'use client'

import type { ImageSettings } from './types'
import type { ImageArtifact } from './types'

export interface GenerateImageArgs {
  prompt: string
  settings: ImageSettings
  userAgnesKey?: string
  /** ignored — image always goes browser-direct because Agnes is reachable
   * from the browser AND from the server. We keep the toggle for parity. */
  useBrowserMode?: boolean
  signal?: AbortSignal
}

export interface GenerateImageResult {
  images: ImageArtifact[]
  model: string
}

const AGNES_BASE_URL = process.env.NEXT_PUBLIC_AGNES_BASE_URL || 'https://apihub.agnes-ai.com/v1'
const AGNES_MODEL = process.env.NEXT_PUBLIC_AGNES_IMAGE_MODEL || 'agnes-image-2.1-flash'
// Public Agnes key baked into the client bundle. Used as fallback when the
// user has not entered their own key in Settings.
const PUBLIC_AGNES_KEY = process.env.NEXT_PUBLIC_AGNES_API_KEY || ''

function resolveAgnesKey(userKey?: string): string {
  if (userKey && userKey.trim().length > 0) return userKey.trim()
  return PUBLIC_AGNES_KEY
}

/**
 * Build the final prompt by combining the user's prompt with the chosen
 * style preset suffix and an optional quality booster.
 */
export function buildFinalPrompt(prompt: string, settings: ImageSettings): string {
  const styleMap: Record<ImageSettings['style'], string> = {
    none: '',
    photorealistic: ', photorealistic, ultra-detailed, 50mm, soft natural lighting, 8k',
    'digital-art': ', digital art, trending on artstation, vibrant, detailed',
    anime: ', anime style, studio ghibli inspired, soft colors, detailed line art',
    'oil-painting': ', oil painting, thick brush strokes, classical composition',
    '3d-render': ', 3d render, octane, cinema4d, soft studio lighting',
    watercolor: ', watercolor painting, soft washes, paper texture, loose brushwork',
    'pixel-art': ', pixel art, 32-bit, crisp pixels, limited palette',
  }
  const suffix = styleMap[settings.style] || ''
  const quality = settings.highQuality ? ', high quality, masterpiece, intricate detail' : ''
  return `${prompt.trim()}${suffix}${quality}`
}

/**
 * Generate an image via Agnes AI. Always goes browser→Agnes because:
 *   1. Agnes is reachable from the browser (no CORS issues — verified).
 *   2. Keeps the UX simple — no need for a separate toggle.
 * Falls back to the server-side `/api/image` proxy only when there's no key
 * in the browser bundle AND no user-provided key.
 */
export async function generateImage(
  args: GenerateImageArgs,
): Promise<GenerateImageResult> {
  const { prompt, settings, userAgnesKey, signal } = args

  const finalPrompt = buildFinalPrompt(prompt, settings)
  const key = resolveAgnesKey(userAgnesKey)

  const requestBody = {
    model: AGNES_MODEL,
    prompt: finalPrompt,
    n: 1,
    size: settings.size,
  }

  let res: Response
  if (key) {
    // Browser-direct — preferred path
    res = await fetch(`${AGNES_BASE_URL}/images/generations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify(requestBody),
      signal,
    })
  } else {
    // Fallback: server-side proxy
    res = await fetch('/api/image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: finalPrompt,
        size: settings.size,
        n: 1,
      }),
      signal,
    })
  }

  if (!res.ok) {
    let msg = `Request failed (${res.status})`
    try {
      const j = await res.json()
      if (j.error) {
        if (typeof j.error === 'string') msg = j.error
        else if (typeof j.error === 'object' && j.error !== null)
          msg = j.error.message || j.error.type || JSON.stringify(j.error)
        else msg = String(j.error)
      }
    } catch {
      /* noop */
    }
    throw new Error(msg)
  }

  const json = await res.json()
  const images: ImageArtifact[] = (json?.data || json?.images || [])
    .map((d: any) => ({
      url: d.url || (d.b64_json ? `data:image/png;base64,${d.b64_json}` : null),
      revisedPrompt: d.revisedPrompt ?? d.revised_prompt ?? null,
      size: settings.size,
    }))
    .filter((d: any) => d.url)

  if (images.length === 0) {
    throw new Error('No image was returned by Agnes.')
  }

  return { images, model: AGNES_MODEL }
}

export function hasAgnesPublicKey(): boolean {
  return PUBLIC_AGNES_KEY.length > 0
}

export const AGNES_INFO = {
  baseUrl: AGNES_BASE_URL,
  model: AGNES_MODEL,
}
