'use client'

import { useCallback, useRef, useState } from 'react'
import { toast } from 'sonner'
import { useChatStore } from '@/lib/store'
import { streamChatCompletion } from '@/lib/stream'
import { performSearch, shouldAutoSearch } from '@/lib/search'
import { THINKING_SYSTEM_PROMPT_SUFFIX } from '@/lib/thinking'
import { getChatModel, CHAT_MODELS } from '@/lib/types'
import type { SearchContext, SearchProgressStep } from '@/lib/types'

interface UseChatOptions {
  conversationId: string
}

/**
 * Build a system-prompt suffix that contains the web-search context. The AI
 * is instructed to cite sources by number.
 */
function buildSearchContextPrompt(ctx: SearchContext): string {
  const parts: string[] = []
  if (ctx.instantAnswer) {
    parts.push(`Instant answer (DuckDuckGo): ${ctx.instantAnswer}`)
  }
  if (ctx.results.length > 0) {
    parts.push(
      'Web search results (cite sources by number in your answer using [1], [2], …):',
    )
    ctx.results.forEach((r, i) => {
      parts.push(
        `[${i + 1}] ${r.title}\n    URL: ${r.url}\n    Source: ${r.source}\n    Snippet: ${r.snippet}`,
      )
    })
  }
  return parts.join('\n')
}

export function useChat({ conversationId }: UseChatOptions) {
  const [isStreaming, setIsStreaming] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  const addMessage = useChatStore((s) => s.addMessage)
  const appendToMessage = useChatStore((s) => s.appendToMessage)
  const updateMessage = useChatStore((s) => s.updateMessage)
  const deleteMessage = useChatStore((s) => s.deleteMessage)

  const runStream = useCallback(
    async (
      convId: string,
      history: { role: 'user' | 'assistant'; content: string }[],
      options?: { userText?: string; mode?: 'chat' | 'thinking' },
    ) => {
      const state = useChatStore.getState()
      let settings = state.settings
      const userApiKey = state.userApiKey
      const userOpenRouterKey = state.userOpenRouterKey
      const useBrowserMode = state.useBrowserMode
      const webSearchEnabled = state.webSearchEnabled

      // Resolve the conversation mode: 'thinking' mode forces native reasoning
      // + a reasoning-capable model, regardless of the global thinkingEnabled
      // toggle. 'chat' mode respects the toggle and selected model as before.
      const conv = state.conversations.find((c) => c.id === convId)
      const convMode = options?.mode || conv?.mode || 'chat'
      const isThinkingMode = convMode === 'thinking'

      // In thinking mode, use the dedicated thinkingModelId picker (separate
      // from the chat-mode selectedChatModelId). The thinking picker only
      // shows native reasoning models (Nemotron, LFM 2.5 Thinking).
      let model = isThinkingMode ? state.thinkingModelId : state.selectedChatModelId
      let thinkingEnabled = isThinkingMode || state.thinkingEnabled

      const thinkingStartedAt = thinkingEnabled ? Date.now() : null

      // Determine whether to use native reasoning (OpenRouter reasoning models)
      // vs the <think> tag fallback. Decided early so we can set it on the
      // assistant message before the first delta arrives.
      const selectedModelMeta = getChatModel(model)
      const useNativeReasoning = thinkingEnabled && !!selectedModelMeta.supportsNativeReasoning

      const assistantId = state.addMessage(convId, {
        role: 'assistant',
        content: '',
        streaming: true,
        // Pre-initialize thinking fields so the bubble shows up immediately
        // when thinking mode is on (even before the first delta arrives).
        ...(thinkingEnabled
          ? {
              thinking: '',
              thinkingStreaming: true,
              thinkingCharCount: 0,
              thinkingNative: useNativeReasoning,
            }
          : {}),
      })

      setIsStreaming(true)
      const controller = new AbortController()
      abortRef.current = controller

      // Optional web search — fetch results and inject them into the system prompt.
      // Triggered when:
      //   - webSearchEnabled is true (user toggled the globe on), OR
      //   - the message text looks like it needs live info (auto-detect heuristic)
      const wantsSearch =
        webSearchEnabled && options?.userText
          ? true
          : options?.userText
            ? shouldAutoSearch(options.userText)
            : false

      let searchContext: SearchContext | null = null
      if (wantsSearch && options?.userText) {
        state.updateMessage(convId, assistantId, { searching: true })
        try {
          const res = await performSearch(options.userText, {
            limit: 6,
            signal: controller.signal,
            useServerProxy: !useBrowserMode,
            onProgress: (progress: SearchProgressStep[]) => {
              state.updateMessage(convId, assistantId, {
                searchContext: {
                  query: options.userText!,
                  results: [],
                  progress,
                },
              })
            },
          })

          if (res.results.length > 0 || res.abstract) {
            searchContext = {
              query: res.query,
              results: res.results.map((r) => ({
                title: r.title,
                url: r.url,
                snippet: r.snippet,
                source: r.source,
              })),
              instantAnswer: res.abstract,
              instantAnswerUrl: res.abstractUrl,
              backendsHit: res.backendsHit,
              tookMs: res.tookMs,
            }
          } else {
            searchContext = null
          }

          state.updateMessage(convId, assistantId, {
            searching: false,
            searchContext: searchContext || undefined,
          })

          if (searchContext) {
            const searchPrompt = buildSearchContextPrompt(searchContext)
            settings = {
              ...settings,
              systemPrompt: `${settings.systemPrompt}\n\n---\nWeb search context for the user's latest question:\n${searchPrompt}\n---\nUse this context to ground your answer. Cite sources inline as [1], [2], etc. matching the order above. If the context is insufficient, say so honestly.`,
            }
          }
        } catch (err) {
          state.updateMessage(convId, assistantId, { searching: false })
          // Non-fatal: continue without search context.
          console.warn('Web search failed:', err)
        }
      }

      // Thinking mode: if the selected model supports NATIVE reasoning
      // (OpenRouter reasoning models), use that — no system-prompt hacking needed.
      // Otherwise, fall back to the <think> tag approach which works with any model.
      if (thinkingEnabled && !useNativeReasoning) {
        settings = {
          ...settings,
          systemPrompt: `${settings.systemPrompt}${THINKING_SYSTEM_PROMPT_SUFFIX}`,
        }
      }

      await streamChatCompletion({
        messages: history,
        settings,
        model,
        userApiKey,
        userOpenRouterKey,
        requestNativeReasoning: useNativeReasoning,
        useBrowserMode,
        signal: controller.signal,
        onDelta: (delta) => state.appendToMessage(convId, assistantId, delta),
        onThinkingDelta: thinkingEnabled
          ? (delta) => {
              const msg = useChatStore
                .getState()
                .conversations.find((c) => c.id === convId)
                ?.messages.find((m) => m.id === assistantId)
              const prev = msg?.thinking || ''
              const next = prev + delta
              // Compute live throughput: chars produced so far / elapsed seconds
              const elapsedMs = thinkingStartedAt ? Date.now() - thinkingStartedAt : 0
              const charsPerSec =
                elapsedMs > 100 ? Math.round((next.length / elapsedMs) * 1000) : undefined
              state.updateMessage(convId, assistantId, {
                thinking: next,
                thinkingCharCount: next.length,
                thinkingCharsPerSec: charsPerSec,
              })
            }
          : undefined,
        onThinkingEnd: thinkingEnabled
          ? () => {
              const tookMs = thinkingStartedAt ? Date.now() - thinkingStartedAt : undefined
              const msg = useChatStore
                .getState()
                .conversations.find((c) => c.id === convId)
                ?.messages.find((m) => m.id === assistantId)
              const chars = msg?.thinking?.length || 0
              const words = msg?.thinking
                ? msg.thinking.trim().split(/\s+/).filter(Boolean).length
                : 0
              const charsPerSec =
                tookMs && tookMs > 0 ? Math.round((chars / tookMs) * 1000) : undefined
              state.updateMessage(convId, assistantId, {
                thinkingStreaming: false,
                thinkingTookMs: tookMs,
                thinkingCharsPerSec: charsPerSec,
                thinkingWordCount: words,
              })
            }
          : undefined,
        onError: (err, kind, meta) => {
          // Defensive: ensure error is always a string before storing on the message.
          // Groq sometimes returns {message, type, param} objects — if any slip
          // through stream.ts's normalization, React would crash trying to render them.
          const errMsg =
            typeof err === 'string'
              ? err
              : err && typeof err === 'object'
                ? (err as { message?: string }).message ||
                  (err as { type?: string }).type ||
                  JSON.stringify(err)
                : String(err ?? 'Unknown error')

          // Build the message patch — include structured rate-limit fields when present.
          const patch: Parameters<typeof state.updateMessage>[2] = {
            streaming: false,
            thinkingStreaming: false,
            error: errMsg,
            errorKind: kind,
          }
          if (meta?.retryAfterSec !== undefined) patch.retryAfterSec = meta.retryAfterSec
          if (meta?.limitType) patch.limitType = meta.limitType
          state.updateMessage(convId, assistantId, patch)

          if (kind === 'rate_limit') {
            const limitLabel = meta?.limitType ? ` (${meta.limitType})` : ''
            const retryLabel = meta?.retryAfterSec
              ? ` Try again in ${meta.retryAfterSec}s.`
              : ' Please wait a moment and try again.'
            toast.error('Limit tercapai', {
              description: `Anda telah mencapai limit${limitLabel}.${retryLabel}`,
              duration: 9000,
            })
          } else if (kind === 'quota') {
            const limitLabel = meta?.limitType ? ` (${meta.limitType})` : ''
            toast.error('Limit tercapai', {
              description: `Anda telah mencapai limit${limitLabel}. Limit ini lebih lama (harian/bulanan) — silakan upgrade plan atau tunggu reset.`,
              duration: 12000,
            })
          } else if (kind === 'forbidden') {
            toast.error('Blocked by Cloudflare', {
              description:
                'The server IP is blocked by Groq. Open Settings → enable Browser-direct mode (and add your Groq API key if not set).',
              duration: 8000,
            })
          } else if (kind === 'auth') {
            toast.error('Invalid API key', {
              description: 'Open Settings and paste a valid Groq API key (starts with gsk_).',
              duration: 8000,
            })
          } else if (kind === 'network') {
            toast.error('Network error', { description: err, duration: 6000 })
          } else {
            toast.error('Chat error', { description: err, duration: 6000 })
          }
        },
        onFinish: (reason) => {
          if (reason === 'aborted') {
            const msg = useChatStore
              .getState()
              .conversations.find((c) => c.id === convId)
              ?.messages.find((m) => m.id === assistantId)
            if (msg && !msg.content && !(msg.thinking && msg.thinking.length > 0)) {
              state.deleteMessage(convId, assistantId)
            } else {
              state.updateMessage(convId, assistantId, {
                streaming: false,
                thinkingStreaming: false,
              })
            }
          } else {
            state.updateMessage(convId, assistantId, {
              streaming: false,
              thinkingStreaming: false,
            })
          }
        },
      })

      setIsStreaming(false)
      abortRef.current = null
    },
    [],
  )

  const send = useCallback(
    async (userText: string) => {
      const text = userText.trim()
      if (!text || isStreaming) return

      const conv = useChatStore.getState().conversations.find((c) => c.id === conversationId)
      if (!conv) return

      addMessage(conversationId, { role: 'user', content: text })

      const history = [...conv.messages, { role: 'user' as const, content: text }]
        .filter((m) => m.role !== 'system' && !m.error && m.content.trim().length > 0)
        .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }))

      await runStream(conversationId, history, {
        userText: text,
        mode: conv.mode === 'thinking' ? 'thinking' : 'chat',
      })
    },
    [conversationId, isStreaming, addMessage, runStream],
  )

  const stop = useCallback(() => {
    abortRef.current?.abort()
  }, [])

  const regenerate = useCallback(async () => {
    if (isStreaming) return
    const conv = useChatStore.getState().conversations.find((c) => c.id === conversationId)
    if (!conv) return
    const msgs = conv.messages
    let lastAssistantIdx = -1
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].role === 'assistant') {
        lastAssistantIdx = i
        break
      }
    }
    if (lastAssistantIdx === -1) return
    const lastUser = [...msgs.slice(0, lastAssistantIdx)].reverse().find((m) => m.role === 'user')
    if (!lastUser) return
    deleteMessage(conversationId, msgs[lastAssistantIdx].id)
    await send(lastUser.content)
  }, [conversationId, isStreaming, deleteMessage, send])

  const editUserMessage = useCallback(
    async (msgId: string, newContent: string) => {
      if (isStreaming) return
      const conv = useChatStore.getState().conversations.find((c) => c.id === conversationId)
      if (!conv) return
      const idx = conv.messages.findIndex((m) => m.id === msgId)
      if (idx === -1) return
      const toRemove = conv.messages.slice(idx + 1).map((m) => m.id)
      for (const id of toRemove) deleteMessage(conversationId, id)
      updateMessage(conversationId, msgId, { content: newContent })
      await send(newContent)
    },
    [conversationId, isStreaming, deleteMessage, updateMessage, send],
  )

  return { send, stop, regenerate, editUserMessage, isStreaming, runStream }
}

export type UseChatReturn = ReturnType<typeof useChat>
