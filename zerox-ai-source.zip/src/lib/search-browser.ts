'use client'

import type { SearchResultEntry } from './types'

/**
 * Browser-direct DuckDuckGo HTML scraper.
 * Runs in the user's browser — their IP is usually NOT blocked by DDG,
 * unlike the sandbox server's IP. Returns ~5-10 organic results.
 */
export async function ddgHtmlSearchBrowser(query: string, limit = 6): Promise<SearchResultEntry[]> {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}&kl=wt-wt`
  const res = await fetch(url, {
    headers: {
      Accept: 'text/html,application/xhtml+xml',
      'Accept-Language': 'en-US,en;q=0.9',
    },
  })
  if (!res.ok) throw new Error(`DuckDuckGo HTML ${res.status}`)
  const html = await res.text()

  // DDG sometimes returns an anomaly/CAPTCHA page — bail in that case.
  if (html.includes('anomaly-modal') || html.length < 5000) {
    throw new Error('DuckDuckGo returned a challenge page')
  }

  const results: SearchResultEntry[] = []
  const resultRegex =
    /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]*class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>)?/g

  let match: RegExpExecArray | null
  while ((match = resultRegex.exec(html)) !== null && results.length < limit) {
    const rawHref = match[1]
    const title = decodeEntities(match[2])
    const snippet = decodeEntities(match[3] || '')
    const url = decodeUddg(rawHref)
    if (title && url && !url.startsWith('javascript:')) {
      results.push({ title, url, snippet, source: 'duckduckgo' })
    }
  }
  return results
}

/**
 * DuckDuckGo Instant Answer API — always reachable, no challenge pages.
 * Returns a single abstract (Wikipedia summary) + related topics.
 */
export async function ddgInstantAnswerBrowser(
  query: string,
  limit = 5,
): Promise<{ abstract?: string; abstractUrl?: string; results: SearchResultEntry[] }> {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
  const res = await fetch(url)
  if (!res.ok) throw new Error(`DuckDuckGo IA ${res.status}`)
  const json = (await res.json()) as {
    Abstract?: string
    AbstractURL?: string
    Heading?: string
    Answer?: string
    RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>
  }

  const results: SearchResultEntry[] = []
  if (json.Abstract && json.AbstractURL) {
    results.push({ title: json.Heading || query, url: json.AbstractURL, snippet: json.Abstract, source: 'ddg-ia' })
  }
  if (Array.isArray(json.RelatedTopics)) {
    for (const t of json.RelatedTopics) {
      if (results.length >= limit) break
      if (t.Text && t.FirstURL) {
        results.push({
          title: t.Text.split(' - ')[0] || t.Text.slice(0, 80),
          url: t.FirstURL,
          snippet: t.Text,
          source: 'ddg-ia',
        })
      }
    }
  }
  return {
    abstract: json.Abstract || undefined,
    abstractUrl: json.AbstractURL || undefined,
    results,
  }
}

/**
 * Wikipedia REST search — always reachable, great for factual queries.
 * Returns page title, excerpt, URL, and description.
 */
export async function wikipediaSearchBrowser(query: string, limit = 5): Promise<SearchResultEntry[]> {
  const url = `https://en.wikipedia.org/w/rest.php/v1/search/page?q=${encodeURIComponent(query)}&limit=${limit}`
  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
  })
  if (!res.ok) throw new Error(`Wikipedia ${res.status}`)
  const json = (await res.json()) as {
    pages?: Array<{
      title: string
      key: string
      excerpt?: string
      description?: string
    }>
  }
  if (!json.pages) return []
  return json.pages.map((p) => ({
    title: p.title,
    url: `https://en.wikipedia.org/wiki/${encodeURIComponent(p.key.replace(/ /g, '_'))}`,
    snippet: stripHtml(p.excerpt || p.description || ''),
    source: 'wikipedia' as const,
  }))
}

function stripHtml(s: string): string {
  return s.replace(/<[^>]*>/g, '').trim()
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/<[^>]*>/g, '')
    .trim()
}

function decodeUddg(href: string): string {
  try {
    const u = new URL(href.startsWith('//') ? `https:${href}` : href)
    const uddg = u.searchParams.get('uddg')
    if (uddg) return decodeURIComponent(uddg)
    return href
  } catch {
    return href
  }
}

