'use client'

import { useCallback, useRef, useState } from 'react'
import { toast } from 'sonner'
import { useChatStore } from '@/lib/store'
import { generateImage, AGNES_INFO } from '@/lib/image'

interface UseImageOptions {
  conversationId: string
}

export function useImage({ conversationId }: UseImageOptions) {
  const [isGenerating, setIsGenerating] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  const addMessage = useChatStore((s) => s.addMessage)
  const updateMessage = useChatStore((s) => s.updateMessage)
  const deleteMessage = useChatStore((s) => s.deleteMessage)

  const runGenerate = useCallback(
    async (convId: string, prompt: string) => {
      const state = useChatStore.getState()
      const imageSettings = state.imageSettings
      const userAgnesKey = state.userAgnesKey

      // Add a user-facing message that mirrors the prompt (kind: 'image')
      state.addMessage(convId, { role: 'user', content: prompt, kind: 'image' })

      // Add assistant placeholder with generating flag
      const assistantId = state.addMessage(convId, {
        role: 'assistant',
        content: '',
        kind: 'image',
        generating: true,
        imagePrompt: prompt,
        images: [],
      })

      setIsGenerating(true)
      const controller = new AbortController()
      abortRef.current = controller

      try {
        const { images } = await generateImage({
          prompt,
          settings: imageSettings,
          userAgnesKey,
          signal: controller.signal,
        })
        state.updateMessage(convId, assistantId, { generating: false, images })
      } catch (err) {
        if ((err as Error).name === 'AbortError') {
          // Remove the empty placeholder if aborted
          const msg = useChatStore
            .getState()
            .conversations.find((c) => c.id === convId)
            ?.messages.find((m) => m.id === assistantId)
          if (msg && (!msg.images || msg.images.length === 0)) {
            state.deleteMessage(convId, assistantId)
          } else {
            state.updateMessage(convId, assistantId, { generating: false })
          }
        } else {
          const message = err instanceof Error ? err.message : 'Unknown error'
          state.updateMessage(convId, assistantId, { generating: false, error: message })
          toast.error('Image generation failed', { description: message, duration: 7000 })
        }
      } finally {
        setIsGenerating(false)
        abortRef.current = null
      }
    },
    [],
  )

  const generate = useCallback(
    async (prompt: string) => {
      const text = prompt.trim()
      if (!text || isGenerating) return
      const conv = useChatStore.getState().conversations.find((c) => c.id === conversationId)
      if (!conv) return
      await runGenerate(conversationId, text)
    },
    [conversationId, isGenerating, runGenerate],
  )

  const stop = useCallback(() => {
    abortRef.current?.abort()
  }, [])

  const regenerate = useCallback(async () => {
    if (isGenerating) return
    const conv = useChatStore.getState().conversations.find((c) => c.id === conversationId)
    if (!conv) return
    // Find the last assistant image message
    let lastAssistantIdx = -1
    for (let i = conv.messages.length - 1; i >= 0; i--) {
      if (conv.messages[i].role === 'assistant' && conv.messages[i].kind === 'image') {
        lastAssistantIdx = i
        break
      }
    }
    if (lastAssistantIdx === -1) return
    const promptMsg = [...conv.messages.slice(0, lastAssistantIdx)]
      .reverse()
      .find((m) => m.role === 'user' && m.kind === 'image')
    const prompt = promptMsg?.content || conv.messages[lastAssistantIdx].imagePrompt
    if (!prompt) return
    // Delete the old assistant image and the user prompt
    deleteMessage(conversationId, conv.messages[lastAssistantIdx].id)
    if (promptMsg) deleteMessage(conversationId, promptMsg.id)
    await runGenerate(conversationId, prompt)
  }, [conversationId, isGenerating, deleteMessage, runGenerate])

  return { generate, stop, regenerate, isGenerating, runGenerate, AGNES_INFO }
}

export type UseImageReturn = ReturnType<typeof useImage>
