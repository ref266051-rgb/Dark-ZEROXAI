'use client'

import type { ChatSettings } from './types'

export interface StreamMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
}

export interface StreamOptions {
  messages: StreamMessage[]
  settings: ChatSettings
  /** Groq model id (e.g. 'llama-3.1-8b-instant' or 'meta-llama/llama-prompt-guard-2-22m') */
  model?: string
  userApiKey?: string
  /** User-provided OpenRouter API key (used when model is from OpenRouter) */
  userOpenRouterKey?: string
  /** When true, request native reasoning from the model (OpenRouter reasoning models). */
  requestNativeReasoning?: boolean
  useBrowserMode?: boolean
  signal?: AbortSignal
  onDelta: (delta: string) => void
  /** Called with each chunk of reasoning content — works for both native (delta.reasoning) and <think> tag fallback */
  onThinkingDelta?: (delta: string) => void
  /** Called once when the thinking phase ends and the answer phase begins */
  onThinkingEnd?: () => void
  onFinish?: (reason: string) => void
  onError?: (
    err: string,
    kind?: 'forbidden' | 'auth' | 'network' | 'rate_limit' | 'quota' | 'unknown',
    meta?: { retryAfterSec?: number; limitType?: string },
  ) => void
}

const DEFAULT_GROQ_MODEL = process.env.NEXT_PUBLIC_GROQ_MODEL || 'llama-3.1-8b-instant'
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'

const OPENROUTER_URL =
  (process.env.NEXT_PUBLIC_OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1') +
  '/chat/completions'

/** Detect whether a model id should be routed to OpenRouter (vs Groq).
 *  OpenRouter models have ids like 'openrouter/owl-alpha', 'nvidia/nemotron-...',
 *  'liquid/lfm-...', etc. Groq models are bare names like 'llama-3.1-8b-instant'. */
export function isOpenRouterModel(modelId: string): boolean {
  // Anything with a vendor/ prefix (containing '/') goes to OpenRouter,
  // except for 'meta-llama/' which Groq also uses internally — but since
  // the user only selects from our CHAT_MODELS registry, we can be liberal here.
  // The litmus test: if it contains '/', it's an OpenRouter id.
  return modelId.includes('/')
}

/**
 * Pick the best OpenRouter API key for browser-direct mode:
 * 1. User-provided key (from Settings) — highest priority
 * 2. NEXT_PUBLIC_OPENROUTER_API_KEY (baked into the bundle) — fallback
 */
export function resolveOpenRouterKey(userApiKey?: string): string {
  if (userApiKey && userApiKey.trim().length > 0) return userApiKey.trim()
  return process.env.NEXT_PUBLIC_OPENROUTER_API_KEY || ''
}

/** True if the OpenRouter built-in demo key is available in the bundle. */
export function hasOpenRouterPublicKey(): boolean {
  return (process.env.NEXT_PUBLIC_OPENROUTER_API_KEY || '').length > 0
}

// Public key baked into the client bundle. Used as a fallback when the user
// has not provided their own key in Settings. Safe to expose because the
// user explicitly shared it; they can override it in Settings anytime.
const PUBLIC_KEY = process.env.NEXT_PUBLIC_GROQ_API_KEY || ''

/**
 * Pick the best API key for browser-direct mode:
 * 1. User-provided key (from Settings) — highest priority
 * 2. NEXT_PUBLIC_GROQ_API_KEY (baked into the bundle) — fallback
 */
function resolveBrowserApiKey(userApiKey?: string): string {
  if (userApiKey && userApiKey.trim().length > 0) return userApiKey.trim()
  return PUBLIC_KEY
}

function classifyError(
  status: number,
  body: string,
): 'forbidden' | 'auth' | 'network' | 'rate_limit' | 'quota' | 'unknown' {
  if (status === 429) {
    const lower = body.toLowerCase()
    // Quota = daily/monthly spending cap reached (not a temporary rate limit)
    if (
      lower.includes('quota') ||
      lower.includes('spending') ||
      lower.includes('monthly') ||
      lower.includes('daily') ||
      lower.includes('cap') ||
      lower.includes('plan limit')
    ) {
      return 'quota'
    }
    return 'rate_limit'
  }
  if (status === 402) {
    // Payment Required — billing limit
    return 'quota'
  }
  if (status === 401 || status === 403) {
    const lower = body.toLowerCase()
    if (lower.includes('forbidden') || lower.includes('cloudflare')) return 'forbidden'
    if (lower.includes('invalid api key') || lower.includes('unauthorized')) return 'auth'
    return 'forbidden'
  }
  return 'unknown'
}

/**
 * Parse the Retry-After header value (can be seconds or HTTP-date).
 * Returns seconds, or undefined if not present / unparseable.
 */
function parseRetryAfter(res: Response): number | undefined {
  const ra = res.headers.get('retry-after')
  if (!ra) return undefined
  // Numeric form: seconds
  const asNum = Number(ra)
  if (!isNaN(asNum) && asNum > 0) return Math.ceil(asNum)
  // HTTP-date form: parse and diff
  const asDate = Date.parse(ra)
  if (!isNaN(asDate)) {
    const diff = Math.ceil((asDate - Date.now()) / 1000)
    return diff > 0 ? diff : undefined
  }
  return undefined
}

/** Extract a friendly limit-type label from the error body */
function extractLimitType(body: string): string | undefined {
  const lower = body.toLowerCase()
  if (lower.includes('requests per minute') || lower.includes('rpm')) return 'Requests per minute'
  if (lower.includes('requests per day') || lower.includes('rpd')) return 'Daily requests'
  if (lower.includes('tokens per minute') || lower.includes('tpm')) return 'Tokens per minute'
  if (lower.includes('tokens per day') || lower.includes('tpd')) return 'Daily tokens'
  if (lower.includes('daily') || lower.includes('day')) return 'Daily quota'
  if (lower.includes('monthly') || lower.includes('month')) return 'Monthly spending cap'
  if (lower.includes('quota')) return 'Usage quota'
  return undefined
}

/**
 * Stream a chat completion from Groq.
 * - If `useBrowserMode` is true, the request goes straight from the browser
 *   to Groq using the user-provided key (or the baked-in NEXT_PUBLIC key).
 * - Otherwise, it goes through the server-side `/api/chat` proxy.
 *
 * Browser-direct is the default and recommended mode because the server host
 * may be blocked by Groq's Cloudflare WAF (403 Forbidden).
 */
export async function streamChatCompletion(opts: StreamOptions): Promise<void> {
  const {
    messages,
    settings,
    model,
    userApiKey,
    userOpenRouterKey,
    requestNativeReasoning,
    useBrowserMode,
    signal,
    onDelta,
    onThinkingDelta,
    onThinkingEnd,
    onFinish,
    onError,
  } = opts

  const modelId = model || DEFAULT_GROQ_MODEL
  const isOpenRouter = isOpenRouterModel(modelId)
  const useNativeReasoning = requestNativeReasoning && isOpenRouter

  // State machine for parsing <think>...</think> blocks out of the streamed
  // response. The AI is instructed (via the thinking system prompt) to wrap
  // its reasoning in <think>...</think> before the final answer. We split
  // the stream into two channels: thinking deltas and answer deltas.
  let inThinking = false
  let thinkBuffer = '' // holds partial <think> tag detection across chunks
  let thinkEnded = false
  let skipNextLeadingNewline = false // true right after <think> if next chunk might start with \n
  let skipNextLeadingAnswerNewline = false // true right after </think> if next chunk might start with \n

  const routeDelta = (delta: string) => {
    // Native reasoning (OpenRouter delta.reasoning) doesn't go through this
    // function — it's routed directly to onThinkingDelta from the SSE parser.
    // When native reasoning is active, all `content` deltas are the answer.
    if (useNativeReasoning) {
      onDelta(delta)
      return
    }
    if (!onThinkingDelta && !onThinkingEnd) {
      // Thinking mode is off — pass everything straight through.
      onDelta(delta)
      return
    }

    let remaining = delta
    // If we just consumed </think> at the end of the previous chunk, the next
    // chunk typically starts with '\n' — skip it once (we're now in answer mode).
    if (skipNextLeadingAnswerNewline && remaining.startsWith('\n')) {
      remaining = remaining.slice(1)
      skipNextLeadingAnswerNewline = false
      // Also skip a second '\n' if present (common: AI emits "\n\n" after </think>)
      if (remaining.startsWith('\n')) remaining = remaining.slice(1)
    } else if (skipNextLeadingAnswerNewline) {
      skipNextLeadingAnswerNewline = false
    }
    // If we just consumed <think> at the end of the previous chunk, the next
    // chunk typically starts with '\n' — skip it once (we're now in thinking mode).
    if (skipNextLeadingNewline && remaining.startsWith('\n')) {
      remaining = remaining.slice(1)
      skipNextLeadingNewline = false
    } else if (skipNextLeadingNewline) {
      // Next chunk didn't start with '\n' — clear the flag.
      skipNextLeadingNewline = false
    }
    while (remaining.length > 0) {
      if (inThinking) {
        // Look for the closing </think> tag.
        const endIdx = remaining.indexOf('</think>')
        if (endIdx === -1) {
          // No closing tag in this chunk. We may be mid-way through a tag
          // across chunks (e.g. held "</" + new "think>" = "</think>").
          // Combine buffer + remaining and check the combined string.
          const combined = thinkBuffer + remaining
          const combinedEnd = combined.indexOf('</think>')
          if (combinedEnd !== -1) {
            // Tag spans buffer + remaining — reprocess from combined.
            remaining = combined
            thinkBuffer = ''
            continue
          }
          // Find how many chars at the end of `combined` form a prefix of '</think>'.
          let holdLen = 0
          for (let i = Math.min(combined.length, 8); i >= 1; i--) {
            if ('</think>'.startsWith(combined.slice(-i))) {
              holdLen = i
              break
            }
          }
          // Flush everything before the held suffix as thinking content.
          const flushLen = combined.length - holdLen
          if (flushLen > 0) {
            onThinkingDelta?.(combined.slice(0, flushLen))
          }
          thinkBuffer = holdLen > 0 ? combined.slice(-holdLen) : ''
          remaining = ''
        } else {
          // Found closing tag — flush any held buffer, then thinking content
          // up to the tag, then switch to answer mode.
          if (thinkBuffer) {
            onThinkingDelta?.(thinkBuffer)
            thinkBuffer = ''
          }
          if (endIdx > 0) {
            onThinkingDelta?.(remaining.slice(0, endIdx))
          }
          inThinking = false
          thinkEnded = true
          onThinkingEnd?.()
          remaining = remaining.slice(endIdx + '</think>'.length)
          // Skip a leading newline if present (common right after </think>)
          if (remaining.startsWith('\n')) remaining = remaining.slice(1)
          if (remaining.startsWith('\n')) remaining = remaining.slice(1)
          // If remaining is empty, the next chunk might start with '\n' —
          // mark it so we skip on the next call.
          if (remaining.length === 0) {
            // We use a separate flag because skipNextLeadingNewline is for the
            // thinking branch; here we're back in answer mode.
            skipNextLeadingAnswerNewline = true
          }
        }
      } else {
        // Look for the opening <think> tag.
        // Only honor it if thinking hasn't ended yet (the AI shouldn't reopen,
        // but we guard against it anyway).
        const startIdx = remaining.indexOf('<think>')
        if (startIdx === -1 && !thinkEnded) {
          // No opening tag in this chunk. We may be mid-way through a tag
          // across chunks (e.g. held "<" + new "t" = "<t" which is a prefix
          // of "<think>"). Combine buffer + remaining and check the combined
          // string: does it contain "<think>"? Is its tail a prefix of "<think>"?
          const combined = thinkBuffer + remaining
          const combinedStartIdx = combined.indexOf('<think>')
          if (combinedStartIdx !== -1) {
            // Tag spans buffer + remaining — reprocess from combined.
            remaining = combined
            thinkBuffer = ''
            continue
          }
          // Find how many chars at the end of `combined` form a prefix of '<think>'.
          let holdLen = 0
          for (let i = Math.min(combined.length, 7); i >= 1; i--) {
            if ('<think>'.startsWith(combined.slice(-i))) {
              holdLen = i
              break
            }
          }
          // Flush everything before the held suffix as answer content.
          const flushLen = combined.length - holdLen
          if (flushLen > 0) {
            onDelta(combined.slice(0, flushLen))
          }
          thinkBuffer = holdLen > 0 ? combined.slice(-holdLen) : ''
          remaining = ''
        } else if (startIdx !== -1 && !thinkEnded) {
          // Found opening tag — flush anything before it (including any held
          // buffer) as answer content, then switch to thinking mode.
          if (thinkBuffer) {
            onDelta(thinkBuffer)
            thinkBuffer = ''
          }
          if (startIdx > 0) {
            onDelta(remaining.slice(0, startIdx))
          }
          inThinking = true
          remaining = remaining.slice(startIdx + '<think>'.length)
          // Skip a leading newline right after <think> (also when the newline
          // lands in the next chunk, we'll handle it on the next iteration
          // by checking remaining.startsWith('\n') again here).
          if (remaining.startsWith('\n')) remaining = remaining.slice(1)
          // If remaining is now empty but we just consumed <think>, the next
          // chunk might start with '\n' — we handle that on the next call by
          // routing through inThinking branch. To avoid leaking that leading
          // newline into thinking content, set a flag.
          if (remaining.length === 0) {
            // Mark that we should skip a leading newline on the next chunk
            skipNextLeadingNewline = true
          }
        } else {
          // Thinking already ended (or no opening tag in this chunk) — pass through.
          if (thinkBuffer) {
            onDelta(thinkBuffer)
            thinkBuffer = ''
          }
          onDelta(remaining)
          remaining = ''
        }
      }
    }
  }

  const finalMessages = [
    ...(settings.systemPrompt ? [{ role: 'system' as const, content: settings.systemPrompt }] : []),
    ...messages,
  ]

  const requestBody: Record<string, unknown> = {
    model: modelId,
    messages: finalMessages,
    temperature: settings.temperature,
    max_tokens: settings.maxTokens,
    top_p: settings.topP,
    stream: true,
  }
  // OpenRouter native reasoning — ask the model to emit reasoning via delta.reasoning.
  // We allocate a reasonable thinking budget (separate from max_tokens which is for the answer).
  if (useNativeReasoning) {
    requestBody.reasoning = {
      enabled: true,
      max_tokens: Math.min(2048, Math.max(512, settings.maxTokens)),
    }
    // Some reasoning models want temperature unset or 1; we keep the user's choice
    // but cap it to avoid degenerate output.
    requestBody.temperature = Math.min(Number(requestBody.temperature) || 0.7, 1)
  }
  const body = JSON.stringify(requestBody)

  let res: Response
  try {
    if (isOpenRouter) {
      // OpenRouter endpoint — same OpenAI-compatible shape, different host.
      // OpenRouter streams SSE comments (`: OPENROUTER PROCESSING`) which our
      // parser already ignores (lines starting with `:` aren't `data:` lines).
      if (useBrowserMode) {
        const key = resolveOpenRouterKey(userOpenRouterKey)
        if (!key) {
          onError?.(
            'No OpenRouter API key available. Open Settings and paste your OpenRouter API key, or set NEXT_PUBLIC_OPENROUTER_API_KEY.',
            'auth',
          )
          return
        }
        res = await fetch(OPENROUTER_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${key}`,
            // OpenRouter recommends these optional headers for analytics;
            // safe to omit but nice to include.
            'HTTP-Referer': window.location.origin,
            'X-Title': 'zeroX ai',
          },
          body,
          signal,
        })
      } else {
        res = await fetch('/api/chat/openrouter', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: modelId,
            messages: finalMessages,
            systemPrompt: settings.systemPrompt,
            temperature: settings.temperature,
            maxTokens: settings.maxTokens,
            topP: settings.topP,
            requestNativeReasoning: useNativeReasoning,
          }),
          signal,
        })
      }
    } else if (useBrowserMode) {
      const key = resolveBrowserApiKey(userApiKey)
      if (!key) {
        onError?.(
          'No API key available. Open Settings and paste your Groq API key, or set NEXT_PUBLIC_GROQ_API_KEY.',
          'auth',
        )
        return
      }
      res = await fetch(GROQ_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body,
        signal,
      })
    } else {
      res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: modelId,
          messages: finalMessages,
          systemPrompt: settings.systemPrompt,
          temperature: settings.temperature,
          maxTokens: settings.maxTokens,
          topP: settings.topP,
        }),
        signal,
      })
    }
  } catch (err) {
    if ((err as Error).name === 'AbortError') {
      onFinish?.('aborted')
      return
    }
    console.error('[streamChatCompletion] initial fetch failed:', err)
    onError?.(
      err instanceof Error ? err.message : 'Network error — could not reach the provider.',
      'network',
    )
    return
  }

  if (!res.ok || !res.body) {
    let msg = `Request failed (${res.status})`
    let raw = ''
    try {
      raw = await res.text()
      try {
        const j = JSON.parse(raw)
        // Groq returns errors as {"error": {"message": "...", "type": "...", "param": "..."}}
        // — we need to extract the inner .message string, not the whole object.
        if (j.error) {
          if (typeof j.error === 'string') {
            msg = j.error
          } else if (typeof j.error === 'object' && j.error !== null) {
            msg = j.error.message || j.error.type || JSON.stringify(j.error)
          } else {
            msg = String(j.error)
          }
        }
      } catch {
        msg = raw || msg
      }
    } catch {
      /* noop */
    }
    const kind = classifyError(res.status, raw || msg)
    // For rate-limit / quota errors, extract retry-after + limit type so the
    // UI can show a friendly "limit tercapai" banner with countdown.
    const meta: { retryAfterSec?: number; limitType?: string } = {}
    if (kind === 'rate_limit' || kind === 'quota') {
      const ra = parseRetryAfter(res)
      if (ra !== undefined) meta.retryAfterSec = ra
      const lt = extractLimitType(raw || msg)
      if (lt) meta.limitType = lt
    }
    console.error('[streamChatCompletion] non-ok response', { status: res.status, msg, kind })
    onError?.(msg, kind, meta)
    return
  }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })

      const parts = buffer.split('\n\n')
      buffer = parts.pop() || ''

      for (const part of parts) {
        const line = part.trim()
        if (!line.startsWith('data:')) continue
        const payload = line.slice(5).trim()
        if (!payload) continue
        if (payload === '[DONE]') {
          onFinish?.('done')
          return
        }
        try {
          const json = JSON.parse(payload)
          if (json.error) {
            // Same normalization as the non-ok branch above.
            let errMsg: string
            let errType: string | undefined
            if (typeof json.error === 'string') errMsg = json.error
            else if (typeof json.error === 'object' && json.error !== null) {
              errMsg = json.error.message || json.error.type || JSON.stringify(json.error)
              errType = json.error.type
            } else errMsg = String(json.error)
            // Mid-stream errors are typically rate-limit interrupts. Classify
            // based on the error type field if present.
            let kind = classifyError(0, errMsg)
            if (
              errType === 'rate_limit_exceeded' ||
              errType === 'rate_limit' ||
              errMsg.toLowerCase().includes('rate limit')
            ) {
              kind = 'rate_limit'
            } else if (errType === 'quota_exceeded' || errMsg.toLowerCase().includes('quota')) {
              kind = 'quota'
            }
            const meta: { limitType?: string } = {}
            const lt = extractLimitType(errMsg)
            if (lt) meta.limitType = lt
            onError?.(errMsg, kind, meta)
            return
          }
          const choice = json?.choices?.[0]
          const delta = choice?.delta

          // Native reasoning stream (OpenRouter reasoning models).
          // The model emits `delta.reasoning` for its chain-of-thought, then
          // `delta.content` for the final answer. Route them to separate channels.
          if (useNativeReasoning && delta?.reasoning) {
            onThinkingDelta?.(delta.reasoning)
          }
          // Once content starts streaming, mark thinking as done (if not already).
          if (useNativeReasoning && delta?.content && !thinkEnded) {
            thinkEnded = true
            inThinking = false
            onThinkingEnd?.()
          }
          if (delta?.content) {
            routeDelta(delta.content)
          }
          if (choice?.finish_reason) {
            // If the model finished without ever emitting content (e.g. pure
            // reasoning then stop), close the thinking phase.
            if (useNativeReasoning && !thinkEnded) {
              thinkEnded = true
              inThinking = false
              onThinkingEnd?.()
            }
            onFinish?.(choice.finish_reason)
          }
        } catch {
          /* noop */
        }
      }
    }
    // Flush any held buffer that never resolved into a tag (e.g. AI didn't
    // close </think> or emitted a stray "<thi" at the very end).
    if (thinkBuffer) {
      if (inThinking) {
        onThinkingDelta?.(thinkBuffer)
      } else {
        onDelta(thinkBuffer)
      }
      thinkBuffer = ''
    }
    if (inThinking) {
      // Stream ended while still inside <think> — close it out.
      onThinkingEnd?.()
    }
    onFinish?.('done')
  } catch (err) {
    if ((err as Error).name === 'AbortError') {
      onFinish?.('aborted')
      return
    }
    console.error('[streamChatCompletion] stream read failed:', err)
    onError?.(err instanceof Error ? err.message : 'Stream error', 'network')
  }
}

export function hasPublicKey(): boolean {
  return PUBLIC_KEY.length > 0
}
