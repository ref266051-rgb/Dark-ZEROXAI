'use client'

import {
  Sparkles,
  Code2,
  PenLine,
  GraduationCap,
  BarChart3,
  Lightbulb,
  Rocket,
  Bug,
  Mail,
  ChefHat,
  Map,
  Bot,
  Building2,
  Mountain,
  Utensils,
  PawPrint,
  Satellite,
  Camera,
  Palette,
  Cherry,
  Image,
  Box,
  Droplet,
  Grid3x3,
  FileText,
  Languages,
  Brain,
  Baby,
  Scale,
  type LucideIcon,
} from 'lucide-react'
import type { IconName } from './types'

const REGISTRY: Record<IconName, LucideIcon> = {
  sparkles: Sparkles,
  code: Code2,
  pen: PenLine,
  graduation: GraduationCap,
  chart: BarChart3,
  lightbulb: Lightbulb,
  rocket: Rocket,
  bug: Bug,
  mail: Mail,
  'chef-hat': ChefHat,
  map: Map,
  bot: Bot,
  city: Building2,
  mountain: Mountain,
  utensils: Utensils,
  pawprint: PawPrint,
  satellite: Satellite,
  camera: Camera,
  palette: Palette,
  cherry: Cherry,
  image: Image,
  cube: Box,
  droplet: Droplet,
  grid: Grid3x3,
  file: FileText,
  languages: Languages,
  brain: Brain,
  baby: Baby,
  scale: Scale,
}

export function getIcon(name: IconName): LucideIcon {
  return REGISTRY[name] || Sparkles
}

export { Sparkles }
