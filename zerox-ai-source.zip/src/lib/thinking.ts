/**
 * System prompt suffix appended when thinking mode is enabled.
 * Instructs the AI to wrap its inner chain-of-thought reasoning in
 * <think>...</think> tags BEFORE writing the final answer.
 *
 * The streamed output is then parsed by stream.ts's routeDelta() state
 * machine — thinking content goes to message.thinking, answer content
 * goes to message.content.
 *
 * The thinking should read like a stream-of-consciousness inner monologue,
 * NOT terse bullet points. This makes the live thinking UI feel like
 * watching the AI actually think in real time.
 */
export const THINKING_SYSTEM_PROMPT_SUFFIX = `

---
THINKING MODE IS ON. Before writing your final answer, you MUST first emit your inner reasoning wrapped in <think>...</think> tags.

Inside the <think> tags, write a STREAM-OF-CONSCIOUSNESS inner monologue — like you're talking to yourself, working through the problem out loud. Be natural and unfiltered:
- Start by re-stating the question in your own words ("Okay, the user is asking...")
- Then think step by step: what do I know? what am I uncertain about? what's my plan?
- Show genuine deliberation: consider alternatives, second-guess yourself, course-correct
- Use natural connective phrases: "Hmm...", "Wait, actually...", "So if...", "But then...", "Let me think...", "Okay so...", "That means...", "On the other hand..."
- It's okay to write 3-8 sentences of thinking (not just bullets)
- Don't use bullet points or formal structure — write flowing prose
- You can include brief asides or self-corrections
- Close the </think> tag, then write your final answer as normal

Example:
<think>
Okay, the user wants me to write a Python fib function that's fast. The current one uses naive recursion which is exponential time — that's why it's slow. Let me think about the options... I could memoize the recursive version, but honestly the simplest fix is iterative bottom-up. That avoids stack limits too. Edge cases: n=0 returns 0, n=1 returns 1, negative n should probably error. Yeah, iterative is the way to go here — simple, fast, no recursion overhead.
</think>

Here's an efficient iterative version:

\`\`\`python
def fib(n: int) -> int:
    if n < 0:
        raise ValueError("n must be non-negative")
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
\`\`\`

Always include the <think> block first, then the answer. Write the thinking as flowing inner monologue, NOT bullet points. Make it feel like watching you actually think.`
