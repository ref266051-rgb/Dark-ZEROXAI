'use client'

import type { SearchResponse, SearchResult } from './search-types'
import type { SearchProgressStep } from './types'
import {
  ddgHtmlSearchBrowser,
  ddgInstantAnswerBrowser,
  wikipediaSearchBrowser,
} from './search-browser'

export interface PerformSearchOptions {
  /** Called for each backend as it starts — used to power the live "visiting site N/M" indicator */
  onBackendStart?: (backend: string) => void
  /** Called when a backend returns results */
  onBackendResult?: (backend: string, count: number) => void
  /** Called when a backend fails */
  onBackendError?: (backend: string, err: string) => void
  /** Called with the full progress array on every change (for live UI updates) */
  onProgress?: (progress: SearchProgressStep[]) => void
  /** Max results to return overall */
  limit?: number
  /** Signal to abort */
  signal?: AbortSignal
  /** When true, route through the server-side /api/search proxy instead of browser-direct */
  useServerProxy?: boolean
}

/**
 * High-level search coordinator. Runs three backends in parallel:
 *   1. DuckDuckGo HTML (real organic results, primary)
 *   2. Wikipedia REST (factual / encyclopedic, always reachable)
 *   3. DuckDuckGo Instant Answer (definitions / disambiguation)
 * Dedupes by URL and merges into a single ranked list.
 *
 * Reports live progress via the optional callbacks so the UI can show
 * "Searching DuckDuckGo…", "Searching Wikipedia…", "Found 3 results", etc.
 *
 * In browser-direct mode (default), each backend is called from the user's
 * browser directly. In server-proxy mode, the request goes through /api/search.
 */
export async function performSearch(
  query: string,
  opts: PerformSearchOptions = {},
): Promise<SearchResponse> {
  const {
    onBackendStart,
    onBackendResult,
    onBackendError,
    onProgress,
    limit = 6,
    signal,
    useServerProxy = false,
  } = opts
  const start = Date.now()

  if (useServerProxy) {
    // Single round-trip through the server proxy.
    onBackendStart?.('Server proxy')
    onProgress?.([{ backend: 'Server proxy', status: 'running' }])
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit }),
        signal,
      })
      if (!res.ok) throw new Error(`Search proxy ${res.status}`)
      const json = (await res.json()) as SearchResponse
      onBackendResult?.('Server proxy', json.results.length)
      onProgress?.([{ backend: 'Server proxy', status: 'success', count: json.results.length }])
      return { ...json, tookMs: Date.now() - start }
    } catch (e) {
      onBackendError?.('Server proxy', e instanceof Error ? e.message : 'failed')
      onProgress?.([{ backend: 'Server proxy', status: 'error', error: e instanceof Error ? e.message : 'failed' }])
      return {
        query,
        results: [],
        source: 'none',
        tookMs: Date.now() - start,
        backendsHit: [],
      }
    }
  }

  // Live progress tracker — shared mutable array that all backends update.
  const progress: SearchProgressStep[] = [
    { backend: 'DuckDuckGo', status: 'pending' },
    { backend: 'Wikipedia', status: 'pending' },
    { backend: 'DuckDuckGo IA', status: 'pending' },
  ]
  const setStep = (backend: string, patch: Partial<SearchProgressStep>) => {
    const idx = progress.findIndex((s) => s.backend === backend)
    if (idx >= 0) {
      progress[idx] = { ...progress[idx], ...patch }
      onProgress?.([...progress])
    }
  }

  const tasks: Array<{ name: string; run: () => Promise<SearchResult[]> }> = [
    {
      name: 'DuckDuckGo',
      run: async () => {
        onBackendStart?.('DuckDuckGo')
        setStep('DuckDuckGo', { status: 'running' })
        try {
          const r = await ddgHtmlSearchBrowser(query, limit)
          onBackendResult?.('DuckDuckGo', r.length)
          setStep('DuckDuckGo', { status: 'success', count: r.length })
          return r
        } catch (e) {
          const msg = e instanceof Error ? e.message : 'failed'
          onBackendError?.('DuckDuckGo', msg)
          setStep('DuckDuckGo', { status: 'error', error: msg })
          return []
        }
      },
    },
    {
      name: 'Wikipedia',
      run: async () => {
        onBackendStart?.('Wikipedia')
        setStep('Wikipedia', { status: 'running' })
        try {
          const r = await wikipediaSearchBrowser(query, 4)
          onBackendResult?.('Wikipedia', r.length)
          setStep('Wikipedia', { status: 'success', count: r.length })
          return r
        } catch (e) {
          const msg = e instanceof Error ? e.message : 'failed'
          onBackendError?.('Wikipedia', msg)
          setStep('Wikipedia', { status: 'error', error: msg })
          return []
        }
      },
    },
    {
      name: 'DuckDuckGo IA',
      run: async () => {
        onBackendStart?.('DuckDuckGo IA')
        setStep('DuckDuckGo IA', { status: 'running' })
        try {
          const ia = await ddgInstantAnswerBrowser(query, 3)
          onBackendResult?.('DuckDuckGo IA', ia.results.length)
          setStep('DuckDuckGo IA', { status: 'success', count: ia.results.length })
          return ia.results
        } catch (e) {
          const msg = e instanceof Error ? e.message : 'failed'
          onBackendError?.('DuckDuckGo IA', msg)
          setStep('DuckDuckGo IA', { status: 'error', error: msg })
          return []
        }
      },
    },
  ]

  const settled = await Promise.all(
    tasks.map(async (t) => {
      if (signal?.aborted) return { name: t.name, results: [] as SearchResult[] }
      try {
        const results = await t.run()
        return { name: t.name, results }
      } catch {
        return { name: t.name, results: [] as SearchResult[] }
      }
    }),
  )

  // Dedupe by URL (case-insensitive on the pathname)
  const seen = new Set<string>()
  const combined: SearchResult[] = []
  const backendsHit: string[] = []
  for (const { name, results } of settled) {
    if (results.length > 0) backendsHit.push(name)
    for (const r of results) {
      const key = r.url.toLowerCase().replace(/\/$/, '')
      if (seen.has(key)) continue
      seen.add(key)
      combined.push(r)
      if (combined.length >= limit) break
    }
    if (combined.length >= limit) break
  }

  let source: SearchResponse['source'] = 'none'
  if (combined.length > 0) {
    if (backendsHit.length >= 2) source = 'mixed'
    else if (backendsHit[0] === 'DuckDuckGo') source = 'ddg-html'
    else if (backendsHit[0] === 'Wikipedia') source = 'wikipedia'
    else if (backendsHit[0] === 'DuckDuckGo IA') source = 'ddg-ia'
  }

  // Also fetch the DDG IA abstract separately so we can include it in the response
  let abstract: string | undefined
  let abstractUrl: string | undefined
  try {
    const ia = await ddgInstantAnswerBrowser(query, 1)
    abstract = ia.abstract
    abstractUrl = ia.abstractUrl
  } catch {
    /* noop */
  }

  return {
    query,
    results: combined,
    source,
    abstract,
    abstractUrl,
    tookMs: Date.now() - start,
    backendsHit,
  }
}

/**
 * Decide whether a user message looks like it needs live web search.
 * Cheap heuristic — runs in the client before even contacting the LLM.
 */
export function shouldAutoSearch(text: string): boolean {
  const t = text.toLowerCase()
  const triggers = [
    'latest',
    'recent',
    'today',
    'yesterday',
    'this week',
    'this month',
    'this year',
    'current',
    'now',
    'news',
    'update',
    'updates',
    'happening',
    'happen',
    'price',
    'prices',
    'stock',
    'weather',
    'forecast',
    'score',
    'scores',
    'result',
    'results',
    'release',
    'released',
    'announce',
    'announced',
    'who is',
    'what is',
    'when is',
    'when was',
    'where is',
    'how do i',
    'how to',
    'best',
    'top',
    'compare',
    'vs',
    'versus',
    '2024',
    '2025',
    '2026',
    'find',
    'search for',
    'look up',
    'lookup',
  ]
  // Only trigger if the message is reasonably long (avoid "hi"/"yes")
  if (text.trim().length < 12) return false
  return triggers.some((tr) => t.includes(tr))
}
