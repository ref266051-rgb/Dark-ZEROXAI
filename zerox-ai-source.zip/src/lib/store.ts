'use client'

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { v4 as uuid } from 'uuid'
import type { AppMode, ChatMessage, ChatSettings, Conversation, ImageSettings, Persona } from './types'
import { DEFAULT_PERSONAS, DEFAULT_SETTINGS, DEFAULT_IMAGE_SETTINGS, DEFAULT_CHAT_MODEL_ID } from './types'

interface ChatStore {
  conversations: Conversation[]
  activeId: string | null
  settings: ChatSettings
  activePersonaId: string
  imageSettings: ImageSettings
  /** Currently-selected top-level mode — used for new conversations */
  mode: AppMode
  /** Currently-selected chat model id (from CHAT_MODELS) */
  selectedChatModelId: string
  /** Selected model id for thinking mode (separate picker — only reasoning models) */
  thinkingModelId: string
  /** Optional user-provided Groq API key (stored locally, calls go browser→Groq) */
  userApiKey: string
  /** Optional user-provided Agnes AI API key (browser-direct image generation) */
  userAgnesKey: string
  /** Optional user-provided OpenRouter API key (browser-direct chat with OpenRouter models) */
  userOpenRouterKey: string
  /** When true, use the userApiKey and call Groq directly from the browser */
  useBrowserMode: boolean
  /** When true, chat messages trigger a DuckDuckGo+Wikipedia web search first
   *  and the results are injected into the model's context. */
  webSearchEnabled: boolean
  /** When true, AI uses <think> tags for chain-of-thought reasoning shown in a collapsible bubble */
  thinkingEnabled: boolean

  /* selectors */
  active: () => Conversation | undefined

  /* conversation ops */
  newConversation: (personaId?: string, mode?: AppMode) => string
  deleteConversation: (id: string) => void
  renameConversation: (id: string, title: string) => void
  setActive: (id: string) => void
  clearAll: () => void
  importConversation: (c: Conversation) => void

  /* message ops */
  addMessage: (convId: string, msg: Omit<ChatMessage, 'id' | 'createdAt'>) => string
  updateMessage: (convId: string, msgId: string, patch: Partial<ChatMessage>) => void
  appendToMessage: (convId: string, msgId: string, delta: string) => void
  deleteMessage: (convId: string, msgId: string) => void

  /* settings */
  setSettings: (patch: Partial<ChatSettings>) => void
  applyPersona: (persona: Persona) => void
  setImageSettings: (patch: Partial<ImageSettings>) => void
  setMode: (mode: AppMode) => void
  setSelectedChatModelId: (id: string) => void
  setThinkingModelId: (id: string) => void

  /* api key */
  setUserApiKey: (key: string) => void
  setUserAgnesKey: (key: string) => void
  setUserOpenRouterKey: (key: string) => void
  setUseBrowserMode: (v: boolean) => void
  setWebSearchEnabled: (v: boolean) => void
  setThinkingEnabled: (v: boolean) => void

  /* search */
  searchConversations: (q: string) => Conversation[]
}

function autoTitle(text: string): string {
  const cleaned = text.replace(/\s+/g, ' ').trim()
  if (!cleaned) return 'New chat'
  return cleaned.length > 38 ? cleaned.slice(0, 38) + '…' : cleaned
}

export const useChatStore = create<ChatStore>()(
  persist(
    (set, get) => ({
      conversations: [],
      activeId: null,
      settings: DEFAULT_SETTINGS,
      activePersonaId: 'default',
      imageSettings: DEFAULT_IMAGE_SETTINGS,
      mode: 'chat',
      selectedChatModelId: DEFAULT_CHAT_MODEL_ID,
      // Default thinking model: Nemotron (better native reasoning, 9B)
      thinkingModelId: 'nvidia/nemotron-nano-9b-v2:free',
      userApiKey: '',
      userAgnesKey: '',
      userOpenRouterKey: '',
      // Browser-direct is the default because the server host is frequently
      // blocked by Groq's Cloudflare WAF. Falls back to NEXT_PUBLIC_GROQ_API_KEY
      // when userApiKey is empty (see stream.ts).
      useBrowserMode: true,
      webSearchEnabled: false,
      thinkingEnabled: false,

      active: () => get().conversations.find((c) => c.id === get().activeId),

      newConversation: (personaId, mode) => {
        const id = uuid()
        const now = Date.now()
        const finalMode = mode ?? get().mode
        const conv: Conversation = {
          id,
          title: finalMode === 'image' ? 'New image' : finalMode === 'thinking' ? 'New thinking' : 'New chat',
          messages: [],
          createdAt: now,
          updatedAt: now,
          personaId: personaId ?? get().activePersonaId,
          mode: finalMode,
        }
        set((s) => ({ conversations: [conv, ...s.conversations], activeId: id }))
        return id
      },

      deleteConversation: (id) =>
        set((s) => {
          const conversations = s.conversations.filter((c) => c.id !== id)
          const activeId = s.activeId === id ? conversations[0]?.id ?? null : s.activeId
          return { conversations, activeId }
        }),

      renameConversation: (id, title) =>
        set((s) => ({
          conversations: s.conversations.map((c) =>
            c.id === id ? { ...c, title: title.trim() || 'Untitled', updatedAt: Date.now() } : c,
          ),
        })),

      setActive: (id) => set({ activeId: id }),

      clearAll: () => set({ conversations: [], activeId: null }),

      importConversation: (c) =>
        set((s) => ({ conversations: [c, ...s.conversations], activeId: c.id })),

      addMessage: (convId, msg) => {
        const id = uuid()
        const message: ChatMessage = { ...msg, id, createdAt: Date.now() }
        set((s) => ({
          conversations: s.conversations.map((c) => {
            if (c.id !== convId) return c
            const isFirstUser = msg.role === 'user' && !c.messages.some((m) => m.role === 'user')
            return {
              ...c,
              title: isFirstUser ? autoTitle(msg.content) : c.title,
              messages: [...c.messages, message],
              updatedAt: Date.now(),
            }
          }),
        }))
        return id
      },

      updateMessage: (convId, msgId, patch) =>
        set((s) => ({
          conversations: s.conversations.map((c) =>
            c.id === convId
              ? {
                  ...c,
                  messages: c.messages.map((m) => (m.id === msgId ? { ...m, ...patch } : m)),
                  updatedAt: Date.now(),
                }
              : c,
          ),
        })),

      appendToMessage: (convId, msgId, delta) =>
        set((s) => ({
          conversations: s.conversations.map((c) =>
            c.id === convId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === msgId ? { ...m, content: m.content + delta } : m,
                  ),
                  updatedAt: Date.now(),
                }
              : c,
          ),
        })),

      deleteMessage: (convId, msgId) =>
        set((s) => ({
          conversations: s.conversations.map((c) =>
            c.id === convId
              ? { ...c, messages: c.messages.filter((m) => m.id !== msgId), updatedAt: Date.now() }
              : c,
          ),
        })),

      setSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),

      applyPersona: (persona) =>
        set((s) => ({
          activePersonaId: persona.id,
          settings: { ...s.settings, systemPrompt: persona.systemPrompt },
        })),

      setImageSettings: (patch) => set((s) => ({ imageSettings: { ...s.imageSettings, ...patch } })),

      setMode: (mode) => set({ mode }),

      setSelectedChatModelId: (id) => set({ selectedChatModelId: id }),
      setThinkingModelId: (id) => set({ thinkingModelId: id }),

      setUserApiKey: (key) => set({ userApiKey: key.trim() }),
      setUserAgnesKey: (key) => set({ userAgnesKey: key.trim() }),
      setUserOpenRouterKey: (key) => set({ userOpenRouterKey: key.trim() }),
      setUseBrowserMode: (v) => set({ useBrowserMode: v }),
      setWebSearchEnabled: (v) => set({ webSearchEnabled: v }),
      setThinkingEnabled: (v) => set({ thinkingEnabled: v }),

      searchConversations: (q) => {
        const query = q.trim().toLowerCase()
        if (!query) return get().conversations
        return get().conversations.filter(
          (c) =>
            c.title.toLowerCase().includes(query) ||
            c.messages.some((m) => m.content.toLowerCase().includes(query)),
        )
      },
    }),
    {
      name: 'zerox-ai-store',
      version: 7,
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        conversations: s.conversations,
        settings: s.settings,
        activePersonaId: s.activePersonaId,
        activeId: s.activeId,
        userApiKey: s.userApiKey,
        userAgnesKey: s.userAgnesKey,
        userOpenRouterKey: s.userOpenRouterKey,
        useBrowserMode: s.useBrowserMode,
        webSearchEnabled: s.webSearchEnabled,
        thinkingEnabled: s.thinkingEnabled,
        imageSettings: s.imageSettings,
        mode: s.mode,
        selectedChatModelId: s.selectedChatModelId,
        thinkingModelId: s.thinkingModelId,
      }),
      merge: (persisted, current) => {
        const p = (persisted || {}) as Partial<ChatStore>
        // Force browser-direct mode on for everyone (server host is blocked
        // by Groq's Cloudflare WAF — see stream.ts). User can still turn it
        // off in Settings if they prefer the server proxy.

        // Sanitize any legacy message.error values that are objects (from the
        // old buggy stream.ts that passed Groq's {message, type, param} body
        // verbatim). Convert them to strings so React can render them.
        const sanitizedConversations = Array.isArray(p.conversations)
          ? p.conversations.map((c) => ({
              ...c,
              messages: Array.isArray(c.messages)
                ? c.messages.map((m) => {
                    if (m.error !== undefined && typeof m.error !== 'string') {
                      try {
                        const e = m.error as unknown as { message?: string; type?: string }
                        return {
                          ...m,
                          error: e?.message || e?.type || JSON.stringify(e),
                        }
                      } catch {
                        return { ...m, error: 'Unknown error' }
                      }
                    }
                    return m
                  })
                : c.messages,
            }))
          : current.conversations

        return {
          ...current,
          ...p,
          conversations: sanitizedConversations,
          useBrowserMode: true,
          // Backfill imageSettings for older persisted states
          imageSettings: { ...DEFAULT_IMAGE_SETTINGS, ...(p.imageSettings || {}) },
          mode: p.mode || 'chat',
          userAgnesKey: p.userAgnesKey || '',
          userOpenRouterKey: p.userOpenRouterKey || '',
          selectedChatModelId: p.selectedChatModelId || DEFAULT_CHAT_MODEL_ID,
          thinkingModelId: p.thinkingModelId || 'nvidia/nemotron-nano-9b-v2:free',
          webSearchEnabled: p.webSearchEnabled ?? false,
          thinkingEnabled: p.thinkingEnabled ?? false,
        } as ChatStore
      },
    },
  ),
)

export { DEFAULT_PERSONAS }
