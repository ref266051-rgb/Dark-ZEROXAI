export type Role = 'user' | 'assistant' | 'system'

export type AppMode = 'chat' | 'image' | 'thinking'

export interface ImageArtifact {
  url: string
  /** optional revised prompt returned by the model */
  revisedPrompt?: string | null
  /** size requested */
  size?: string
}

/** A single web-search result returned by /api/search */
export interface SearchResultEntry {
  title: string
  url: string
  snippet: string
  source: 'duckduckgo' | 'wikipedia' | 'ddg-ia' | 'unknown'
}

/** One step in the live search progress (one per backend) */
export interface SearchProgressStep {
  /** backend name, e.g. "DuckDuckGo", "Wikipedia", "DuckDuckGo IA" */
  backend: string
  status: 'pending' | 'running' | 'success' | 'error'
  /** number of results returned (when status is 'success') */
  count?: number
  /** error message (when status is 'error') */
  error?: string
}

/** Web-search context attached to a chat message */
export interface SearchContext {
  query: string
  results: SearchResultEntry[]
  instantAnswer?: string
  instantAnswerUrl?: string
  /** which backends actually returned results */
  backendsHit?: string[]
  /** time spent searching in ms */
  tookMs?: number
  /** live progress steps — only set while searching is in progress */
  progress?: SearchProgressStep[]
}

export interface ChatMessage {
  id: string
  role: Role
  content: string
  createdAt: number
  /** true while the assistant message is still being streamed */
  streaming?: boolean
  /** stored error message if generation failed */
  error?: string
  /** structured error kind for specialized rendering (rate-limit banner etc.) */
  errorKind?: 'forbidden' | 'auth' | 'network' | 'rate_limit' | 'quota' | 'unknown'
  /** for rate-limit errors: seconds until the user can retry */
  retryAfterSec?: number
  /** for rate-limit errors: friendly label like "Daily quota" or "Requests per minute" */
  limitType?: string
  /** present when this is an image-generation turn (mode='image') */
  kind?: 'text' | 'image'
  /** for assistant image messages — the generated image(s) */
  images?: ImageArtifact[]
  /** for assistant image messages while generating */
  generating?: boolean
  /** the prompt used to generate the image (mirrored for regenerate) */
  imagePrompt?: string
  /** when web search was enabled for this turn, the results we found */
  searchContext?: SearchContext
  /** true while the assistant is fetching search results (before streaming starts) */
  searching?: boolean
  /** user feedback on this message: 'up' | 'down' | undefined */
  feedback?: 'up' | 'down'

  /** Chain-of-thought reasoning from the AI (when thinking mode is on) */
  thinking?: string
  /** true while the AI is still streaming its thinking phase */
  thinkingStreaming?: boolean
  /** total characters of thinking produced so far (for live counter) */
  thinkingCharCount?: number
  /** time spent thinking, in ms (set when thinking phase completes) */
  thinkingTookMs?: number
  /** thinking throughput in chars/sec (set when thinking phase completes) */
  thinkingCharsPerSec?: number
  /** word count of thinking (set when thinking phase completes) */
  thinkingWordCount?: number
  /** true if thinking came from native reasoning (OpenRouter delta.reasoning), false if from <think> tag fallback */
  thinkingNative?: boolean
}

export interface Conversation {
  id: string
  title: string
  messages: ChatMessage[]
  createdAt: number
  updatedAt: number
  /** persona preset id */
  personaId?: string
  /** 'chat' (default) or 'image' — locks the conversation's mode */
  mode?: AppMode
}

export type IconName =
  | 'sparkles'
  | 'code'
  | 'pen'
  | 'graduation'
  | 'chart'
  | 'lightbulb'
  | 'rocket'
  | 'bug'
  | 'mail'
  | 'chef-hat'
  | 'map'
  | 'bot'
  | 'city'
  | 'mountain'
  | 'utensils'
  | 'pawprint'
  | 'satellite'
  | 'camera'
  | 'palette'
  | 'cherry'
  | 'image'
  | 'cube'
  | 'droplet'
  | 'grid'
  | 'file'
  | 'languages'
  | 'brain'
  | 'baby'
  | 'scale'

export interface Persona {
  id: string
  name: string
  description: string
  icon: IconName
  systemPrompt: string
}

export interface ChatSettings {
  systemPrompt: string
  temperature: number
  maxTokens: number
  topP: number
}

export interface ImageSettings {
  size: '1024x1024' | '1024x1792' | '1792x1024' | '512x512'
  /** aesthetic style hint injected into the prompt */
  style: 'none' | 'photorealistic' | 'digital-art' | 'anime' | 'oil-painting' | '3d-render' | 'watercolor' | 'pixel-art'
  /** extra negative-style modifier appended to the prompt */
  highQuality: boolean
}

export const DEFAULT_PERSONAS: Persona[] = [
  {
    id: 'default',
    name: 'ZeroX Assistant',
    description: 'Helpful general-purpose assistant',
    icon: 'sparkles',
    systemPrompt:
      'You are zeroX ai, a helpful, friendly and concise AI assistant. Answer clearly and use Markdown formatting (headings, lists, code blocks) where useful. Be honest when you do not know something.',
  },
  {
    id: 'coder',
    name: 'Code Companion',
    description: 'Senior engineer that ships clean code',
    icon: 'code',
    systemPrompt:
      'You are a senior software engineer. Write clean, idiomatic, well-tested code. Explain your reasoning briefly, then provide the code in fenced code blocks with the correct language tag. Mention edge cases and trade-offs.',
  },
  {
    id: 'writer',
    name: 'Creative Writer',
    description: 'Vivid storytelling and polished prose',
    icon: 'pen',
    systemPrompt:
      'You are an imaginative creative writer. Craft vivid, engaging prose with strong rhythm and concrete imagery. Adapt tone to the user request — playful, lyrical, or dramatic — and keep the reader hooked.',
  },
  {
    id: 'tutor',
    name: 'Patient Tutor',
    description: 'Explains concepts step by step',
    icon: 'graduation',
    systemPrompt:
      'You are a patient tutor. Break concepts into small steps, use analogies and examples, and check understanding by asking the occasional guiding question. Never make the learner feel bad for not knowing.',
  },
  {
    id: 'analyst',
    name: 'Business Analyst',
    description: 'Structured, data-driven reasoning',
    icon: 'chart',
    systemPrompt:
      'You are a sharp business analyst. Be structured, concise, and data-driven. Use tables, bullet points, and clear headings. Highlight risks, assumptions, and next steps. Avoid fluff.',
  },
]

export const SUGGESTED_PROMPTS: { title: string; subtitle: string; prompt: string; icon: IconName }[] = [
  {
    icon: 'lightbulb',
    title: 'Explain a concept',
    subtitle: 'Make quantum computing simple',
    prompt: 'Explain quantum computing to me like I am a curious high-school student. Use an everyday analogy and a clear example.',
  },
  {
    icon: 'rocket',
    title: 'Draft a pitch',
    subtitle: 'Startup elevator pitch in 60s',
    prompt: 'Help me write a 60-second elevator pitch for a startup that uses AI to optimize last-mile delivery for small e-commerce shops.',
  },
  {
    icon: 'bug',
    title: 'Debug my code',
    subtitle: 'Find the bug in a snippet',
    prompt: 'I have a Python function that should return the n-th Fibonacci number but it is very slow. Here it is:\n\n```python\ndef fib(n):\n    if n < 2: return n\n    return fib(n-1) + fib(n-2)\n```\n\nWhy is it slow and how can I fix it?',
  },
  {
    icon: 'mail',
    title: 'Polish my writing',
    subtitle: 'Make it crisp and pro',
    prompt: 'Polish this email to make it more concise and professional while keeping the friendly tone:\n\n"Hey team, just wanted to let you know that the project is kinda delayed a bit because of some issues we ran into with the API. Let me know if you have questions."',
  },
  {
    icon: 'chef-hat',
    title: 'Plan a meal',
    subtitle: 'Quick weeknight dinner',
    prompt: 'Suggest a 30-minute weeknight dinner I can cook with chicken thighs, garlic, lemon, and pasta. Give me the recipe in clear numbered steps.',
  },
  {
    icon: 'map',
    title: 'Plan a trip',
    subtitle: '3-day Kyoto itinerary',
    prompt: 'Plan a 3-day Kyoto itinerary for a first-time visitor who loves food and quiet temples. Include morning, afternoon, and evening blocks.',
  },
]

export const DEFAULT_SETTINGS: ChatSettings = {
  systemPrompt: DEFAULT_PERSONAS[0].systemPrompt,
  temperature: 0.7,
  maxTokens: 2048,
  topP: 1,
}

/* ----------------------------------------------------------------------------
 * Chat model registry
 * Each entry maps to a model id hosted on Groq. Only models that the user's
 * API key has access to will actually work at runtime; we expose all of them
 * in the picker and surface a friendly error if the model is unavailable.
 * -------------------------------------------------------------------------- */
export interface ChatModel {
  id: string
  /** Short display name (shown in compact dropdowns) */
  name: string
  /** Provider / family label */
  provider: string
  description: string
  /** Whether this is a classifier / guardrail model (changes default UI copy) */
  kind?: 'chat' | 'classifier'
  /** Recommended max_tokens cap */
  maxTokensCap?: number
  /** Badge shown next to the model name */
  badge?: string
  /**
   * True if this model natively returns reasoning via `delta.reasoning` (OpenRouter
   * reasoning models). When true + thinking enabled, we use the native reasoning
   * stream instead of the <think> tag fallback.
   */
  supportsNativeReasoning?: boolean
}

export const CHAT_MODELS: ChatModel[] = [
  {
    id: 'llama-3.1-8b-instant',
    name: 'Llama 3.1 8B Instant',
    provider: 'Meta · Groq',
    description:
      'Fast, capable 8B model from Meta — optimized for low-latency chat. Great default for everyday tasks.',
    kind: 'chat',
    maxTokensCap: 8192,
    badge: 'Default',
  },
  {
    id: 'openrouter/owl-alpha',
    name: 'Owl Alpha',
    provider: 'ZOO · OpenRouter',
    description:
      'High-performance foundation model for agentic workloads. Natively supports tool use, 1M-token context, and complex instruction execution. Free during preview.',
    kind: 'chat',
    maxTokensCap: 8192,
    badge: 'New',
  },
  {
    id: 'nvidia/nemotron-nano-9b-v2:free',
    name: 'Nemotron Nano 9B',
    provider: 'NVIDIA · OpenRouter',
    description:
      'NVIDIA\'s compact reasoning model — emits native chain-of-thought via delta.reasoning. Free. Best for watching the AI think live.',
    kind: 'chat',
    maxTokensCap: 8192,
    badge: 'Thinks',
    supportsNativeReasoning: true,
  },
  {
    id: 'liquid/lfm-2.5-1.2b-thinking:free',
    name: 'LFM 2.5 Thinking',
    provider: 'LiquidAI · OpenRouter',
    description:
      'Tiny 1.2B model with explicit thinking mode. Streams native reasoning before answering. Free and very fast.',
    kind: 'chat',
    maxTokensCap: 4096,
    badge: 'Thinks',
    supportsNativeReasoning: true,
  },
]

export const DEFAULT_CHAT_MODEL_ID = 'llama-3.1-8b-instant'

export function getChatModel(id: string | undefined | null): ChatModel {
  if (!id) return CHAT_MODELS[0]
  return CHAT_MODELS.find((m) => m.id === id) || CHAT_MODELS[0]
}

export const DEFAULT_IMAGE_SETTINGS: ImageSettings = {
  size: '1024x1024',
  style: 'none',
  highQuality: true,
}

export const IMAGE_STYLE_PRESETS: { id: ImageSettings['style']; label: string; icon: IconName; suffix: string }[] = [
  { id: 'none', label: 'Default', icon: 'sparkles', suffix: '' },
  { id: 'photorealistic', label: 'Photoreal', icon: 'camera', suffix: ', photorealistic, ultra-detailed, 50mm, soft natural lighting, 8k' },
  { id: 'digital-art', label: 'Digital Art', icon: 'palette', suffix: ', digital art, trending on artstation, vibrant, detailed' },
  { id: 'anime', label: 'Anime', icon: 'cherry', suffix: ', anime style, studio ghibli inspired, soft colors, detailed line art' },
  { id: 'oil-painting', label: 'Oil Paint', icon: 'image', suffix: ', oil painting, thick brush strokes, classical composition' },
  { id: '3d-render', label: '3D Render', icon: 'cube', suffix: ', 3d render, octane, cinema4d, soft studio lighting, subsurface scattering' },
  { id: 'watercolor', label: 'Watercolor', icon: 'droplet', suffix: ', watercolor painting, soft washes, paper texture, loose brushwork' },
  { id: 'pixel-art', label: 'Pixel Art', icon: 'grid', suffix: ', pixel art, 32-bit, crisp pixels, limited palette' },
]

export const SUGGESTED_IMAGE_PROMPTS: { title: string; subtitle: string; prompt: string; icon: IconName }[] = [
  {
    icon: 'bot',
    title: 'Cute character',
    subtitle: 'Robot watering a flower',
    prompt: 'A tiny friendly robot watering a glowing flower in a sunlit garden, soft pastel colors, charming, detailed illustration',
  },
  {
    icon: 'city',
    title: 'Cinematic scene',
    subtitle: 'Neon city at night',
    prompt: 'A neon-lit futuristic city street at night, reflections on wet asphalt, lone figure with umbrella, cinematic wide shot, moody atmosphere',
  },
  {
    icon: 'mountain',
    title: 'Landscape',
    subtitle: 'Floating islands',
    prompt: 'Floating islands above a sea of clouds at golden hour, waterfalls cascading into the sky, epic fantasy landscape, painterly',
  },
  {
    icon: 'utensils',
    title: 'Food photo',
    subtitle: 'Gourmet burger',
    prompt: 'A gourmet cheeseburger with melted gruyere, caramelized onions, and crispy lettuce on a toasted brioche bun, studio food photography, shallow depth of field',
  },
  {
    icon: 'pawprint',
    title: 'Animal portrait',
    subtitle: 'Fox in autumn forest',
    prompt: 'A red fox sitting in an autumn forest with golden leaves, soft morning light, sharp focus on the fox, blurred background',
  },
  {
    icon: 'satellite',
    title: 'Sci-fi concept',
    subtitle: 'Deep-space station',
    prompt: 'A sleek space station orbiting a gas giant, large observation window, lone astronaut looking out, sci-fi concept art, dramatic lighting',
  },
]
