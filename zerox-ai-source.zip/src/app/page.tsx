'use client'

import * as React from 'react'
import { PanelLeftOpen, Trash2, Palette, Brain } from 'lucide-react'
import { useChatStore } from '@/lib/store'
import { useChat } from '@/lib/use-chat'
import { useImage } from '@/lib/use-image'
import { Sidebar } from '@/components/chat/sidebar'
import { ChatInput } from '@/components/chat/chat-input'
import { MessageItem } from '@/components/chat/message-item'
import { ImageMessageItem } from '@/components/chat/image-message-item'
import { Welcome } from '@/components/chat/welcome'
import { ImageWelcome } from '@/components/chat/image-welcome'
import { ThinkingWelcome } from '@/components/chat/thinking-welcome'
import { ImageInput } from '@/components/chat/image-input'
import { ThemeToggle } from '@/components/chat/theme-toggle'
import { ModeSwitch } from '@/components/chat/mode-switch'
import { ModelSelector } from '@/components/chat/model-selector'
import { ThinkingModelSelector } from '@/components/chat/thinking-model-selector'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent } from '@/components/ui/sheet'
import { DEFAULT_PERSONAS, getChatModel } from '@/lib/types'
import { getIcon } from '@/lib/icon-registry'
import { cn } from '@/lib/utils'

export default function Home() {
  const conversations = useChatStore((s) => s.conversations)
  const activeId = useChatStore((s) => s.activeId)
  const newConversation = useChatStore((s) => s.newConversation)
  const setActive = useChatStore((s) => s.setActive)
  const activePersonaId = useChatStore((s) => s.activePersonaId)
  const deleteMessage = useChatStore((s) => s.deleteMessage)
  const updateMessage = useChatStore((s) => s.updateMessage)
  const setMode = useChatStore((s) => s.setMode)
  const selectedChatModelId = useChatStore((s) => s.selectedChatModelId)

  const [mobileOpen, setMobileOpen] = React.useState(false)
  const [hydrated, setHydrated] = React.useState(false)
  const scrollRef = React.useRef<HTMLDivElement>(null)
  const [autoStick, setAutoStick] = React.useState(true)

  React.useEffect(() => {
    setHydrated(true)
  }, [])

  React.useEffect(() => {
    if (!hydrated) return
    if (!activeId && conversations.length > 0) {
      setActive(conversations[0].id)
    }
  }, [hydrated, activeId, conversations, setActive])

  const conv = conversations.find((c) => c.id === activeId) || null
  const convMode = conv?.mode || 'chat'
  const chat = useChat({ conversationId: conv?.id || '' })
  const image = useImage({ conversationId: conv?.id || '' })

  React.useEffect(() => {
    if (!scrollRef.current || !autoStick) return
    scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [conv?.messages, autoStick])

  const onScroll = () => {
    const el = scrollRef.current
    if (!el) return
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80
    setAutoStick(nearBottom)
  }

  /* ---- Chat send ---- */
  const handleSend = React.useCallback((text: string) => {
    if (!conv) {
      const id = newConversation(undefined, 'chat')
      setTimeout(() => {
        const store = useChatStore
        store.getState().addMessage(id, { role: 'user', content: text })
        // Re-fetch state AFTER addMessage so we see the new user message.
        const conv0 = store.getState().conversations.find((c) => c.id === id)
        const history = (conv0?.messages || [])
          .filter((m) => m.role !== 'system' && !m.error && m.content.trim().length > 0)
          .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }))
        chat.runStream(id, history, { userText: text })
      }, 0)
      return
    }
    chat.send(text)
  }, [conv, newConversation, chat])

  /* ---- Image generate ---- */
  const handleGenerate = (text: string) => {
    if (!conv) {
      const id = newConversation(undefined, 'image')
      setTimeout(() => {
        image.runGenerate(id, text)
      }, 0)
      return
    }
    image.generate(text)
  }

  /* ---- Mode switch starts a new conversation in the chosen mode ---- */
  const handleModeSwitch = (mode: 'chat' | 'image') => {
    setMode(mode)
    // ModeSwitch already calls newConversation() — we just sync global mode here
  }

  const persona = DEFAULT_PERSONAS.find((p) => p.id === activePersonaId) || DEFAULT_PERSONAS[0]
  const chatModel = getChatModel(selectedChatModelId)
  const thinkingModelId = useChatStore((s) => s.thinkingModelId)
  const thinkingModel = getChatModel(thinkingModelId)
  const PersonaIcon = getIcon(persona.icon)
  const isImageMode = convMode === 'image'
  const isThinkingMode = convMode === 'thinking'
  const isBusy = isImageMode ? image.isGenerating : chat.isStreaming

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-sidebar-border/60 md:block">
        <Sidebar />
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-64 p-0">
          <Sidebar isMobile onClose={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main */}
      <main className="flex min-w-0 flex-1 flex-col">
        {/* Top bar — slim, refined */}
        <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border/60 bg-background/70 px-3 backdrop-blur-md sm:px-4">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 md:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <PanelLeftOpen size={16} />
          </Button>

          <div className="flex min-w-0 flex-1 items-center gap-2">
            <span
              className={cn(
                'flex h-6 w-6 items-center justify-center',
                isImageMode
                  ? 'text-fuchsia-500'
                  : isThinkingMode
                    ? 'text-violet-500'
                    : 'text-primary',
              )}
            >
              {isImageMode ? (
                <Palette size={15} />
              ) : isThinkingMode ? (
                <Brain size={15} />
              ) : (
                <PersonaIcon size={15} />
              )}
            </span>
            <div className="flex min-w-0 flex-col leading-tight">
              <span className="truncate text-[13px] font-semibold tracking-tight">
                {conv?.title ||
                  (isImageMode
                    ? 'Image studio'
                    : isThinkingMode
                      ? 'Thinking mode'
                      : 'zeroX ai')}
              </span>
              <span
                className={cn(
                  'truncate text-[10px] text-muted-foreground',
                  isThinkingMode && 'text-violet-600 dark:text-violet-400',
                )}
              >
                {isImageMode
                  ? 'agnes-image-2.1-flash · Agnes AI'
                  : isThinkingMode
                    ? `${thinkingModel.name} · native reasoning`
                    : `${persona.name} · ${chatModel.name}`}
              </span>
            </div>
          </div>

          {/* Model selector — chat mode shows all models, thinking mode shows only reasoning models */}
          {isThinkingMode ? (
            <ThinkingModelSelector className="hidden sm:inline-flex" />
          ) : !isImageMode ? (
            <ModelSelector className="hidden sm:inline-flex" />
          ) : null}

          <ModeSwitch
            currentMode={convMode}
            onSwitch={handleModeSwitch}
            className="hidden sm:inline-flex"
          />

          {conv && conv.messages.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="hidden gap-1 text-[11px] text-muted-foreground hover:text-foreground sm:inline-flex"
              onClick={() => {
                if (confirm('Clear all messages in this chat?')) {
                  const msgs = conv.messages.map((m) => m.id)
                  for (const id of msgs) deleteMessage(conv.id, id)
                }
              }}
            >
              <Trash2 size={12} /> Clear
            </Button>
          )}
          <ThemeToggle />
        </header>

        {/* Mobile mode switch row */}
        <div className="flex items-center justify-center gap-2 border-b border-border bg-background/50 py-2 sm:hidden">
          <ModeSwitch currentMode={convMode} onSwitch={handleModeSwitch} />
          {isThinkingMode ? (
            <ThinkingModelSelector />
          ) : !isImageMode ? (
            <ModelSelector />
          ) : null}
        </div>

        {/* Messages */}
        <div ref={scrollRef} onScroll={onScroll} className="scrollbar-thin flex-1 overflow-y-auto">
          {!conv || conv.messages.length === 0 ? (
            isImageMode ? (
              <ImageWelcome onPick={handleGenerate} />
            ) : isThinkingMode ? (
              <ThinkingWelcome onPick={handleSend} />
            ) : (
              <Welcome onPick={handleSend} />
            )
          ) : (
            <div className="mx-auto max-w-3xl space-y-1 pb-6">
              {conv.messages.map((m, idx) => {
                const isLastAssistant =
                  idx === conv.messages.length - 1 && m.role === 'assistant'
                if (m.kind === 'image') {
                  return (
                    <ImageMessageItem
                      key={m.id}
                      message={m}
                      isLast={isLastAssistant}
                      onRegenerate={image.regenerate}
                      onDelete={() => deleteMessage(conv.id, m.id)}
                      disabled={isBusy}
                    />
                  )
                }
                return (
                  <MessageItem
                    key={m.id}
                    message={m}
                    isLast={isLastAssistant}
                    onRegenerate={chat.regenerate}
                    onEdit={(newContent) => chat.editUserMessage(m.id, newContent)}
                    onDelete={() => deleteMessage(conv.id, m.id)}
                    onFeedback={(f) =>
                      updateMessage(conv.id, m.id, { feedback: f })
                    }
                    onRetry={chat.regenerate}
                    disabled={isBusy}
                  />
                )
              })}
            </div>
          )}
        </div>

        {/* Input */}
        {isImageMode ? (
          <ImageInput
            onGenerate={handleGenerate}
            onStop={image.stop}
            isGenerating={image.isGenerating}
            placeholder={
              conv ? 'Describe the image you want to create…' : 'Describe an image to start a new image session…'
            }
          />
        ) : (
          <ChatInput
            onSend={handleSend}
            onStop={chat.stop}
            isStreaming={chat.isStreaming}
            forceThinking={isThinkingMode}
            placeholder={
              isThinkingMode
                ? conv
                  ? 'Ask the AI to reason through a problem…'
                  : 'Ask a question — the AI will think out loud before answering…'
                : conv
                  ? 'Message zeroX ai…'
                  : 'Send your first message to start a new chat…'
            }
          />
        )}
      </main>
    </div>
  )
}
