import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'
export const maxDuration = 60

export interface ImageRequestBody {
  prompt: string
  size?: '1024x1024' | '1024x1792' | '1792x1024' | '512x512'
  n?: number
}

const API_KEY = process.env.AGNES_API_KEY || ''
const BASE_URL = process.env.AGNES_BASE_URL || 'https://apihub.agnes-ai.com/v1'
const MODEL = process.env.AGNES_IMAGE_MODEL || 'agnes-image-2.1-flash'

export async function POST(req: NextRequest) {
  let body: ImageRequestBody
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const prompt = (body.prompt || '').trim()
  if (!prompt) {
    return NextResponse.json({ error: 'prompt is required' }, { status: 400 })
  }

  if (!API_KEY) {
    return NextResponse.json(
      { error: 'AGNES_API_KEY is not configured on the server.' },
      { status: 500 },
    )
  }

  const size = body.size || '1024x1024'
  const n = Math.min(Math.max(body.n || 1, 1), 1) // Agnes currently returns 1 image per call

  try {
    const res = await fetch(`${BASE_URL}/images/generations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        model: MODEL,
        prompt,
        n,
        size,
      }),
    })

    const raw = await res.text()
    if (!res.ok) {
      let msg = `Agnes API error (${res.status})`
      try {
        const j = JSON.parse(raw)
        msg = j.error?.message || j.error || msg
      } catch {
        msg = raw || msg
      }
      return NextResponse.json({ error: msg }, { status: res.status })
    }

    let json: any
    try {
      json = JSON.parse(raw)
    } catch {
      return NextResponse.json({ error: 'Malformed response from Agnes' }, { status: 502 })
    }

    const images = (json?.data || [])
      .map((d: any) => ({
        url: d.url || (d.b64_json ? `data:image/png;base64,${d.b64_json}` : null),
        revisedPrompt: d.revised_prompt ?? null,
        size,
      }))
      .filter((d: any) => d.url)

    if (images.length === 0) {
      return NextResponse.json({ error: 'No image returned by Agnes' }, { status: 502 })
    }

    return NextResponse.json({ images, model: MODEL, prompt })
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Failed to call Agnes' },
      { status: 500 },
    )
  }
}
