import { NextResponse } from 'next/server'

export const runtime = 'edge'

export async function GET() {
  return NextResponse.json({
    models: [
      {
        id: 'llama-3.1-8b-instant',
        name: 'Llama 3.1 8B Instant',
        provider: 'Groq',
        description: 'Fast, capable 8B model from Meta — optimized for low-latency chat.',
        contextWindow: 131072,
      },
    ],
    default: 'llama-3.1-8b-instant',
  })
}
