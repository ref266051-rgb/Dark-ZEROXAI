import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'
export const maxDuration = 20

export interface SearchResult {
  title: string
  url: string
  snippet: string
}

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36'

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/<[^>]*>/g, '')
    .trim()
}

function decodeUddg(href: string): string {
  try {
    const u = new URL(href.startsWith('//') ? `https:${href}` : href)
    const uddg = u.searchParams.get('uddg')
    if (uddg) return decodeURIComponent(uddg)
    return href
  } catch {
    return href
  }
}

async function searchHtml(query: string, limit = 6): Promise<SearchResult[]> {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}&kl=wt-wt`
  const res = await fetch(url, {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'text/html,application/xhtml+xml',
      'Accept-Language': 'en-US,en;q=0.9',
    },
  })
  if (!res.ok) throw new Error(`DDG HTML ${res.status}`)
  const html = await res.text()
  if (html.includes('anomaly-modal') || html.length < 5000) {
    throw new Error('DDG challenge page')
  }
  const results: SearchResult[] = []
  const re =
    /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]*class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>)?/g
  let m: RegExpExecArray | null
  while ((m = re.exec(html)) !== null && results.length < limit) {
    const rawHref = m[1]
    const title = decodeEntities(m[2])
    const snippet = decodeEntities(m[3] || '')
    const u = decodeUddg(rawHref)
    if (title && u && !u.startsWith('javascript:')) {
      results.push({ title, url: u, snippet })
    }
  }
  return results
}

interface IaJson {
  Abstract?: string
  AbstractURL?: string
  Heading?: string
  RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>
}

async function searchIa(
  query: string,
  limit = 5,
): Promise<{ abstract?: string; abstractUrl?: string; results: SearchResult[] }> {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
  const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } })
  if (!res.ok) throw new Error(`DDG IA ${res.status}`)
  const json = (await res.json()) as IaJson
  const results: SearchResult[] = []
  if (json.Abstract && json.AbstractURL) {
    results.push({ title: json.Heading || query, url: json.AbstractURL, snippet: json.Abstract })
  }
  if (Array.isArray(json.RelatedTopics)) {
    for (const t of json.RelatedTopics) {
      if (results.length >= limit) break
      if (t.Text && t.FirstURL) {
        results.push({
          title: t.Text.split(' - ')[0] || t.Text.slice(0, 80),
          url: t.FirstURL,
          snippet: t.Text,
        })
      }
    }
  }
  return { abstract: json.Abstract || undefined, abstractUrl: json.AbstractURL || undefined, results }
}

async function searchWikipedia(query: string, limit = 5): Promise<SearchResult[]> {
  const url = `https://en.wikipedia.org/w/rest.php/v1/search/page?q=${encodeURIComponent(query)}&limit=${limit}`
  const res = await fetch(url, { headers: { Accept: 'application/json' } })
  if (!res.ok) throw new Error(`Wikipedia ${res.status}`)
  const json = (await res.json()) as {
    pages?: Array<{ title: string; key: string; excerpt?: string; description?: string }>
  }
  if (!json.pages) return []
  return json.pages.map((p) => ({
    title: p.title,
    url: `https://en.wikipedia.org/wiki/${encodeURIComponent(p.key.replace(/ /g, '_'))}`,
    snippet: (p.excerpt || p.description || '').replace(/<[^>]*>/g, '').trim(),
  }))
}

export async function POST(req: NextRequest) {
  let body: { query?: string; limit?: number }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }
  const query = (body.query || '').trim()
  if (!query) return NextResponse.json({ error: 'query is required' }, { status: 400 })
  const limit = Math.min(Math.max(body.limit || 6, 1), 10)

  const start = Date.now()
  const [htmlR, iaR, wikiR] = await Promise.allSettled([
    searchHtml(query, limit),
    searchIa(query, 3),
    searchWikipedia(query, 4),
  ])
  const htmlResults = htmlR.status === 'fulfilled' ? htmlR.value : []
  const ia = iaR.status === 'fulfilled' ? iaR.value : { results: [] }
  const wiki = wikiR.status === 'fulfilled' ? wikiR.value : []

  const seen = new Set<string>()
  const combined: SearchResult[] = []
  const backendsHit: string[] = []
  for (const [name, results] of [
    ['ddg-html', htmlResults],
    ['wikipedia', wiki],
    ['ddg-ia', ia.results],
  ] as const) {
    if (results.length > 0) backendsHit.push(name)
    for (const r of results) {
      const key = r.url.toLowerCase().replace(/\/$/, '')
      if (seen.has(key)) continue
      seen.add(key)
      combined.push(r)
      if (combined.length >= limit) break
    }
    if (combined.length >= limit) break
  }

  let source: 'ddg-html' | 'ddg-ia' | 'wikipedia' | 'mixed' | 'none' = 'none'
  if (combined.length > 0) {
    if (backendsHit.length >= 2) source = 'mixed'
    else if (backendsHit[0] === 'ddg-html') source = 'ddg-html'
    else if (backendsHit[0] === 'wikipedia') source = 'wikipedia'
    else if (backendsHit[0] === 'ddg-ia') source = 'ddg-ia'
  }

  return NextResponse.json({
    query,
    results: combined,
    source,
    abstract: ia.abstract,
    abstractUrl: ia.abstractUrl,
    tookMs: Date.now() - start,
    backendsHit,
  })
}

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')
  if (!q) return NextResponse.json({ error: 'q is required' }, { status: 400 })
  // Reuse POST logic by calling helpers directly.
  const limit = Math.min(Math.max(Number(req.nextUrl.searchParams.get('limit') || '6'), 1), 10)
  const start = Date.now()
  const [htmlR, iaR, wikiR] = await Promise.allSettled([
    searchHtml(q, limit),
    searchIa(q, 3),
    searchWikipedia(q, 4),
  ])
  const htmlResults = htmlR.status === 'fulfilled' ? htmlR.value : []
  const ia = iaR.status === 'fulfilled' ? iaR.value : { results: [] }
  const wiki = wikiR.status === 'fulfilled' ? wikiR.value : []
  const seen = new Set<string>()
  const combined: SearchResult[] = []
  const backendsHit: string[] = []
  for (const [name, results] of [
    ['ddg-html', htmlResults],
    ['wikipedia', wiki],
    ['ddg-ia', ia.results],
  ] as const) {
    if (results.length > 0) backendsHit.push(name)
    for (const r of results) {
      const key = r.url.toLowerCase().replace(/\/$/, '')
      if (seen.has(key)) continue
      seen.add(key)
      combined.push(r)
      if (combined.length >= limit) break
    }
    if (combined.length >= limit) break
  }
  let source: 'ddg-html' | 'ddg-ia' | 'wikipedia' | 'mixed' | 'none' = 'none'
  if (combined.length > 0) {
    if (backendsHit.length >= 2) source = 'mixed'
    else if (backendsHit[0] === 'ddg-html') source = 'ddg-html'
    else if (backendsHit[0] === 'wikipedia') source = 'wikipedia'
    else if (backendsHit[0] === 'ddg-ia') source = 'ddg-ia'
  }
  return NextResponse.json({
    query: q,
    results: combined,
    source,
    abstract: ia.abstract,
    abstractUrl: ia.abstractUrl,
    tookMs: Date.now() - start,
    backendsHit,
  })
}
