import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'edge'
export const maxDuration = 60

export interface OpenRouterRequestBody {
  messages: { role: 'user' | 'assistant' | 'system'; content: string }[]
  systemPrompt?: string
  temperature?: number
  maxTokens?: number
  topP?: number
  model?: string
  /** When true, request native reasoning from the model (reasoning.enabled=true). */
  requestNativeReasoning?: boolean
}

const API_KEY = process.env.OPENROUTER_API_KEY || ''
const BASE_URL = process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1'
const DEFAULT_MODEL = process.env.OPENROUTER_MODEL || 'openrouter/owl-alpha'

export async function POST(req: NextRequest) {
  let body: OpenRouterRequestBody
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const { messages, systemPrompt, temperature, maxTokens, topP, model, requestNativeReasoning } = body

  if (!Array.isArray(messages) || messages.length === 0) {
    return NextResponse.json(
      { error: 'messages must be a non-empty array' },
      { status: 400 },
    )
  }

  if (!API_KEY) {
    return NextResponse.json(
      { error: 'OPENROUTER_API_KEY is not configured on the server.' },
      { status: 500 },
    )
  }

  const finalMessages = [
    ...(systemPrompt ? [{ role: 'system' as const, content: systemPrompt }] : []),
    ...messages.map((m) => ({ role: m.role, content: m.content })),
  ]

  const orRes = await fetch(`${BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
      // Optional but recommended by OpenRouter for analytics + ranking.
      'HTTP-Referer': 'https://zerox-ai.app',
      'X-Title': 'zeroX ai',
    },
    body: JSON.stringify({
      model: model || DEFAULT_MODEL,
      messages: finalMessages,
      temperature: typeof temperature === 'number' ? temperature : 0.7,
      max_tokens: typeof maxTokens === 'number' ? maxTokens : 2048,
      top_p: typeof topP === 'number' ? topP : 1,
      stream: true,
      ...(requestNativeReasoning
        ? {
            reasoning: {
              enabled: true,
              max_tokens: Math.min(2048, Math.max(512, typeof maxTokens === 'number' ? maxTokens : 2048)),
            },
          }
        : {}),
    }),
  })

  if (!orRes.ok || !orRes.body) {
    const text = await orRes.text().catch(() => '')
    const responseHeaders: Record<string, string> = { 'Content-Type': 'application/json' }
    const retryAfter = orRes.headers.get('retry-after')
    if (retryAfter) responseHeaders['retry-after'] = retryAfter
    return new Response(
      JSON.stringify({
        error: `OpenRouter API error (${orRes.status}): ${text || orRes.statusText}`,
      }),
      { status: orRes.status, headers: responseHeaders },
    )
  }

  // OpenRouter streams OpenAI-compatible SSE, but interleaves comment lines
  // (`: OPENROUTER PROCESSING`) while warming up. We pass the stream through
  // unchanged — the client parser already skips lines that don't start with
  // `data:`.
  const encoder = new TextEncoder()
  const decoder = new TextDecoder()

  const stream = new ReadableStream({
    async start(controller) {
      const reader = orRes.body!.getReader()
      let buffer = ''
      try {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          const chunk = decoder.decode(value, { stream: true })
          // Forward as-is. The client parser handles `:` comment lines and
          // `data:` event lines uniformly.
          controller.enqueue(encoder.encode(chunk))
          buffer = chunk // keep ref to satisfy TS unused-var check
        }
        controller.close()
      } catch (err) {
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({
              error: err instanceof Error ? err.message : 'Stream error',
            })}\n\n`,
          ),
        )
        controller.close()
      }
    },
    cancel() {
      // upstream reader is GC'd
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  })
}
