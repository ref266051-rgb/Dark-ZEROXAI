import { NextRequest } from 'next/server'

export const runtime = 'edge'

export interface ChatRequestBody {
  messages: { role: 'user' | 'assistant' | 'system'; content: string }[]
  systemPrompt?: string
  temperature?: number
  maxTokens?: number
  topP?: number
  model?: string
}

const DEFAULT_MODEL = process.env.GROQ_MODEL || 'llama-3.1-8b-instant'
const API_KEY = process.env.GROQ_API_KEY || ''

export async function POST(req: NextRequest) {
  let body: ChatRequestBody
  try {
    body = await req.json()
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  const { messages, systemPrompt, temperature, maxTokens, topP, model } = body

  if (!Array.isArray(messages) || messages.length === 0) {
    return new Response(JSON.stringify({ error: 'messages must be a non-empty array' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  if (!API_KEY) {
    return new Response(
      JSON.stringify({ error: 'GROQ_API_KEY is not configured on the server.' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } },
    )
  }

  const finalMessages = [
    ...(systemPrompt ? [{ role: 'system' as const, content: systemPrompt }] : []),
    ...messages.map((m) => ({ role: m.role, content: m.content })),
  ]

  const groqRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
    },
    body: JSON.stringify({
      model: model || DEFAULT_MODEL,
      messages: finalMessages,
      temperature: typeof temperature === 'number' ? temperature : 0.7,
      max_tokens: typeof maxTokens === 'number' ? maxTokens : 2048,
      top_p: typeof topP === 'number' ? topP : 1,
      stream: true,
    }),
  })

  if (!groqRes.ok || !groqRes.body) {
    const text = await groqRes.text().catch(() => '')
    // Forward rate-limit headers so the client can show a countdown.
    const responseHeaders: Record<string, string> = { 'Content-Type': 'application/json' }
    const retryAfter = groqRes.headers.get('retry-after')
    if (retryAfter) responseHeaders['retry-after'] = retryAfter
    return new Response(
      JSON.stringify({
        error: `Groq API error (${groqRes.status}): ${text || groqRes.statusText}`,
      }),
      { status: groqRes.status, headers: responseHeaders },
    )
  }

  const encoder = new TextEncoder()
  const decoder = new TextDecoder()

  const stream = new ReadableStream({
    async start(controller) {
      const reader = groqRes.body!.getReader()
      let buffer = ''

      try {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })

          const lines = buffer.split('\n')
          buffer = lines.pop() || ''

          for (const raw of lines) {
            const line = raw.trim()
            if (!line || !line.startsWith('data:')) continue
            const data = line.slice(5).trim()
            if (data === '[DONE]') {
              controller.close()
              return
            }
            try {
              const json = JSON.parse(data)
              const delta = json?.choices?.[0]?.delta?.content
              if (delta) {
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta })}\n\n`))
              }
              if (json?.choices?.[0]?.finish_reason) {
                controller.enqueue(
                  encoder.encode(
                    `data: ${JSON.stringify({ finish: json.choices[0].finish_reason })}\n\n`,
                  ),
                )
              }
            } catch {
              // ignore malformed chunks
            }
          }
        }
        controller.close()
      } catch (err) {
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ error: err instanceof Error ? err.message : 'Stream error' })}\n\n`,
          ),
        )
        controller.close()
      }
    },
    cancel() {
      // upstream reader is GC'd; Groq connection will close
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
    },
  })
}
