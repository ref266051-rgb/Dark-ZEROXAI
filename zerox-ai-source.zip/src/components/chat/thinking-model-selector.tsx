'use client'

import * as React from 'react'
import { ChevronDown, Check, Brain, Zap, Cpu } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { useChatStore } from '@/lib/store'
import { CHAT_MODELS, getChatModel } from '@/lib/types'

interface ThinkingModelSelectorProps {
  className?: string
}

/**
 * Model picker for Thinking mode. Only shows models that support native
 * reasoning (`supportsNativeReasoning: true`). Separate from the regular
 * ModelSelector which shows all chat models.
 */
export function ThinkingModelSelector({ className }: ThinkingModelSelectorProps) {
  const selectedId = useChatStore((s) => s.thinkingModelId)
  const setSelected = useChatStore((s) => s.setThinkingModelId)
  const current = getChatModel(selectedId)

  // Filter to only native reasoning models
  const thinkingModels = CHAT_MODELS.filter((m) => m.supportsNativeReasoning)

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn(
            'h-7 gap-1.5 rounded-full border-violet-400/40 bg-violet-500/5 px-2.5 text-[11px] font-medium text-violet-700 hover:bg-violet-500/10 hover:text-violet-700 dark:text-violet-300',
            className,
          )}
          aria-label="Select thinking model"
        >
          <Brain size={12} className="text-violet-500" />
          <span className="max-w-[100px] truncate sm:max-w-[140px]">{current.name}</span>
          <ChevronDown size={11} className="opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72">
        <div className="flex items-center gap-1.5 px-2 py-1.5 text-[10px] font-medium uppercase tracking-wide text-violet-600 dark:text-violet-400">
          <Brain size={10} />
          Thinking models · native reasoning
        </div>
        {thinkingModels.map((m) => {
          const active = m.id === selectedId
          return (
            <DropdownMenuItem
              key={m.id}
              onClick={() => setSelected(m.id)}
              className="flex flex-col items-start gap-1 py-2"
            >
              <div className="flex w-full items-center gap-2">
                <Zap size={13} className="text-violet-500" />
                <span className="text-[13px] font-medium">{m.name}</span>
                {m.badge && (
                  <Badge
                    variant="secondary"
                    className="ml-auto bg-violet-500/10 text-[10px] text-violet-600 dark:text-violet-400"
                  >
                    {m.badge}
                  </Badge>
                )}
                {active && <Check size={13} className="ml-1 text-violet-500" />}
              </div>
              <p className="text-[11px] leading-relaxed text-muted-foreground">{m.description}</p>
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-muted-foreground/70">{m.id}</span>
                <span className="text-[10px] text-muted-foreground/60">· {m.provider}</span>
              </div>
            </DropdownMenuItem>
          )
        })}
        <div className="border-t border-border px-2 py-1.5 text-[10px] text-muted-foreground">
          These models stream their chain-of-thought live via{' '}
          <code className="font-mono">delta.reasoning</code>.
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
