'use client'

import * as React from 'react'
import ReactMarkdown from 'react-markdown'
import { Check, Copy } from 'lucide-react'

interface MarkdownProps {
  content: string
}

export function Markdown({ content }: MarkdownProps) {
  return (
    <div className="prose-zx">
      <ReactMarkdown
        components={{
          code({ node, className, children, ...props }) {
            const isInline = !className?.includes('language-')
            const text = String(children).replace(/\n$/, '')
            if (isInline) {
              return (
                <code className={className} {...props}>
                  {children}
                </code>
              )
            }
            return <CodeBlock language={extractLang(className)} code={text} />
          },
          pre({ children }) {
            return <>{children}</>
          },
          a({ children, href }) {
            return (
              <a href={href} target="_blank" rel="noopener noreferrer">
                {children}
              </a>
            )
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  )
}

function extractLang(className?: string) {
  const m = /language-([\w-]+)/.exec(className || '')
  return m ? m[1] : 'text'
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = React.useState(false)
  const onCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }
  return (
    <div className="my-3 overflow-hidden rounded-lg border border-border bg-zinc-950 text-zinc-50 dark:bg-zinc-900/80">
      <div className="flex items-center justify-between border-b border-white/10 bg-white/5 px-3 py-1.5">
        <span className="font-mono text-xs text-zinc-400">{language}</span>
        <button
          onClick={onCopy}
          className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-xs text-zinc-300 transition hover:bg-white/10 hover:text-white"
          aria-label="Copy code"
        >
          {copied ? <Check size={12} /> : <Copy size={12} />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="scrollbar-thin overflow-x-auto p-3 text-[13px] leading-relaxed">
        <code className={`language-${language}`}>{code}</code>
      </pre>
    </div>
  )
}
