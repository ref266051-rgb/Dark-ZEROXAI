'use client'

import * as React from 'react'
import { Download, ExternalLink, RefreshCw, Trash2, AlertTriangle, Sparkles, User, Palette } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { ChatMessage } from '@/lib/types'

interface ImageMessageItemProps {
  message: ChatMessage
  isLast: boolean
  onRegenerate: () => void
  onDelete: () => void
  disabled: boolean
}

/** Build a clean filename slug from a prompt string */
function slugify(s: string, maxLen = 40): string {
  return (
    s
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .trim()
      .replace(/\s+/g, '-')
      .slice(0, maxLen) || 'image'
  )
}

export function ImageMessageItem({
  message,
  isLast,
  onRegenerate,
  onDelete,
  disabled,
}: ImageMessageItemProps) {
  const isUser = message.role === 'user'
  const [lightboxOpen, setLightboxOpen] = React.useState(false)

  const download = async (url: string) => {
    const baseName = slugify(message.imagePrompt || 'image')
    const filename = `zerox-${baseName}-${Date.now()}.png`
    try {
      // Try fetching as blob (works if the host allows CORS)
      const res = await fetch(url, { mode: 'cors' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const blob = await res.blob()
      const blobUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = blobUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(blobUrl)
      toast.success('Image downloaded', { description: filename, duration: 2500 })
    } catch {
      // Fallback 1: try fetch without explicit cors mode (browser default)
      try {
        const res2 = await fetch(url)
        if (!res2.ok) throw new Error(`HTTP ${res2.status}`)
        const blob = await res2.blob()
        const blobUrl = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = blobUrl
        a.download = filename
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(blobUrl)
        toast.success('Image downloaded', { description: filename, duration: 2500 })
        return
      } catch {
        /* fall through */
      }
      // Fallback 2: open in new tab so user can right-click → save
      window.open(url, '_blank', 'noopener,noreferrer')
      toast.info('Opened image in new tab', {
        description: 'Right-click → Save image as… to download.',
        duration: 5000,
      })
    }
  }

  return (
    <div className={cn('group flex gap-3 px-4 py-5 sm:px-6', isUser ? 'bg-background' : 'bg-muted/30')}>
      <div
        className={cn(
          'flex h-8 w-8 shrink-0 items-center justify-center rounded-full shadow-sm',
          isUser
            ? 'bg-secondary text-secondary-foreground'
            : 'bg-gradient-to-br from-fuchsia-500 to-purple-600 text-white',
        )}
      >
        {isUser ? <User size={15} strokeWidth={2.2} /> : <Palette size={15} strokeWidth={2.2} />}
      </div>

      <div className="min-w-0 flex-1">
        <div className="mb-1 flex items-center gap-2">
          <span className="text-sm font-semibold">{isUser ? 'You' : 'zeroX ai'}</span>
          {!isUser && (
            <span className="rounded-full bg-fuchsia-500/10 px-2 py-0.5 text-[10px] font-medium text-fuchsia-600 dark:text-fuchsia-400">
              Image
            </span>
          )}
          {message.generating && (
            <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
              generating…
            </span>
          )}
        </div>

        {/* The prompt text */}
        {message.content && (
          <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
            {message.content}
          </p>
        )}

        {/* Error */}
        {message.error && (
          <div className="mt-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            <div className="flex items-center gap-2 font-medium">
              <AlertTriangle size={14} /> Error
            </div>
            <div className="mt-1 text-destructive/90">{message.error}</div>
          </div>
        )}

        {/* Generating placeholder */}
        {message.generating && !message.error && (
          <div className="mt-2 aspect-square w-full max-w-md overflow-hidden rounded-xl border border-border bg-gradient-to-br from-muted/50 to-muted">
            <div className="flex h-full w-full items-center justify-center">
              <div className="flex flex-col items-center gap-3 text-muted-foreground">
                <div className="relative h-12 w-12">
                  <div className="absolute inset-0 animate-ping rounded-full bg-primary/20" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Sparkles size={22} className="text-primary" />
                  </div>
                </div>
                <p className="text-xs">Painting your image…</p>
                <p className="text-[10px] text-muted-foreground/70">Usually takes 5–15 seconds</p>
              </div>
            </div>
          </div>
        )}

        {/* Generated images */}
        {!message.generating && message.images && message.images.length > 0 && (
          <div className="mt-2 grid gap-3">
            {message.images.map((img, idx) => (
              <div key={idx} className="group/img relative w-full max-w-md overflow-hidden rounded-xl border border-border bg-card">
                <button
                  type="button"
                  onClick={() => setLightboxOpen(true)}
                  className="block w-full cursor-zoom-in"
                  aria-label="Open image full size"
                >
                  { }
                  <img
                    src={img.url}
                    alt={message.imagePrompt || 'Generated image'}
                    className="h-auto w-full"
                    loading="lazy"
                  />
                </button>
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 transition group-hover/img:opacity-100" />
                <div className="absolute bottom-2 right-2 flex gap-1 opacity-0 transition group-hover/img:opacity-100">
                  <Button
                    size="icon"
                    variant="secondary"
                    className="h-8 w-8 rounded-lg bg-black/60 text-white hover:bg-black/80"
                    onClick={(e) => {
                      e.stopPropagation()
                      download(img.url)
                    }}
                    aria-label="Download image"
                  >
                    <Download size={14} />
                  </Button>
                  <Button
                    size="icon"
                    variant="secondary"
                    className="h-8 w-8 rounded-lg bg-black/60 text-white hover:bg-black/80"
                    onClick={(e) => {
                      e.stopPropagation()
                      window.open(img.url, '_blank')
                    }}
                    aria-label="Open in new tab"
                  >
                    <ExternalLink size={14} />
                  </Button>
                </div>
                {img.revisedPrompt && (
                  <p className="border-t border-border bg-muted/30 px-3 py-1.5 text-[11px] text-muted-foreground">
                    {img.revisedPrompt}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Hover actions */}
        {!message.generating && !message.error && (
          <div className="mt-2 flex items-center gap-1 opacity-0 transition group-hover:opacity-100">
            {!isUser && isLast && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1 px-2 text-xs text-muted-foreground"
                onClick={onRegenerate}
                disabled={disabled}
              >
                <RefreshCw size={12} /> Regenerate
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-destructive"
              onClick={onDelete}
              disabled={disabled}
            >
              <Trash2 size={12} /> Delete
            </Button>
          </div>
        )}
      </div>

      {/* Lightbox */}
      {lightboxOpen && message.images && message.images[0] && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setLightboxOpen(false)}
        >
          <button
            type="button"
            className="absolute right-4 top-4 inline-flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            onClick={() => setLightboxOpen(false)}
            aria-label="Close"
          >
            ✕
          </button>
          { }
          <img
            src={message.images[0].url}
            alt={message.imagePrompt || 'Generated image'}
            className="max-h-full max-w-full rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  )
}
