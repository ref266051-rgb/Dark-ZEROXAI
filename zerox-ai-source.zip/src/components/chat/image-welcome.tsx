'use client'

import * as React from 'react'
import { ArrowRight, Palette, Sparkles } from 'lucide-react'
import { SUGGESTED_IMAGE_PROMPTS } from '@/lib/types'
import { getIcon } from '@/lib/icon-registry'
import { cn } from '@/lib/utils'

interface ImageWelcomeProps {
  onPick: (prompt: string) => void
}

export function ImageWelcome({ onPick }: ImageWelcomeProps) {
  return (
    <div className="flex min-h-full flex-col items-center justify-center px-4 py-10 sm:py-16">
      {/* Big hero logo */}
      <div className="relative mb-6">
        <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-fuchsia-400/30 to-purple-500/20 blur-2xl" />
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-fuchsia-500 to-purple-600 shadow-lg shadow-fuchsia-500/25">
          <Palette size={36} className="text-white" strokeWidth={2.2} />
        </div>
      </div>

      {/* Hero headline */}
      <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
        Create with{' '}
        <span className="bg-gradient-to-r from-fuchsia-500 to-purple-500 bg-clip-text text-transparent">
          zeroX ai
        </span>
      </h1>
      <p className="mt-3 max-w-lg text-center text-base text-muted-foreground sm:text-lg">
        Generate stunning images from text prompts. Powered by Agnes AI&apos;s{' '}
        <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">agnes-image-2.1-flash</code>{' '}
        model.
      </p>

      {/* Prompt cards — 2x3 grid */}
      <div className="mt-10 grid w-full max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
        {SUGGESTED_IMAGE_PROMPTS.map((p) => {
          const Icon = getIcon(p.icon)
          return (
            <button
              key={p.title}
              onClick={() => onPick(p.prompt)}
              className={cn(
                'group relative overflow-hidden rounded-xl border border-border bg-card p-4 text-left transition-all',
                'hover:-translate-y-0.5 hover:border-fuchsia-400/40 hover:shadow-md hover:shadow-fuchsia-500/5',
              )}
            >
              <div className="mb-1.5 flex items-center gap-2.5">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-fuchsia-500/10 text-fuchsia-600 transition-colors group-hover:bg-fuchsia-500/15 dark:text-fuchsia-400">
                  <Icon size={16} strokeWidth={2} />
                </span>
                <span className="font-medium text-foreground">{p.title}</span>
                <ArrowRight
                  size={14}
                  className="ml-auto text-muted-foreground opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100"
                />
              </div>
              <p className="pl-[42px] text-sm text-muted-foreground">{p.subtitle}</p>
            </button>
          )
        })}
      </div>

      {/* Footer tips */}
      <div className="mt-10 flex flex-col items-center gap-1.5 text-center">
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <Sparkles size={12} className="text-fuchsia-500" />
          Pick a style (Photoreal, Anime, Oil Paint…) and aspect ratio above the input.
        </span>
        <span className="text-[11px] text-muted-foreground/70">
          Requests go straight from your browser to Agnes AI — no setup needed.
        </span>
      </div>
    </div>
  )
}
