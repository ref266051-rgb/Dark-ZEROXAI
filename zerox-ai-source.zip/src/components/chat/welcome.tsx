'use client'

import * as React from 'react'
import { ArrowRight, Sparkles } from 'lucide-react'
import { SUGGESTED_PROMPTS } from '@/lib/types'
import { getIcon } from '@/lib/icon-registry'
import { cn } from '@/lib/utils'

interface WelcomeProps {
  onPick: (prompt: string) => void
}

export function Welcome({ onPick }: WelcomeProps) {
  return (
    <div className="flex min-h-full flex-col items-center justify-center px-4 py-10 sm:py-16">
      {/* Big hero logo — Lucide Sparkles in a gradient tile */}
      <div className="relative mb-6">
        <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-emerald-400/30 to-teal-500/20 blur-2xl" />
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/25">
          <Sparkles size={36} className="text-white" strokeWidth={2.2} />
        </div>
      </div>

      {/* Hero headline */}
      <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
        Welcome to{' '}
        <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
          zeroX ai
        </span>
      </h1>
      <p className="mt-3 max-w-lg text-center text-base text-muted-foreground sm:text-lg">
        Your fast AI assistant powered by Llama 3.1 8B — with live web search, image generation,
        and slash commands.
      </p>

      {/* Prompt cards — 2x3 grid on desktop, 1 col mobile */}
      <div className="mt-10 grid w-full max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
        {SUGGESTED_PROMPTS.map((p) => {
          const Icon = getIcon(p.icon)
          return (
            <button
              key={p.title}
              onClick={() => onPick(p.prompt)}
              className={cn(
                'group relative overflow-hidden rounded-xl border border-border bg-card p-4 text-left transition-all',
                'hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md hover:shadow-primary/5',
              )}
            >
              <div className="mb-1.5 flex items-center gap-2.5">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary/15">
                  <Icon size={16} strokeWidth={2} />
                </span>
                <span className="font-medium text-foreground">{p.title}</span>
                <ArrowRight
                  size={14}
                  className="ml-auto text-muted-foreground opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100"
                />
              </div>
              <p className="pl-[42px] text-sm text-muted-foreground">{p.subtitle}</p>
            </button>
          )
        })}
      </div>

      {/* Footer tips */}
      <div className="mt-10 flex flex-col items-center gap-1.5 text-center">
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <Sparkles size={12} className="text-primary" />
          Type{' '}
          <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[11px] text-foreground">/</code>{' '}
          in the chat box for quick slash commands.
        </span>
        <span className="text-[11px] text-muted-foreground/70">
          Requests go straight from your browser to Groq using a built-in demo key — no setup
          needed.
        </span>
      </div>
    </div>
  )
}
