'use client'

import * as React from 'react'
import {
  Brain,
  ChevronDown,
  ChevronRight,
  Loader2,
  Clock,
  Zap,
  Check,
  Copy,
  Search,
  Lightbulb,
  Sparkles,
  MessageSquare,
} from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

interface ThinkingBubbleProps {
  thinking: string
  streaming?: boolean
  charCount?: number
  tookMs?: number
  charsPerSec?: number
  wordCount?: number
  /** When true, this is native reasoning from a reasoning model (vs <think> tag fallback) */
  native?: boolean
}

/**
 * Detect what "phase" of thinking the AI is in based on the content streamed so far.
 * Returns a label + icon that updates live as the reasoning grows.
 */
function detectPhase(thinking: string): { label: string; icon: React.ReactNode; phase: number } {
  const t = thinking.toLowerCase()
  const len = thinking.length
  if (len < 80) {
    return { label: 'Analyzing question', icon: <Search size={9} />, phase: 0 }
  }
  if (
    t.includes('plan') ||
    t.includes('approach') ||
    t.includes('strategy') ||
    t.includes("let's think") ||
    t.includes('let me think') ||
    t.includes('step by step') ||
    t.includes('first,') ||
    t.includes('first ')
  ) {
    return { label: 'Forming plan', icon: <Lightbulb size={9} />, phase: 1 }
  }
  if (
    t.includes('but') ||
    t.includes('however') ||
    t.includes('wait') ||
    t.includes('actually') ||
    t.includes('on the other hand') ||
    t.includes('alternatively') ||
    t.includes('hmm')
  ) {
    return { label: 'Considering alternatives', icon: <Sparkles size={9} />, phase: 2 }
  }
  if (
    t.includes('so,') ||
    t.includes('therefore') ||
    t.includes('that means') ||
    t.includes('in conclusion') ||
    t.includes('final answer') ||
    t.includes('the answer is') ||
    t.includes("i'll ") ||
    t.includes('i will ')
  ) {
    return { label: 'Formulating answer', icon: <MessageSquare size={9} />, phase: 3 }
  }
  if (len < 400) {
    return { label: 'Reasoning', icon: <Brain size={9} />, phase: 1 }
  }
  return { label: 'Deliberating', icon: <Brain size={9} />, phase: 2 }
}

export function ThinkingBubble({
  thinking,
  streaming = false,
  charCount,
  tookMs,
  charsPerSec,
  wordCount,
  native = false,
}: ThinkingBubbleProps) {
  const [expanded, setExpanded] = React.useState(true)

  // Auto-collapse when streaming ends (but only if user hasn't manually toggled)
  const userToggledRef = React.useRef(false)
  React.useEffect(() => {
    if (!streaming && !userToggledRef.current) {
      const t = setTimeout(() => setExpanded(false), 800)
      return () => clearTimeout(t)
    }
  }, [streaming])

  const handleToggle = () => {
    userToggledRef.current = true
    setExpanded((v) => !v)
  }

  const onCopy = () => {
    navigator.clipboard.writeText(thinking)
    toast.success('Thinking copied', { duration: 1500 })
  }

  const liveCount = charCount ?? thinking.length
  const phase = detectPhase(thinking)

  // Live chars-per-second (smoothed over a 1s rolling window)
  const [ratePerSec, setRatePerSec] = React.useState<number | null>(null)
  const lastCountRef = React.useRef(0)
  const lastTsRef = React.useRef<number>(Date.now())
  React.useEffect(() => {
    if (!streaming) {
      setRatePerSec(null)
      lastCountRef.current = 0
      lastTsRef.current = Date.now()
      return
    }
    const id = setInterval(() => {
      const now = Date.now()
      const dt = (now - lastTsRef.current) / 1000
      const dCount = liveCount - lastCountRef.current
      if (dt > 0) {
        setRatePerSec(Math.round(dCount / dt))
      }
      lastCountRef.current = liveCount
      lastTsRef.current = now
    }, 1000)
    return () => clearInterval(id)
  }, [streaming, liveCount])

  // Compute words-per-minute for display (live during streaming, final after)
  const effectiveRate = streaming ? ratePerSec : charsPerSec
  const wpm = effectiveRate ? Math.round((effectiveRate / 5)) : null // ~5 chars per word

  return (
    <div className="mb-1.5 overflow-hidden rounded-xl border border-violet-500/25 bg-gradient-to-br from-violet-500/5 to-fuchsia-500/5">
      {/* Header — always visible, click to expand/collapse */}
      <button
        type="button"
        onClick={handleToggle}
        className="flex w-full items-center gap-2 px-3 py-1.5 text-left transition hover:bg-violet-500/5"
        aria-expanded={expanded}
      >
        {/* Animated brain icon — pulses when streaming */}
        <span
          className={cn(
            'relative flex h-5 w-5 shrink-0 items-center justify-center rounded-md transition-colors',
            streaming
              ? 'bg-violet-500/20 text-violet-600 dark:text-violet-400'
              : 'bg-violet-500/15 text-violet-600 dark:text-violet-400',
          )}
        >
          {streaming ? (
            <>
              <span className="absolute inset-0 animate-ping rounded-md bg-violet-500/30" />
              <Brain size={11} strokeWidth={2.4} className="relative" />
            </>
          ) : (
            <Brain size={11} strokeWidth={2.2} />
          )}
        </span>

        {/* Status label — changes with phase */}
        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-violet-700 dark:text-violet-300">
          {streaming ? (
            <>
              <span className="opacity-70">{phase.icon}</span>
              <span>{phase.label}…</span>
            </>
          ) : (
            <span>Thought process</span>
          )}
        </span>

        {/* Native badge */}
        {native && (
          <span className="inline-flex items-center gap-0.5 rounded-full bg-violet-500/15 px-1.5 py-0.5 text-[9px] font-medium text-violet-600 dark:text-violet-400">
            <Zap size={8} /> native
          </span>
        )}

        {/* Live metrics */}
        {streaming ? (
          <>
            <span className="text-[10px] tabular-nums text-muted-foreground">
              {liveCount.toLocaleString()} chars
            </span>
            {wpm !== null && wpm > 0 && (
              <span className="text-[10px] tabular-nums text-muted-foreground/70">
                · {wpm} wpm
              </span>
            )}
            <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-violet-600 dark:text-violet-400">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-violet-500 opacity-75" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-violet-500" />
              </span>
              LIVE
            </span>
          </>
        ) : (
          tookMs !== undefined && (
            <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
              <Check size={9} className="text-emerald-500" />
              <Clock size={9} />
              {(tookMs / 1000).toFixed(1)}s
              {wordCount !== undefined && wordCount > 0 && (
                <span className="opacity-70">· {wordCount} words</span>
              )}
              {wpm !== null && wpm > 0 && (
                <span className="opacity-70">· {wpm} wpm</span>
              )}
            </span>
          )
        )}

        <span className="ml-auto flex items-center gap-1">
          {!streaming && thinking && (
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => {
                e.stopPropagation()
                onCopy()
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.stopPropagation()
                  onCopy()
                }
              }}
              className="inline-flex items-center gap-0.5 rounded px-1 py-0.5 text-[9px] text-muted-foreground/70 transition hover:bg-violet-500/10 hover:text-violet-600 dark:hover:text-violet-400"
              aria-label="Copy thinking"
            >
              <Copy size={9} />
            </span>
          )}
          {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        </span>
      </button>

      {/* Body — collapsible thinking content */}
      {expanded && (
        <div className="border-t border-violet-500/15 bg-background/40 px-3 py-2">
          {thinking ? (
            <div className="relative">
              <pre className="whitespace-pre-wrap break-words font-mono text-[11px] leading-relaxed text-foreground/70">
                {thinking}
                {streaming && (
                  <span className="ml-0.5 inline-block h-3 w-[2px] animate-pulse bg-violet-500 align-middle" />
                )}
              </pre>
              {/* Subtle gradient fade at the bottom while streaming — feels like there's more coming */}
              {streaming && thinking.length > 200 && (
                <div className="pointer-events-none absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-background/80 to-transparent" />
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2 py-1 text-[11px] text-muted-foreground">
              <Loader2 size={11} className="animate-spin text-violet-500" />
              <span>Reasoning will appear here…</span>
            </div>
          )}

          {/* Streaming progress bar — shows live activity */}
          {streaming && (
            <div className="mt-2 flex items-center gap-2">
              <div className="h-0.5 flex-1 overflow-hidden rounded-full bg-violet-500/10">
                <div
                  className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all duration-300"
                  style={{ width: `${Math.min(100, (liveCount / 1000) * 100)}%` }}
                />
              </div>
              <span className="text-[9px] tabular-nums text-muted-foreground/60">
                {Math.min(100, Math.round((liveCount / 1000) * 100))}%
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
