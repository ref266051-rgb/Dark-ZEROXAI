'use client'

import * as React from 'react'
import { BarChart3, MessageSquare, Search, ThumbsUp, ThumbsDown, Image as ImageIcon, Clock, Hash } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useChatStore } from '@/lib/store'
import { cn } from '@/lib/utils'

interface StatsDialogProps {
  open: boolean
  onOpenChange: (o: boolean) => void
}

export function StatsDialog({ open, onOpenChange }: StatsDialogProps) {
  const conversations = useChatStore((s) => s.conversations)

  const stats = React.useMemo(() => {
    let totalMessages = 0
    let userMessages = 0
    let assistantMessages = 0
    let imageMessages = 0
    let searchQueries = 0
    let thumbsUp = 0
    let thumbsDown = 0
    let totalChars = 0
    let oldestTs: number | null = null
    let newestTs: number | null = null
    const modelCounts: Record<string, number> = {}

    for (const c of conversations) {
      for (const m of c.messages) {
        totalMessages++
        if (m.role === 'user') userMessages++
        else assistantMessages++
        if (m.kind === 'image') imageMessages++
        if (m.searchContext) searchQueries++
        if (m.feedback === 'up') thumbsUp++
        if (m.feedback === 'down') thumbsDown++
        totalChars += m.content.length
        if (m.createdAt && (!oldestTs || m.createdAt < oldestTs)) oldestTs = m.createdAt
        if (m.createdAt && (!newestTs || m.createdAt > newestTs)) newestTs = m.createdAt
      }
    }

    const spanDays =
      oldestTs && newestTs
        ? Math.max(1, Math.round((newestTs - oldestTs) / (1000 * 60 * 60 * 24)))
        : 0

    return {
      conversations: conversations.length,
      totalMessages,
      userMessages,
      assistantMessages,
      imageMessages,
      searchQueries,
      thumbsUp,
      thumbsDown,
      totalChars,
      spanDays,
    }
  }, [conversations])

  const cards = [
    { label: 'Conversations', value: stats.conversations, icon: <MessageSquare size={14} />, color: 'text-primary' },
    { label: 'Total messages', value: stats.totalMessages, icon: <Hash size={14} />, color: 'text-blue-500' },
    { label: 'Your messages', value: stats.userMessages, icon: <MessageSquare size={14} />, color: 'text-emerald-500' },
    { label: 'AI replies', value: stats.assistantMessages, icon: <MessageSquare size={14} />, color: 'text-teal-500' },
    { label: 'Images generated', value: stats.imageMessages, icon: <ImageIcon size={14} />, color: 'text-fuchsia-500' },
    { label: 'Web searches', value: stats.searchQueries, icon: <Search size={14} />, color: 'text-amber-500' },
    { label: '👍 Good responses', value: stats.thumbsUp, icon: <ThumbsUp size={14} />, color: 'text-emerald-600' },
    { label: '👎 Bad responses', value: stats.thumbsDown, icon: <ThumbsDown size={14} />, color: 'text-rose-600' },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 size={18} /> Your stats
          </DialogTitle>
          <DialogDescription>
            All-time chat usage on this device. Stored locally — never sent anywhere.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-2">
          {cards.map((c) => (
            <div
              key={c.label}
              className="rounded-lg border border-border bg-card p-3 transition hover:border-primary/30"
            >
              <div className={cn('mb-1 flex items-center gap-1.5 text-[11px] text-muted-foreground', c.color)}>
                {c.icon}
                <span>{c.label}</span>
              </div>
              <div className="text-2xl font-bold tabular-nums">{c.value.toLocaleString()}</div>
            </div>
          ))}
        </div>

        <div className="mt-2 space-y-1.5 rounded-lg bg-muted/40 p-3 text-xs">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock size={12} />
            <span>
              {stats.spanDays > 0
                ? `Active over ${stats.spanDays} day${stats.spanDays === 1 ? '' : 's'}`
                : 'No activity yet'}
            </span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Hash size={12} />
            <span>
              {stats.totalChars.toLocaleString()} characters typed ({Math.round(stats.totalChars / 1000)}k)
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
