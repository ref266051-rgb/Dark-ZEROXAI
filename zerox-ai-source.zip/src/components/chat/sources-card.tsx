'use client'

import * as React from 'react'
import { ExternalLink, Globe, BookOpen, Search, Clock, ChevronDown, ChevronUp } from 'lucide-react'
import type { SearchContext } from '@/lib/types'
import { cn } from '@/lib/utils'

interface SourcesCardProps {
  context: SearchContext
  /** when true, this is the live progress phase (not yet finalized) */
  live?: boolean
}

const SOURCE_ICONS: Record<string, React.ReactNode> = {
  duckduckgo: <Globe size={11} />,
  wikipedia: <BookOpen size={11} />,
  'ddg-ia': <Search size={11} />,
  unknown: <Search size={11} />,
}

function hostname(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '')
  } catch {
    return url
  }
}

export function SourcesCard({ context, live = false }: SourcesCardProps) {
  const [expanded, setExpanded] = React.useState(false)
  const hasResults = context.results.length > 0
  const hasAbstract = Boolean(context.instantAnswer)

  if (!hasResults && !hasAbstract) return null

  // Compact preview (top 3) by default; expandable to show all
  const visibleResults = expanded ? context.results : context.results.slice(0, 3)
  const hiddenCount = context.results.length - visibleResults.length

  return (
    <div
      className={cn(
        'mb-1.5 rounded-xl border bg-card text-sm shadow-sm',
        live ? 'border-primary/30' : 'border-border/70',
      )}
    >
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-border/60 px-3 py-1.5">
        <Search size={11} className="text-primary" />
        <span className="text-[11px] font-semibold">
          {live ? 'Searching…' : 'Web sources'}
        </span>
        <span className="text-[10px] text-muted-foreground">
          · {context.results.length} result{context.results.length !== 1 ? 's' : ''}
          {context.backendsHit && context.backendsHit.length > 0 && (
            <> · {context.backendsHit.join(' + ')}</>
          )}
          {context.tookMs && <> · {Math.round(context.tookMs)}ms</>}
        </span>
        {!live && context.results.length > 3 && (
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="ml-auto inline-flex items-center gap-1 text-[10px] text-muted-foreground transition hover:text-foreground"
            aria-label={expanded ? 'Collapse' : 'Show all'}
          >
            {expanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
            {expanded ? 'Show less' : `Show all ${context.results.length}`}
          </button>
        )}
      </div>

      {/* Optional DuckDuckGo Instant Answer abstract */}
      {hasAbstract && (
        <div className="border-b border-border/60 bg-muted/20 px-3 py-1.5">
          <div className="mb-0.5 flex items-center gap-1.5 text-[9px] font-medium uppercase tracking-wide text-muted-foreground">
            <Search size={9} /> Instant answer
          </div>
          <p className="text-[11px] leading-relaxed text-foreground/90">{context.instantAnswer}</p>
          {context.instantAnswerUrl && (
            <a
              href={context.instantAnswerUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-0.5 inline-flex items-center gap-1 text-[10px] text-primary hover:underline"
            >
              {hostname(context.instantAnswerUrl)} <ExternalLink size={8} />
            </a>
          )}
        </div>
      )}

      {/* Numbered results list */}
      <ol className="divide-y divide-border/60">
        {visibleResults.map((r, idx) => (
          <li key={`${r.url}-${idx}`} className="px-3 py-1.5 transition hover:bg-muted/30">
            <a
              href={r.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <div className="flex items-start gap-2">
                <span className="mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[9px] font-semibold text-primary">
                  {idx + 1}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    {SOURCE_ICONS[r.source] || <Search size={10} />}
                    <span className="truncate text-[10px] text-muted-foreground">
                      {hostname(r.url)}
                    </span>
                    <ExternalLink size={8} className="ml-auto shrink-0 text-muted-foreground/50" />
                  </div>
                  <div className="mt-0.5 truncate text-[11px] font-medium text-foreground hover:text-primary">
                    {r.title}
                  </div>
                  {r.snippet && (
                    <p className="mt-0.5 line-clamp-2 text-[10px] leading-relaxed text-muted-foreground">
                      {r.snippet}
                    </p>
                  )}
                </div>
              </div>
            </a>
          </li>
        ))}
      </ol>

      {/* Footer summary */}
      {!live && (
        <div className="flex items-center gap-1 border-t border-border/60 px-3 py-1 text-[9px] text-muted-foreground">
          <Clock size={8} />
          <span>Search completed in {context.tookMs ? Math.round(context.tookMs) : '?'}ms</span>
        </div>
      )}
    </div>
  )
}
