'use client'

import * as React from 'react'
import {
  Plus,
  Search,
  MessageSquare,
  Image as ImageIcon,
  Trash2,
  Pencil,
  Check,
  X,
  Settings,
  Download,
  Upload,
  PanelLeftClose,
  MoreHorizontal,
  BarChart3,
  Sparkles,
  Brain,
} from 'lucide-react'
import { useChatStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { SettingsDialog } from './settings-dialog'
import { StatsDialog } from './stats-dialog'

interface SidebarProps {
  onClose?: () => void
  isMobile?: boolean
}

export function Sidebar({ onClose, isMobile }: SidebarProps) {
  const conversations = useChatStore((s) => s.conversations)
  const activeId = useChatStore((s) => s.activeId)
  const setActive = useChatStore((s) => s.setActive)
  const newConversation = useChatStore((s) => s.newConversation)
  const deleteConversation = useChatStore((s) => s.deleteConversation)
  const renameConversation = useChatStore((s) => s.renameConversation)
  const clearAll = useChatStore((s) => s.clearAll)
  const importConversation = useChatStore((s) => s.importConversation)
  const mode = useChatStore((s) => s.mode)
  // Active conversation's mode (locked at creation). Falls back to global mode
  // for the "New chat" button label.
  const activeConv = conversations.find((c) => c.id === activeId)
  const currentMode = activeConv?.mode || mode
  const [query, setQuery] = React.useState('')
  const [editingId, setEditingId] = React.useState<string | null>(null)
  const [draft, setDraft] = React.useState('')
  const [settingsOpen, setSettingsOpen] = React.useState(false)
  const [statsOpen, setStatsOpen] = React.useState(false)

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return conversations
    return conversations.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.content.toLowerCase().includes(q)),
    )
  }, [conversations, query])

  const onNew = () => {
    newConversation()
    if (isMobile) onClose?.()
  }

  const onPick = (id: string) => {
    setActive(id)
    if (isMobile) onClose?.()
  }

  const startRename = (id: string, current: string) => {
    setEditingId(id)
    setDraft(current)
  }
  const commitRename = () => {
    if (editingId) renameConversation(editingId, draft)
    setEditingId(null)
  }

  const exportAll = () => {
    const md = conversations
      .map((c) => {
        const lines = [`# ${c.title}`, '']
        for (const m of c.messages) {
          lines.push(`## ${m.role === 'user' ? 'You' : 'zeroX ai'}`)
          lines.push('')
          lines.push(m.content)
          lines.push('')
        }
        return lines.join('\n')
      })
      .join('\n\n---\n\n')
    const blob = new Blob([md], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `zerox-ai-export-${new Date().toISOString().slice(0, 10)}.md`
    a.click()
    URL.revokeObjectURL(url)
  }

  const exportJson = () => {
    const payload = {
      app: 'zeroX ai',
      version: 1,
      exportedAt: new Date().toISOString(),
      conversations,
    }
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `zerox-ai-backup-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const importJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result))
        const list = Array.isArray(data) ? data : data.conversations
        if (!Array.isArray(list)) throw new Error('Invalid file: no conversations array')
        let count = 0
        for (const c of list) {
          if (c && typeof c === 'object' && Array.isArray(c.messages)) {
            // Give each imported conversation a fresh id to avoid collisions.
            importConversation({ ...c, id: crypto.randomUUID() })
            count++
          }
        }
        if (count > 0) {
          alert(`Imported ${count} conversation${count === 1 ? '' : 's'} successfully.`)
        } else {
          alert('No valid conversations found in the file.')
        }
      } catch (err) {
        alert(
          `Failed to import: ${err instanceof Error ? err.message : 'invalid JSON file'}`,
        )
      }
    }
    reader.readAsText(file)
    // Reset input so the same file can be re-imported.
    e.target.value = ''
  }

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      {/* Brand row — slim */}
      <div className="flex items-center justify-between gap-2 px-4 pt-4 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">
            <Sparkles size={14} strokeWidth={2.2} />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-sm font-semibold tracking-tight">zeroX ai</span>
            <span className="text-[10px] text-muted-foreground">Groq · Agnes</span>
          </div>
        </div>
        {isMobile && (
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <PanelLeftClose size={15} />
          </Button>
        )}
      </div>

      {/* New chat / new image — slim pill */}
      <div className="px-3 pb-2.5">
        <Button
          onClick={onNew}
          className="btn-glow w-full justify-start gap-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/95"
          size="sm"
        >
          <Plus size={15} />{' '}
          {currentMode === 'image' ? 'New image' : currentMode === 'thinking' ? 'New thinking' : 'New chat'}
        </Button>
      </div>

      {/* Search — slim */}
      <div className="px-3 pb-2.5">
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search…"
            className="h-8 rounded-lg border-border/60 bg-background/60 pl-8 text-xs"
          />
        </div>
      </div>

      {/* Conversation list */}
      <div className="scrollbar-thin flex-1 overflow-y-auto px-2 pb-2">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-3 py-10 text-center">
            <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-muted">
              <MessageSquare size={16} className="text-muted-foreground/60" />
            </div>
            <p className="text-xs text-muted-foreground">
              {query ? 'No matching chats.' : 'No chats yet.'}
            </p>
            {!query && (
              <p className="mt-0.5 text-[10px] text-muted-foreground/70">
                Click "New chat" to start.
              </p>
            )}
          </div>
        ) : (
          <ul className="space-y-0.5">
            {filtered.map((c) => (
              <li key={c.id}>
                <div
                  className={cn(
                    'group relative flex items-center rounded-md px-2 py-1.5 text-sm transition-colors',
                    c.id === activeId
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                      : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground',
                  )}
                >
                  {editingId === c.id ? (
                    <div className="flex w-full items-center gap-1">
                      <Input
                        value={draft}
                        onChange={(e) => setDraft(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') commitRename()
                          if (e.key === 'Escape') setEditingId(null)
                        }}
                        className="h-7 flex-1 text-sm"
                        autoFocus
                      />
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={commitRename}>
                        <Check size={14} />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={() => setEditingId(null)}
                      >
                        <X size={14} />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <button
                        onClick={() => onPick(c.id)}
                        className="flex min-w-0 flex-1 items-center gap-2 text-left text-[13px]"
                      >
                        {c.mode === 'image' ? (
                          <ImageIcon
                            size={13}
                            className={cn(
                              'shrink-0',
                              c.id === activeId ? 'text-fuchsia-500' : 'text-muted-foreground',
                            )}
                          />
                        ) : c.mode === 'thinking' ? (
                          <Brain
                            size={13}
                            className={cn(
                              'shrink-0',
                              c.id === activeId ? 'text-violet-500' : 'text-muted-foreground',
                            )}
                          />
                        ) : (
                          <MessageSquare
                            size={13}
                            className={cn(
                              'shrink-0',
                              c.id === activeId ? 'text-primary' : 'text-muted-foreground',
                            )}
                          />
                        )}
                        <span className="truncate">{c.title}</span>
                      </button>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 shrink-0 opacity-0 transition group-hover:opacity-100 data-[state=open]:opacity-100"
                            aria-label="Chat options"
                          >
                            <MoreHorizontal size={13} />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-40">
                          <DropdownMenuItem onClick={() => startRename(c.id, c.title)}>
                            <Pencil size={13} /> Rename
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => {
                              const md = [`# ${c.title}`, '']
                              for (const m of c.messages) {
                                md.push(`## ${m.role === 'user' ? 'You' : 'zeroX ai'}`, '', m.content, '')
                              }
                              const blob = new Blob([md.join('\n')], { type: 'text/markdown' })
                              const url = URL.createObjectURL(blob)
                              const a = document.createElement('a')
                              a.href = url
                              a.download = `${c.title.replace(/[^a-z0-9-_ ]/gi, '').slice(0, 40) || 'chat'}.md`
                              a.click()
                              URL.revokeObjectURL(url)
                            }}
                          >
                            <Download size={13} /> Export
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => deleteConversation(c.id)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 size={13} /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Footer — slim */}
      <div className="border-t border-sidebar-border/60 px-2 py-1.5">
        <AlertDialog>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="w-full justify-start gap-2 rounded-md text-xs text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              >
                <Settings size={14} /> Settings &amp; more
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="mb-2 w-56">
              <DropdownMenuItem onClick={() => setSettingsOpen(true)}>
                <Settings size={14} /> Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setStatsOpen(true)}>
                <BarChart3 size={14} /> Your stats
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={exportAll} disabled={conversations.length === 0}>
                <Download size={14} /> Export all as Markdown
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportJson} disabled={conversations.length === 0}>
                <Download size={14} /> Backup as JSON
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => fileInputRef.current?.click()}>
                <Upload size={14} /> Restore from JSON…
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <AlertDialogTrigger asChild>
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  disabled={conversations.length === 0}
                >
                  <Trash2 size={14} /> Clear all chats
                </DropdownMenuItem>
              </AlertDialogTrigger>
            </DropdownMenuContent>
          </DropdownMenu>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete all conversations?</AlertDialogTitle>
              <AlertDialogDescription>
                This permanently removes every chat from this device. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => clearAll()}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete all
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
      <StatsDialog open={statsOpen} onOpenChange={setStatsOpen} />

      {/* Hidden file input for JSON restore */}
      <input
        ref={fileInputRef}
        type="file"
        accept="application/json,.json"
        onChange={importJson}
        className="hidden"
        aria-hidden="true"
        tabIndex={-1}
      />
    </div>
  )
}
