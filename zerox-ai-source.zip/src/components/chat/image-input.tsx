'use client'

import * as React from 'react'
import { Wand2, Square, Sparkles, Image as ImageIcon } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useChatStore } from '@/lib/store'
import { IMAGE_STYLE_PRESETS } from '@/lib/types'
import { getIcon } from '@/lib/icon-registry'
import { hasAgnesPublicKey, AGNES_INFO } from '@/lib/image'

interface ImageInputProps {
  onGenerate: (text: string) => void
  onStop: () => void
  isGenerating: boolean
  placeholder?: string
}

export function ImageInput({ onGenerate, onStop, isGenerating, placeholder }: ImageInputProps) {
  const [value, setValue] = React.useState('')
  const taRef = React.useRef<HTMLTextAreaElement>(null)
  const imageSettings = useChatStore((s) => s.imageSettings)
  const setImageSettings = useChatStore((s) => s.setImageSettings)
  const userAgnesKey = useChatStore((s) => s.userAgnesKey)
  const hasKey = Boolean(userAgnesKey) || hasAgnesPublicKey()

  React.useEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 200) + 'px'
  }, [value])

  const submit = () => {
    const text = value.trim()
    if (!text || isGenerating) return
    onGenerate(text)
    setValue('')
    requestAnimationFrame(() => {
      if (taRef.current) taRef.current.style.height = 'auto'
    })
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      submit()
    }
  }

  const currentStyle = IMAGE_STYLE_PRESETS.find((p) => p.id === imageSettings.style)!
  const CurrentStyleIcon = getIcon(currentStyle.icon)

  return (
    <TooltipProvider delayDuration={300}>
      <div className="border-t border-border bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="mx-auto max-w-3xl px-3 py-3 sm:px-6 sm:py-4">
          {/* Style + size row */}
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1.5 rounded-full text-xs"
                  aria-label="Style preset"
                >
                  <CurrentStyleIcon size={13} />
                  {currentStyle.label}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-44">
                {IMAGE_STYLE_PRESETS.map((p) => {
                  const Icon = getIcon(p.icon)
                  return (
                    <DropdownMenuItem
                      key={p.id}
                      onClick={() => setImageSettings({ style: p.id })}
                      className="gap-2 text-sm"
                    >
                      <Icon size={13} /> {p.label}
                    {p.id === imageSettings.style && (
                      <span className="ml-auto text-xs text-primary">●</span>
                    )}
                    </DropdownMenuItem>
                  )
                })}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1.5 rounded-full text-xs"
                  aria-label="Image size"
                >
                  <ImageIcon size={12} />
                  {imageSettings.size}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-40">
                {(['1024x1024', '1024x1792', '1792x1024', '512x512'] as const).map((s) => (
                  <DropdownMenuItem
                    key={s}
                    onClick={() => setImageSettings({ size: s })}
                    className="gap-2 text-sm"
                  >
                    <span className="font-mono text-xs">{s}</span>
                    <span className="ml-auto text-[10px] text-muted-foreground">
                      {s === '1024x1024' ? 'Square'
                        : s === '1024x1792' ? 'Tall'
                        : s === '1792x1024' ? 'Wide'
                        : 'Small'}
                    </span>
                    {s === imageSettings.size && <span className="ml-1 text-xs text-primary">●</span>}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant={imageSettings.highQuality ? 'secondary' : 'ghost'}
              size="sm"
              className={cn(
                'h-8 gap-1.5 rounded-full text-xs',
                imageSettings.highQuality && 'bg-primary/10 text-primary hover:bg-primary/15',
              )}
              onClick={() => setImageSettings({ highQuality: !imageSettings.highQuality })}
              aria-pressed={imageSettings.highQuality}
            >
              <Sparkles size={12} /> HQ
            </Button>
          </div>

          <div className="relative flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm transition focus-within:border-primary/60 focus-within:ring-2 focus-within:ring-primary/20">
            <Textarea
              ref={taRef}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={onKeyDown}
              rows={1}
              placeholder={placeholder || 'Describe the image you want to create…'}
              className="min-h-[40px] max-h-[200px] flex-1 resize-none border-0 bg-transparent px-1 py-2 text-[15px] shadow-none focus-visible:ring-0 focus-visible:ring-offset-0"
            />

            {isGenerating ? (
              <Button
                size="icon"
                onClick={onStop}
                className="h-9 w-9 shrink-0 rounded-xl"
                variant="destructive"
                aria-label="Stop generating"
              >
                <Square size={16} className="fill-current" />
              </Button>
            ) : (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="icon"
                    onClick={submit}
                    disabled={!value.trim()}
                    className="h-9 w-9 shrink-0 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                    aria-label="Generate image"
                  >
                    <Wand2 size={18} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Generate · Enter</TooltipContent>
              </Tooltip>
            )}
          </div>

          <div className="mt-2 flex items-center justify-between px-1 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <Sparkles size={11} className="text-primary" /> {AGNES_INFO.model} · Agnes AI
              {!hasKey && <span className="ml-1 text-amber-500">⚠ no key</span>}
            </span>
            <span className="hidden sm:inline">
              <kbd className="rounded border border-border bg-muted px-1 py-0.5 font-mono">Enter</kbd>{' '}
              to generate ·{' '}
              <kbd className="rounded border border-border bg-muted px-1 py-0.5 font-mono">
                Shift+Enter
              </kbd>{' '}
              for new line
            </span>
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}
