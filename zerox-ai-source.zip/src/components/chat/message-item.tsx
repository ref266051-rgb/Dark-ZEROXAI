'use client'

import * as React from 'react'
import {
  Check,
  Copy,
  RefreshCw,
  Pencil,
  Trash2,
  X,
  AlertTriangle,
  Search,
  ThumbsUp,
  ThumbsDown,
  Clipboard,
  Sparkles,
  User,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/lib/utils'
import type { ChatMessage } from '@/lib/types'
import { Markdown } from './markdown'
import { SearchProgress } from './search-progress'
import { SourcesCard } from './sources-card'
import { ThinkingBubble } from './thinking-bubble'
import { RateLimitBanner } from './rate-limit-banner'

interface MessageItemProps {
  message: ChatMessage
  isLast: boolean
  onRegenerate: () => void
  onEdit: (newContent: string) => void
  onDelete: () => void
  onFeedback?: (feedback: 'up' | 'down' | undefined) => void
  onRetry?: () => void
  disabled: boolean
}

function formatTime(ts: number): string {
  try {
    const d = new Date(ts)
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  } catch {
    return ''
  }
}

export function MessageItem({
  message,
  isLast,
  onRegenerate,
  onEdit,
  onDelete,
  onFeedback,
  onRetry,
  disabled,
}: MessageItemProps) {
  const [copied, setCopied] = React.useState(false)
  const [copiedMd, setCopiedMd] = React.useState(false)
  const [editing, setEditing] = React.useState(false)
  const [draft, setDraft] = React.useState(message.content)

  const isUser = message.role === 'user'

  const onCopy = () => {
    navigator.clipboard.writeText(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const onCopyMarkdown = () => {
    const sources = message.searchContext?.results || []
    let md = message.content
    if (sources.length > 0) {
      md += '\n\n---\n**Sources:**\n'
      sources.forEach((s, i) => {
        md += `${i + 1}. [${s.title}](${s.url}) — ${s.snippet.slice(0, 100)}${s.snippet.length > 100 ? '…' : ''}\n`
      })
    }
    navigator.clipboard.writeText(md)
    setCopiedMd(true)
    toast.success('Copied as Markdown', { duration: 1500 })
    setTimeout(() => setCopiedMd(false), 1500)
  }

  const toggleFeedback = (f: 'up' | 'down') => {
    const next = message.feedback === f ? undefined : f
    onFeedback?.(next)
  }

  const startEdit = () => {
    setDraft(message.content)
    setEditing(true)
  }
  const saveEdit = () => {
    setEditing(false)
    if (draft.trim() && draft !== message.content) onEdit(draft)
  }
  const cancelEdit = () => {
    setEditing(false)
    setDraft(message.content)
  }

  /* Bubble layout: user = right (accent), assistant = left (muted) */
  return (
    <div className={cn('msg-in flex w-full gap-3 px-4 py-3 sm:px-6', isUser ? 'justify-end' : 'justify-start')}>
      {/* Assistant avatar (left side) */}
      {!isUser && (
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">
          <Sparkles size={15} strokeWidth={2.2} />
        </div>
      )}

      <div className={cn('flex min-w-0 max-w-[85%] flex-col gap-1.5 sm:max-w-[75%]', isUser ? 'items-end' : 'items-start')}>
        {/* Header: name + badges */}
        <div className={cn('flex items-center gap-2 text-xs', isUser ? 'flex-row-reverse' : 'flex-row')}>
          <span className="font-semibold text-foreground">{isUser ? 'You' : 'zeroX ai'}</span>
          {!isUser && message.kind !== 'image' && (
            <span className="hidden rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary sm:inline">
              AI
            </span>
          )}
          {message.searching && (
            <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary">
              <Search size={9} className="animate-pulse" /> searching
            </span>
          )}
          {message.streaming && (
            <span className="rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary">
              typing…
            </span>
          )}
          <span className="text-[10px] text-muted-foreground/70">{formatTime(message.createdAt)}</span>
        </div>

        {/* Web search — live progress / sources */}
        {!isUser && message.searching && message.searchContext?.progress && (
          <SearchProgress
            steps={message.searchContext.progress}
            query={message.searchContext.query}
          />
        )}
        {!isUser && !message.searching && message.searchContext && (
          <SourcesCard context={message.searchContext} />
        )}

        {/* Thinking bubble (chain-of-thought) — shown when thinking mode was on */}
        {!isUser && (message.thinking || message.thinkingStreaming) && (
          <ThinkingBubble
            thinking={message.thinking || ''}
            streaming={message.thinkingStreaming}
            charCount={message.thinkingCharCount}
            tookMs={message.thinkingTookMs}
            charsPerSec={message.thinkingCharsPerSec}
            wordCount={message.thinkingWordCount}
            native={message.thinkingNative}
          />
        )}

        {/* Bubble body */}
        {editing ? (
          <div className="w-full space-y-2 rounded-2xl border border-border bg-card p-3 shadow-sm">
            <Textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              className="min-h-[100px] resize-y bg-background"
              autoFocus
            />
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="ghost" onClick={cancelEdit}>
                <X size={14} /> Cancel
              </Button>
              <Button size="sm" onClick={saveEdit}>
                <Check size={14} /> Save &amp; Submit
              </Button>
            </div>
          </div>
        ) : message.error ? (
          message.errorKind === 'rate_limit' || message.errorKind === 'quota' ? (
            <RateLimitBanner
              kind={message.errorKind}
              message={message.error}
              retryAfterSec={message.retryAfterSec}
              limitType={message.limitType}
              onRetry={onRetry}
            />
          ) : (
            <div
              className={cn(
                'rounded-2xl border px-4 py-2.5 text-sm shadow-sm',
                isUser
                  ? 'rounded-tr-md border-primary/30 bg-primary/10 text-foreground'
                  : 'rounded-tl-md border-destructive/30 bg-destructive/5 text-destructive',
              )}
            >
              <div className="flex items-center gap-2 font-medium">
                <AlertTriangle size={14} /> Error
              </div>
              <div className="mt-1 text-destructive/90">
                {typeof message.error === 'string'
                  ? message.error
                  : (() => {
                      try {
                        const e = message.error as unknown as { message?: string; type?: string }
                        return e?.message || e?.type || JSON.stringify(e)
                      } catch {
                        return 'Unknown error'
                      }
                    })()}
              </div>
            </div>
          )
        ) : message.content ? (
          <div
            className={cn(
              'rounded-2xl px-4 py-2.5 shadow-sm transition',
              isUser
                ? 'rounded-tr-md bg-primary text-primary-foreground'
                : 'rounded-tl-md border border-border bg-card text-card-foreground',
            )}
          >
            {isUser ? (
              <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
                {message.content}
              </p>
            ) : (
              <div className="streaming-cursor-wrapper">
                <Markdown content={message.content} />
                {message.streaming && <span className="streaming-cursor" />}
              </div>
            )}
          </div>
        ) : message.streaming ? (
          <div
            className={cn(
              'flex items-center gap-1.5 rounded-2xl px-4 py-3.5 shadow-sm',
              'rounded-tl-md border border-border bg-card',
            )}
          >
            <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.3s]" />
            <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.15s]" />
            <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60" />
          </div>
        ) : null}

        {/* Actions */}
        {!editing && !message.streaming && !message.error && message.content && (
          <div
            className={cn(
              'flex items-center gap-0.5 opacity-0 transition group-hover:opacity-100',
              isUser ? 'flex-row-reverse' : 'flex-row',
            )}
          >
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
              onClick={onCopy}
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              {copied ? 'Copied' : 'Copy'}
            </Button>
            {!isUser && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
                onClick={onCopyMarkdown}
              >
                {copiedMd ? <Check size={12} /> : <Clipboard size={12} />}
                {copiedMd ? 'Copied' : 'MD'}
              </Button>
            )}
            {isUser && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
                onClick={startEdit}
                disabled={disabled}
              >
                <Pencil size={12} /> Edit
              </Button>
            )}
            {!isUser && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    'h-7 gap-1 px-2 text-xs transition',
                    message.feedback === 'up'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                  onClick={() => toggleFeedback('up')}
                  aria-pressed={message.feedback === 'up'}
                  aria-label="Good response"
                >
                  <ThumbsUp size={12} />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    'h-7 gap-1 px-2 text-xs transition',
                    message.feedback === 'down'
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                  onClick={() => toggleFeedback('down')}
                  aria-pressed={message.feedback === 'down'}
                  aria-label="Bad response"
                >
                  <ThumbsDown size={12} />
                </Button>
              </>
            )}
            {!isUser && isLast && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
                onClick={onRegenerate}
                disabled={disabled}
              >
                <RefreshCw size={12} /> Regenerate
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-destructive"
              onClick={onDelete}
              disabled={disabled}
            >
              <Trash2 size={12} />
            </Button>
          </div>
        )}
      </div>

      {/* User avatar (right side) */}
      {isUser && (
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-secondary-foreground shadow-sm">
          <User size={15} strokeWidth={2.2} />
        </div>
      )}
    </div>
  )
}
