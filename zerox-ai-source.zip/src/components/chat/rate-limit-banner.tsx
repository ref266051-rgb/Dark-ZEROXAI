'use client'

import * as React from 'react'
import { AlertTriangle, Clock, RotateCw, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface RateLimitBannerProps {
  /** 'rate_limit' = temporary (per-minute), 'quota' = longer (daily/monthly) */
  kind: 'rate_limit' | 'quota'
  /** raw error message from Groq (shown collapsed by default) */
  message?: string
  /** seconds until the user can retry */
  retryAfterSec?: number
  /** friendly label like "Daily quota" or "Requests per minute" */
  limitType?: string
  /** callback when user clicks "Try again now" */
  onRetry?: () => void
}

export function RateLimitBanner({
  kind,
  message,
  retryAfterSec,
  limitType,
  onRetry,
}: RateLimitBannerProps) {
  // Live countdown
  const [remaining, setRemaining] = React.useState(retryAfterSec ?? 0)
  React.useEffect(() => {
    if (!retryAfterSec) return
    setRemaining(retryAfterSec)
    if (retryAfterSec <= 0) return
    const id = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(id)
          return 0
        }
        return r - 1
      })
    }, 1000)
    return () => clearInterval(id)
  }, [retryAfterSec])

  const isQuota = kind === 'quota'
  const canRetry = onRetry && (remaining === 0 || !retryAfterSec)

  const formatDuration = (s: number) => {
    if (s <= 0) return 'now'
    if (s < 60) return `${s}s`
    const m = Math.floor(s / 60)
    const sec = s % 60
    return sec > 0 ? `${m}m ${sec}s` : `${m}m`
  }

  return (
    <div
      className={cn(
        'mb-1.5 overflow-hidden rounded-2xl border px-4 py-3 shadow-sm',
        isQuota
          ? 'border-rose-400/40 bg-rose-500/5'
          : 'border-amber-400/40 bg-amber-500/5',
      )}
    >
      {/* Header row */}
      <div className="flex items-start gap-2.5">
        <span
          className={cn(
            'flex h-7 w-7 shrink-0 items-center justify-center rounded-full',
            isQuota ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400' : 'bg-amber-500/15 text-amber-600 dark:text-amber-400',
          )}
        >
          {isQuota ? <Zap size={14} /> : <AlertTriangle size={14} />}
        </span>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span
              className={cn(
                'text-sm font-semibold',
                isQuota ? 'text-rose-700 dark:text-rose-300' : 'text-amber-700 dark:text-amber-300',
              )}
            >
              {isQuota ? 'Limit kuota tercapai' : 'Limit tercapai'}
            </span>
            {limitType && (
              <span
                className={cn(
                  'rounded-full px-1.5 py-0.5 text-[10px] font-medium',
                  isQuota
                    ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
                    : 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
                )}
              >
                {limitType}
              </span>
            )}
          </div>

          <p className="mt-0.5 text-xs leading-relaxed text-foreground/80">
            Anda telah mencapai limit{limitType ? ` (${limitType})` : ''}.
            {isQuota
              ? ' Limit ini bersifat harian/bulanan — silakan upgrade plan Groq Anda atau tunggu reset otomatis.'
              : retryAfterSec && remaining > 0
                ? ` Silakan tunggu ${formatDuration(remaining)} sebelum mencoba lagi.`
                : ' Silakan tunggu sebentar sebelum mencoba lagi.'}
          </p>

          {/* Action row */}
          {(onRetry || remaining > 0) && (
            <div className="mt-2 flex items-center gap-2">
              {onRetry && (
                <Button
                  size="sm"
                  variant={isQuota ? 'destructive' : 'outline'}
                  onClick={onRetry}
                  disabled={!canRetry}
                  className="h-7 gap-1.5 rounded-md px-2.5 text-xs"
                >
                  <RotateCw size={11} className={canRetry ? '' : 'opacity-50'} />
                  {canRetry ? 'Coba lagi' : `Coba lagi (${formatDuration(remaining)})`}
                </Button>
              )}
              {!onRetry && remaining > 0 && (
                <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Clock size={10} />
                  Dapat dicoba lagi dalam {formatDuration(remaining)}
                </span>
              )}
            </div>
          )}

          {/* Collapsible raw error message */}
          {message && (
            <details className="mt-2 group">
              <summary
                className={cn(
                  'cursor-pointer text-[10px] underline-offset-2 hover:underline',
                  isQuota ? 'text-rose-600/70 dark:text-rose-400/70' : 'text-amber-600/70 dark:text-amber-400/70',
                )}
              >
                Lihat detail error dari Groq
              </summary>
              <pre className="mt-1 whitespace-pre-wrap break-words rounded-md bg-muted/40 p-2 font-mono text-[10px] text-muted-foreground">
                {message}
              </pre>
            </details>
          )}
        </div>
      </div>
    </div>
  )
}
