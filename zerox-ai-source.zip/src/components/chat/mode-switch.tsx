'use client'

import { MessageSquare, Image as ImageIcon, Brain } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useChatStore } from '@/lib/store'
import type { AppMode } from '@/lib/types'

interface ModeSwitchProps {
  /** the locked mode of the currently-open conversation — when set, switching
   *  will start a new conversation in the chosen mode instead of mutating
   *  the current one. */
  currentMode: AppMode
  onSwitch?: (mode: AppMode) => void
  className?: string
}

export function ModeSwitch({ currentMode, onSwitch, className }: ModeSwitchProps) {
  const setMode = useChatStore((s) => s.setMode)
  const newConversation = useChatStore((s) => s.newConversation)

  const switchTo = (mode: AppMode) => {
    if (mode === currentMode) return
    setMode(mode)
    onSwitch?.(mode)
    // Always start a fresh conversation when switching modes — keeps each
    // conversation's mode locked and avoids mixing image+text+thinking history.
    newConversation(undefined, mode)
  }

  const tabs: { id: AppMode; label: string; icon: typeof MessageSquare }[] = [
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'thinking', label: 'Thinking', icon: Brain },
    { id: 'image', label: 'Image', icon: ImageIcon },
  ]

  return (
    <div
      className={cn(
        'inline-flex items-center rounded-full border border-border/60 bg-muted/40 p-0.5 text-[11px]',
        className,
      )}
      role="tablist"
      aria-label="App mode"
    >
      {tabs.map((tab) => {
        const Icon = tab.icon
        const active = currentMode === tab.id
        return (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => switchTo(tab.id)}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-medium transition-all',
              active
                ? tab.id === 'thinking'
                  ? 'bg-background text-violet-600 shadow-sm dark:text-violet-400'
                  : 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground',
            )}
          >
            <Icon size={12} />
            {tab.label}
          </button>
        )
      })}
    </div>
  )
}
