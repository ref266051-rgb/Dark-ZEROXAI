'use client'

import { Loader2, Check, X, Globe, BookOpen, Search } from 'lucide-react'
import type { SearchProgressStep } from '@/lib/types'
import { cn } from '@/lib/utils'

interface SearchProgressProps {
  steps: SearchProgressStep[]
  query: string
}

const BACKEND_ICONS: Record<string, React.ReactNode> = {
  DuckDuckGo: <Globe size={12} />,
  Wikipedia: <BookOpen size={12} />,
  'DuckDuckGo IA': <Search size={12} />,
  'Server proxy': <Globe size={12} />,
}

export function SearchProgress({ steps, query }: SearchProgressProps) {
  const total = steps.length
  const done = steps.filter((s) => s.status === 'success' || s.status === 'error').length
  const succeeded = steps.filter((s) => s.status === 'success').reduce((a, s) => a + (s.count || 0), 0)

  return (
    <div className="mb-1.5 rounded-xl border border-primary/25 bg-primary/5 px-3 py-2">
      <div className="mb-1.5 flex items-center gap-2 text-[11px] font-medium text-primary">
        <Loader2 size={11} className="animate-spin" />
        <span>
          Searching for{' '}
          <span className="italic">
            “{query.length > 36 ? query.slice(0, 36) + '…' : query}”
          </span>
          <span className="ml-1 text-muted-foreground/80">
            · {done}/{total} sources{succeeded > 0 && ` · ${succeeded} found`}
          </span>
        </span>
      </div>

      <div className="flex flex-wrap gap-1">
        {steps.map((s) => (
          <span
            key={s.backend}
            className={cn(
              'inline-flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[10px] font-medium transition',
              s.status === 'pending' && 'border-border/60 bg-muted/30 text-muted-foreground/70',
              s.status === 'running' && 'border-primary/40 bg-primary/10 text-primary',
              s.status === 'success' && 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400',
              s.status === 'error' && 'border-destructive/40 bg-destructive/10 text-destructive',
            )}
          >
            {BACKEND_ICONS[s.backend] || <Search size={10} />}
            <span>{s.backend}</span>
            {s.status === 'running' && <Loader2 size={8} className="animate-spin" />}
            {s.status === 'success' && <Check size={8} />}
            {s.status === 'error' && <X size={8} />}
            {s.status === 'success' && s.count !== undefined && (
              <span className="opacity-70">· {s.count}</span>
            )}
          </span>
        ))}
      </div>
    </div>
  )
}
