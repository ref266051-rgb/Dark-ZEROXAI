'use client'

import * as React from 'react'
import { Command as CommandIcon, Sparkles, type LucideIcon, FileText, Languages, Lightbulb, Code2, PenLine, Brain, Baby, Scale } from 'lucide-react'
import { cn } from '@/lib/utils'

export interface SlashCommand {
  /** the trigger, e.g. "/summarize" */
  id: string
  label: string
  description: string
  icon: LucideIcon
  /** builds the prompt that gets sent to the AI; if it returns null, the command is treated as a no-op */
  buildPrompt: (args: string) => string | null
}

export const SLASH_COMMANDS: SlashCommand[] = [
  {
    id: '/summarize',
    label: '/summarize',
    description: 'Summarize the given text or topic in 5 bullets',
    icon: FileText,
    buildPrompt: (args) =>
      args.trim()
        ? `Summarize the following into 5 concise bullet points:\n\n"""${args.trim()}"""`
        : null,
  },
  {
    id: '/translate',
    label: '/translate',
    description: 'Translate text — usage: /translate <to-lang> <text>',
    icon: Languages,
    buildPrompt: (args) => {
      const m = args.trim().match(/^(\S+)\s+([\s\S]+)$/)
      if (!m) return null
      const [, lang, text] = m
      return `Translate the following text into ${lang}. Keep the original meaning and tone. Only output the translation, nothing else.\n\n"""${text.trim()}"""`
    },
  },
  {
    id: '/explain',
    label: '/explain',
    description: 'Explain a concept simply, with an everyday analogy',
    icon: Lightbulb,
    buildPrompt: (args) =>
      args.trim()
        ? `Explain "${args.trim()}" simply. Use one everyday analogy and one short example. Avoid jargon where possible.`
        : null,
  },
  {
    id: '/code',
    label: '/code',
    description: 'Write clean code — usage: /code <language> <task>',
    icon: Code2,
    buildPrompt: (args) => {
      const m = args.trim().match(/^(\S+)\s+([\s\S]+)$/)
      if (!m) return null
      const [, lang, task] = m
      return `Write ${lang} code that: ${task.trim()}\n\nRequirements:\n- Clean, idiomatic, well-commented\n- Include a brief explanation before the code\n- Mention edge cases and trade-offs\n- Use fenced code blocks with the correct language tag`
    },
  },
  {
    id: '/improve',
    label: '/improve',
    description: 'Improve the writing of the given text',
    icon: PenLine,
    buildPrompt: (args) =>
      args.trim()
        ? `Improve the following text for clarity, conciseness, and flow. Keep the original meaning and tone. Return only the improved version.\n\n"""${args.trim()}"""`
        : null,
  },
  {
    id: '/brainstorm',
    label: '/brainstorm',
    description: 'Brainstorm 10 ideas on a topic',
    icon: Brain,
    buildPrompt: (args) =>
      args.trim()
        ? `Brainstorm 10 creative ideas about "${args.trim()}". Format as a numbered list with one-sentence descriptions. Be specific and avoid generic suggestions.`
        : null,
  },
  {
    id: '/eli5',
    label: '/eli5',
    description: 'Explain a concept like I am 5 years old',
    icon: Baby,
    buildPrompt: (args) =>
      args.trim()
        ? `Explain "${args.trim()}" like I am 5 years old. Use very simple words, short sentences, and one fun comparison.`
        : null,
  },
  {
    id: '/proscons',
    label: '/proscons',
    description: 'List pros and cons of a topic or decision',
    icon: Scale,
    buildPrompt: (args) =>
      args.trim()
        ? `List 5 pros and 5 cons of "${args.trim()}". Use a Markdown table with two columns (Pros | Cons). Then give a one-sentence verdict.`
        : null,
  },
]

interface SlashCommandMenuProps {
  open: boolean
  filter: string
  onPick: (cmd: SlashCommand) => void
  onClose: () => void
}

export function SlashCommandMenu({ open, filter, onPick, onClose }: SlashCommandMenuProps) {
  if (!open) return null
  const q = filter.toLowerCase().replace(/^\//, '')
  const filtered = SLASH_COMMANDS.filter(
    (c) =>
      c.label.toLowerCase().includes(q) || c.description.toLowerCase().includes(q),
  )

  return (
    <div
      className="absolute bottom-full left-0 right-0 z-20 mb-2 max-h-72 overflow-y-auto rounded-xl border border-border bg-popover p-1 shadow-xl"
      role="listbox"
      aria-label="Slash commands"
    >
      <div className="flex items-center gap-1.5 px-2 py-1.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        <CommandIcon size={11} /> Slash commands
        <span className="ml-auto inline-flex items-center gap-1 text-[10px] normal-case">
          <Sparkles size={10} className="text-primary" /> {filtered.length} available
        </span>
      </div>
      {filtered.length === 0 ? (
        <div className="px-2 py-3 text-center text-xs text-muted-foreground">No matching commands</div>
      ) : (
        filtered.map((c) => (
          <button
            key={c.id}
            type="button"
            role="option"
            aria-selected="false"
            onClick={() => onPick(c)}
            className={cn(
              'flex w-full items-start gap-2 rounded-lg px-2 py-2 text-left transition',
              'hover:bg-accent hover:text-accent-foreground',
            )}
          >
            <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
              <c.icon size={14} strokeWidth={2} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <code className="font-mono text-xs font-semibold text-primary">{c.label}</code>
              </div>
              <p className="text-[11px] text-muted-foreground">{c.description}</p>
            </div>
          </button>
        ))
      )}
      <div className="border-t border-border px-2 py-1 text-[10px] text-muted-foreground">
        Press <kbd className="rounded bg-muted px-1 font-mono">Esc</kbd> to close
      </div>
      {/* Click-away catcher */}
      <button
        type="button"
        aria-label="Close slash menu"
        className="fixed inset-0 -z-10 cursor-default"
        onClick={onClose}
        tabIndex={-1}
      />
    </div>
  )
}
