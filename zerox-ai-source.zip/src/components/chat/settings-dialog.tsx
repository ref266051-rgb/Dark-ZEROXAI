'use client'

import * as React from 'react'
import { Settings, RotateCcw, User, Thermometer, Hash, Percent, KeyRound, Eye, EyeOff, AlertTriangle } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { useChatStore } from '@/lib/store'
import { hasPublicKey } from '@/lib/stream'
import { DEFAULT_PERSONAS, DEFAULT_SETTINGS } from '@/lib/types'
import { getIcon } from '@/lib/icon-registry'
import { cn } from '@/lib/utils'

interface SettingsDialogProps {
  open: boolean
  onOpenChange: (o: boolean) => void
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const settings = useChatStore((s) => s.settings)
  const setSettings = useChatStore((s) => s.setSettings)
  const applyPersona = useChatStore((s) => s.applyPersona)
  const activePersonaId = useChatStore((s) => s.activePersonaId)
  const userApiKey = useChatStore((s) => s.userApiKey)
  const setUserApiKey = useChatStore((s) => s.setUserApiKey)
  const userAgnesKey = useChatStore((s) => s.userAgnesKey)
  const setUserAgnesKey = useChatStore((s) => s.setUserAgnesKey)
  const userOpenRouterKey = useChatStore((s) => s.userOpenRouterKey)
  const setUserOpenRouterKey = useChatStore((s) => s.setUserOpenRouterKey)
  const useBrowserMode = useChatStore((s) => s.useBrowserMode)
  const setUseBrowserMode = useChatStore((s) => s.setUseBrowserMode)
  const [showKey, setShowKey] = React.useState(false)
  const [showAgnesKey, setShowAgnesKey] = React.useState(false)
  const [showOpenRouterKey, setShowOpenRouterKey] = React.useState(false)

  const reset = () => setSettings(DEFAULT_SETTINGS)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings size={18} /> Settings
          </DialogTitle>
          <DialogDescription>
            Fine-tune zeroX ai behavior. Changes apply to new messages in all chats.
          </DialogDescription>
        </DialogHeader>

        {/* Personas */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2 text-sm">
            <User size={14} /> Persona preset
          </Label>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {DEFAULT_PERSONAS.map((p) => {
              const Icon = getIcon(p.icon)
              return (
                <button
                  key={p.id}
                  onClick={() => applyPersona(p)}
                  className={cn(
                    'rounded-lg border p-3 text-left transition',
                    p.id === activePersonaId
                      ? 'border-primary bg-primary/5 ring-1 ring-primary/30'
                      : 'border-border hover:border-primary/40',
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                      <Icon size={14} strokeWidth={2} />
                    </span>
                    <span className="text-sm font-medium">{p.name}</span>
                  {p.id === activePersonaId && (
                    <Badge variant="secondary" className="ml-auto text-[10px]">
                      Active
                    </Badge>
                  )}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{p.description}</p>
                </button>
              )
            })}
          </div>
        </div>

        {/* Connection / API key */}
        <div className="space-y-3 rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex items-center justify-between gap-2">
            <Label htmlFor="browser-mode" className="flex items-center gap-2 text-sm">
              <KeyRound size={14} /> Browser-direct mode
            </Label>
            <Switch
              id="browser-mode"
              checked={useBrowserMode}
              onCheckedChange={setUseBrowserMode}
            />
          </div>
          <p className="text-xs text-muted-foreground">
            When on, requests go <strong>straight from your browser</strong> to Groq. This bypasses
            the server entirely — and is the recommended mode, because the server host is blocked by
            Groq&apos;s Cloudflare WAF (returns <code className="font-mono">403 Forbidden</code>).
          </p>
          <div className="space-y-1.5">
            <Label htmlFor="api-key" className="text-xs text-muted-foreground">
              Your Groq API key (stored only in this browser)
            </Label>
            <div className="relative">
              <Input
                id="api-key"
                type={showKey ? 'text' : 'password'}
                value={userApiKey}
                onChange={(e) => setUserApiKey(e.target.value)}
                placeholder={hasPublicKey() ? 'Using built-in demo key — paste your own to override' : 'gsk_…'}
                className="pr-10 font-mono text-xs"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                type="button"
                onClick={() => setShowKey((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label={showKey ? 'Hide key' : 'Show key'}
              >
                {showKey ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
            {useBrowserMode && !userApiKey && hasPublicKey() && (
              <div className="flex items-start gap-1.5 rounded-md bg-emerald-500/10 px-2 py-1.5 text-xs text-emerald-700 dark:text-emerald-400">
                <KeyRound size={12} className="mt-0.5 shrink-0" />
                <span>
                  Using the built-in demo key. It works out of the box — no setup needed. Paste your
                  own key above to override.
                </span>
              </div>
            )}
            {useBrowserMode && !userApiKey && !hasPublicKey() && (
              <div className="flex items-start gap-1.5 rounded-md bg-amber-500/10 px-2 py-1.5 text-xs text-amber-700 dark:text-amber-400">
                <AlertTriangle size={12} className="mt-0.5 shrink-0" />
                <span>Browser mode is on but no API key is set — requests will fail.</span>
              </div>
            )}
            <p className="text-[10px] text-muted-foreground">
              Get a free key at{' '}
              <a
                href="https://console.groq.com/keys"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary underline"
              >
                console.groq.com/keys
              </a>
              . Your key never leaves this browser when browser mode is on.
            </p>
          </div>
        </div>

        {/* Agnes AI key (image generation) */}
        <div className="space-y-3 rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex items-center gap-2 text-sm">
            <KeyRound size={14} /> Agnes AI key (for Image mode)
          </div>
          <p className="text-xs text-muted-foreground">
            Used for image generation via <code className="font-mono">agnes-image-2.1-flash</code>.
            Requests always go straight from your browser to Agnes. The built-in demo key works
            out of the box — paste your own here to override.
          </p>
          <div className="space-y-1.5">
            <Label htmlFor="agnes-key" className="text-xs text-muted-foreground">
              Your Agnes AI API key (stored only in this browser)
            </Label>
            <div className="relative">
              <Input
                id="agnes-key"
                type={showAgnesKey ? 'text' : 'password'}
                value={userAgnesKey}
                onChange={(e) => setUserAgnesKey(e.target.value)}
                placeholder="sk-…"
                className="pr-10 font-mono text-xs"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                type="button"
                onClick={() => setShowAgnesKey((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label={showAgnesKey ? 'Hide key' : 'Show key'}
              >
                {showAgnesKey ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>
        </div>

        {/* OpenRouter key (owl-alpha model) */}
        <div className="space-y-3 rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex items-center gap-2 text-sm">
            <KeyRound size={14} /> OpenRouter key (for Owl Alpha)
          </div>
          <p className="text-xs text-muted-foreground">
            Used when the <strong>Owl Alpha</strong> model is selected. Requests go straight from
            your browser to OpenRouter. The built-in demo key works out of the box — paste your
            own here to override (get one at{' '}
            <a
              href="https://openrouter.ai/keys"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary underline"
            >
              openrouter.ai/keys
            </a>
            ).
          </p>
          <div className="space-y-1.5">
            <Label htmlFor="openrouter-key" className="text-xs text-muted-foreground">
              Your OpenRouter API key (stored only in this browser)
            </Label>
            <div className="relative">
              <Input
                id="openrouter-key"
                type={showOpenRouterKey ? 'text' : 'password'}
                value={userOpenRouterKey}
                onChange={(e) => setUserOpenRouterKey(e.target.value)}
                placeholder="sk-or-v1-…"
                className="pr-10 font-mono text-xs"
                autoComplete="off"
                spellCheck={false}
              />
              <button
                type="button"
                onClick={() => setShowOpenRouterKey((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label={showOpenRouterKey ? 'Hide key' : 'Show key'}
              >
                {showOpenRouterKey ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>
        </div>

        {/* System prompt */}
        <div className="space-y-2">
          <Label htmlFor="sys-prompt" className="text-sm">
            System prompt
          </Label>
          <Textarea
            id="sys-prompt"
            value={settings.systemPrompt}
            onChange={(e) => setSettings({ systemPrompt: e.target.value })}
            rows={4}
            className="resize-y text-sm"
            placeholder="Tell the AI how to behave…"
          />
          <p className="text-xs text-muted-foreground">
            You can edit this freely — selecting a persona above will overwrite it.
          </p>
        </div>

        {/* Temperature */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2 text-sm">
              <Thermometer size={14} /> Temperature
            </Label>
            <span className="font-mono text-xs text-muted-foreground">{settings.temperature.toFixed(2)}</span>
          </div>
          <Slider
            value={[settings.temperature]}
            onValueChange={(v) => setSettings({ temperature: v[0] })}
            min={0}
            max={2}
            step={0.05}
          />
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>Focused</span>
            <span>Balanced</span>
            <span>Creative</span>
          </div>
        </div>

        {/* Max tokens */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2 text-sm">
              <Hash size={14} /> Max tokens
            </Label>
            <span className="font-mono text-xs text-muted-foreground">{settings.maxTokens}</span>
          </div>
          <Slider
            value={[settings.maxTokens]}
            onValueChange={(v) => setSettings({ maxTokens: v[0] })}
            min={256}
            max={8192}
            step={256}
          />
        </div>

        {/* Top P */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2 text-sm">
              <Percent size={14} /> Top P
            </Label>
            <span className="font-mono text-xs text-muted-foreground">{settings.topP.toFixed(2)}</span>
          </div>
          <Slider
            value={[settings.topP]}
            onValueChange={(v) => setSettings({ topP: v[0] })}
            min={0.1}
            max={1}
            step={0.05}
          />
        </div>

        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="outline" onClick={reset} className="gap-2">
            <RotateCcw size={14} /> Reset defaults
          </Button>
          <Button onClick={() => onOpenChange(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
