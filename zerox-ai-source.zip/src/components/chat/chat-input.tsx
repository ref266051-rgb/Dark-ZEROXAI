'use client'

import * as React from 'react'
import { ArrowUp, Square, Paperclip, Sparkles, Globe, Server, Search, Brain } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { useChatStore } from '@/lib/store'
import { hasPublicKey, isOpenRouterModel, resolveOpenRouterKey, hasOpenRouterPublicKey } from '@/lib/stream'
import { getChatModel } from '@/lib/types'
import { SLASH_COMMANDS, SlashCommandMenu, type SlashCommand } from './slash-commands'

interface ChatInputProps {
  onSend: (text: string) => void
  onStop: () => void
  isStreaming: boolean
  placeholder?: string
  /** When true, the thinking toggle is forced ON and disabled (thinking mode). */
  forceThinking?: boolean
}

export function ChatInput({ onSend, onStop, isStreaming, placeholder, forceThinking }: ChatInputProps) {
  const [value, setValue] = React.useState('')
  const [slashOpen, setSlashOpen] = React.useState(false)
  const [slashFilter, setSlashFilter] = React.useState('')
  const [slashDismissed, setSlashDismissed] = React.useState(false)
  const taRef = React.useRef<HTMLTextAreaElement>(null)
  const useBrowserMode = useChatStore((s) => s.useBrowserMode)
  const userApiKey = useChatStore((s) => s.userApiKey)
  const selectedChatModelId = useChatStore((s) => s.selectedChatModelId)
  const thinkingModelId = useChatStore((s) => s.thinkingModelId)
  const chatModel = getChatModel(forceThinking ? thinkingModelId : selectedChatModelId)
  const webSearchEnabled = useChatStore((s) => s.webSearchEnabled)
  const setWebSearchEnabled = useChatStore((s) => s.setWebSearchEnabled)
  const thinkingEnabled = useChatStore((s) => s.thinkingEnabled)
  const setThinkingEnabled = useChatStore((s) => s.setThinkingEnabled)
  const userOpenRouterKey = useChatStore((s) => s.userOpenRouterKey)

  // auto-resize
  React.useEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 240) + 'px'
  }, [value])

  // Detect slash command usage while typing.
  // Open the menu when the value starts with "/" and there's no newline yet.
  // Reset the "dismissed" flag once the user types something that doesn't
  // start with "/", so the menu can re-open on the next "/".
  React.useEffect(() => {
    if (!value.startsWith('/') || value.includes('\n')) {
      setSlashOpen(false)
      if (!value.startsWith('/')) setSlashDismissed(false)
      return
    }
    // If user dismissed the menu for this slash, keep it closed until they
    // either pick a command or backspace past the "/".
    if (slashDismissed) {
      setSlashOpen(false)
      return
    }
    setSlashOpen(true)
    setSlashFilter(value)
  }, [value, slashDismissed])

  const applySlashCommand = (cmd: SlashCommand) => {
    // Replace the typed "/query" with a clean placeholder containing the command + nothing,
    // so the user can supply arguments. They type the args then press Enter.
    setValue(`${cmd.id} `)
    setSlashOpen(false)
    setSlashDismissed(false)
    requestAnimationFrame(() => taRef.current?.focus())
  }

  // Resolve a slash command in the input value into a final prompt.
  // Returns null if the value isn't a slash command or if args are missing.
  const resolveSlashCommand = (text: string): { prompt: string; cmd: SlashCommand } | null => {
    const match = text.match(/^(\/\S+)\s+([\s\S]+)$/)
    if (!match) return null
    const [, cmdId, args] = match
    const cmd = SLASH_COMMANDS.find((c) => c.id === cmdId)
    if (!cmd) return null
    const prompt = cmd.buildPrompt(args)
    if (!prompt) return null
    return { prompt, cmd }
  }

  const submit = () => {
    const text = value.trim()
    if (!text || isStreaming) return

    // Try slash command resolution first
    const resolved = resolveSlashCommand(text)
    if (resolved) {
      onSend(resolved.prompt)
      setValue('')
      setSlashOpen(false)
      setSlashDismissed(false)
      requestAnimationFrame(() => {
        if (taRef.current) taRef.current.style.height = 'auto'
      })
      return
    }

    onSend(text)
    setValue('')
    setSlashOpen(false)
    setSlashDismissed(false)
    requestAnimationFrame(() => {
      if (taRef.current) taRef.current.style.height = 'auto'
    })
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Escape' && slashOpen) {
      e.preventDefault()
      setSlashOpen(false)
      setSlashDismissed(true)
      return
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      submit()
    }
  }

  // Determine the connection mode label based on the selected model.
  const isORModel = isOpenRouterModel(chatModel.id)
  const hasKey = isORModel
    ? Boolean(resolveOpenRouterKey(userOpenRouterKey)) || hasOpenRouterPublicKey()
    : Boolean(userApiKey) || hasPublicKey()
  const providerLabel = isORModel ? 'OpenRouter' : 'Groq'
  const modeLabel = useBrowserMode && hasKey ? `Browser → ${providerLabel}` : 'Server proxy'
  const ModeIcon = useBrowserMode && hasKey ? Globe : Server

  return (
    <TooltipProvider delayDuration={300}>
      <div className="border-t border-border/60 bg-background/70 backdrop-blur-md supports-[backdrop-filter]:bg-background/50">
        <div className="mx-auto max-w-3xl px-3 py-3 sm:px-6 sm:py-4">
          <div
            className={cn(
              'relative flex items-end gap-1.5 rounded-2xl border border-border/80 bg-card p-1.5 shadow-sm transition',
              'focus-within:border-primary/50 focus-within:shadow-md focus-within:shadow-primary/5',
            )}
          >
            {/* Slash command menu (above the input) */}
            <SlashCommandMenu
              open={slashOpen}
              filter={slashFilter}
              onPick={applySlashCommand}
              onClose={() => {
                setSlashOpen(false)
                setSlashDismissed(true)
              }}
            />

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 shrink-0 rounded-lg text-muted-foreground"
                  aria-label="Attachments (coming soon)"
                  disabled
                >
                  <Paperclip size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Attachments (coming soon)</TooltipContent>
            </Tooltip>

            <Textarea
              ref={taRef}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={onKeyDown}
              rows={1}
              placeholder={placeholder || 'Message zeroX ai…  (type / for commands)'}
              className="min-h-[40px] max-h-[240px] flex-1 resize-none border-0 bg-transparent px-1 py-2 text-[15px] shadow-none focus-visible:ring-0 focus-visible:ring-offset-0"
            />

            {/* Web search toggle */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setWebSearchEnabled(!webSearchEnabled)}
                  className={cn(
                    'h-8 w-8 shrink-0 rounded-lg transition',
                    webSearchEnabled
                      ? 'bg-primary/10 text-primary hover:bg-primary/15 hover:text-primary'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                  aria-pressed={webSearchEnabled}
                  aria-label="Toggle web search"
                >
                  <Search size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {webSearchEnabled
                  ? 'Web search ON — queries DuckDuckGo + Wikipedia before each reply'
                  : 'Web search OFF — click to enable real-time web context'}
              </TooltipContent>
            </Tooltip>

            {/* Thinking mode toggle */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => !forceThinking && setThinkingEnabled(!thinkingEnabled)}
                  disabled={forceThinking}
                  className={cn(
                    'h-8 w-8 shrink-0 rounded-lg transition',
                    (thinkingEnabled || forceThinking)
                      ? 'bg-violet-500/10 text-violet-600 hover:bg-violet-500/15 hover:text-violet-600 dark:text-violet-400'
                      : 'text-muted-foreground hover:text-foreground',
                    forceThinking && 'cursor-not-allowed opacity-100',
                  )}
                  aria-pressed={thinkingEnabled || forceThinking}
                  aria-label="Toggle thinking mode"
                >
                  <Brain size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {forceThinking
                  ? 'Thinking mode is always ON in this conversation'
                  : thinkingEnabled
                    ? 'Thinking ON — AI shows its reasoning in a collapsible bubble before answering'
                    : 'Thinking OFF — click to enable chain-of-thought reasoning'}
              </TooltipContent>
            </Tooltip>

            {isStreaming ? (
              <Button
                size="icon"
                onClick={onStop}
                className="h-8 w-8 shrink-0 rounded-lg"
                variant="destructive"
                aria-label="Stop generating"
              >
                <Square size={14} className="fill-current" />
              </Button>
            ) : (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="icon"
                    onClick={submit}
                    disabled={!value.trim()}
                    className="btn-glow h-8 w-8 shrink-0 rounded-lg bg-primary"
                    aria-label="Send message"
                  >
                    <ArrowUp size={16} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Send · Enter</TooltipContent>
              </Tooltip>
            )}
          </div>

          <div className="mt-2 flex items-center justify-between px-1 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <Sparkles size={11} className="text-primary" /> {chatModel.name} · {providerLabel}
              <span className="mx-1 opacity-50">·</span>
              <ModeIcon size={11} /> {modeLabel}
              {webSearchEnabled && (
                <>
                  <span className="mx-1 opacity-50">·</span>
                  <Search size={11} className="text-primary" /> Web search
                </>
              )}
              {(thinkingEnabled || forceThinking) && (
                <>
                  <span className="mx-1 opacity-50">·</span>
                  <Brain size={11} className="text-violet-600 dark:text-violet-400" /> Thinking
                </>
              )}
            </span>
            <span className="hidden sm:inline">
              <kbd className="rounded border border-border bg-muted px-1 py-0.5 font-mono">/</kbd>{' '}
              commands ·{' '}
              <kbd className="rounded border border-border bg-muted px-1 py-0.5 font-mono">Enter</kbd>{' '}
              to send ·{' '}
              <kbd className="rounded border border-border bg-muted px-1 py-0.5 font-mono">
                Shift+Enter
              </kbd>{' '}
              new line
            </span>
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}
