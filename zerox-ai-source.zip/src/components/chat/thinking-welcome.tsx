'use client'

import * as React from 'react'
import { ArrowRight, Brain, Sparkles, Zap, Clock, Lightbulb } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ThinkingWelcomeProps {
  onPick: (prompt: string) => void
}

const THINKING_PROMPTS: { title: string; subtitle: string; prompt: string; icon: typeof Brain }[] = [
  {
    title: 'Solve a math puzzle',
    subtitle: 'Step-by-step reasoning',
    prompt: 'A farmer has 100 meters of fence to enclose a rectangular field. What dimensions give the maximum area? Walk me through your reasoning.',
    icon: Lightbulb,
  },
  {
    title: 'Weigh a decision',
    subtitle: 'Pros, cons, trade-offs',
    prompt: 'I have a job offer with 30% higher salary but worse work-life balance. Should I take it? Think through the trade-offs carefully.',
    icon: Sparkles,
  },
  {
    title: 'Debug reasoning',
    subtitle: 'Find the logical flaw',
    prompt: 'Someone argues: "All birds can fly. Penguins are birds. Therefore penguins can fly." Where exactly does this argument go wrong? Think step by step.',
    icon: Zap,
  },
  {
    title: 'Plan strategically',
    subtitle: 'Multi-step planning',
    prompt: 'I want to learn Rust in 3 months while working full-time. Design a realistic study plan that I can actually stick to. Think through the constraints first.',
    icon: Clock,
  },
  {
    title: 'Explain a paradox',
    subtitle: 'Work through the logic',
    prompt: 'Explain the Ship of Theseus paradox. If every plank of a ship is replaced over time, is it still the same ship? Reason through both sides.',
    icon: Brain,
  },
  {
    title: 'Estimate unknown',
    subtitle: 'Fermi problem reasoning',
    prompt: 'How many piano tuners are there in Jakarta? Think through this Fermi estimate step by step, showing your reasoning at each stage.',
    icon: Lightbulb,
  },
]

export function ThinkingWelcome({ onPick }: ThinkingWelcomeProps) {
  return (
    <div className="flex min-h-full flex-col items-center justify-center px-4 py-10 sm:py-16">
      {/* Big hero logo */}
      <div className="relative mb-6">
        <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-violet-400/30 to-fuchsia-500/20 blur-2xl" />
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-violet-500 to-fuchsia-600 shadow-lg shadow-violet-500/25">
          <Brain size={36} className="text-white" strokeWidth={2.2} />
        </div>
      </div>

      {/* Hero headline */}
      <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
        Think with{' '}
        <span className="bg-gradient-to-r from-violet-500 to-fuchsia-500 bg-clip-text text-transparent">
          zeroX ai
        </span>
      </h1>
      <p className="mt-3 max-w-lg text-center text-base text-muted-foreground sm:text-lg">
        Watch the AI reason through complex problems out loud — real chain-of-thought, streamed
        live before the answer.
      </p>

      {/* Feature pills */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11px]">
        <span className="inline-flex items-center gap-1 rounded-full bg-violet-500/10 px-2.5 py-1 font-medium text-violet-600 dark:text-violet-400">
          <Zap size={10} /> Native reasoning
        </span>
        <span className="inline-flex items-center gap-1 rounded-full bg-fuchsia-500/10 px-2.5 py-1 font-medium text-fuchsia-600 dark:text-fuchsia-400">
          <Brain size={10} /> Live thought stream
        </span>
        <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-1 font-medium text-primary">
          <Sparkles size={10} /> Powered by Nemotron & LFM
        </span>
      </div>

      {/* Prompt cards */}
      <div className="mt-10 grid w-full max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
        {THINKING_PROMPTS.map((p) => {
          const Icon = p.icon
          return (
            <button
              key={p.title}
              onClick={() => onPick(p.prompt)}
              className={cn(
                'group relative overflow-hidden rounded-xl border border-border bg-card p-4 text-left transition-all',
                'hover:-translate-y-0.5 hover:border-violet-400/40 hover:shadow-md hover:shadow-violet-500/5',
              )}
            >
              <div className="mb-1.5 flex items-center gap-2.5">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-violet-500/10 text-violet-600 transition-colors group-hover:bg-violet-500/15 dark:text-violet-400">
                  <Icon size={16} strokeWidth={2} />
                </span>
                <span className="font-medium text-foreground">{p.title}</span>
                <ArrowRight
                  size={14}
                  className="ml-auto text-muted-foreground opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100"
                />
              </div>
              <p className="pl-[42px] text-sm text-muted-foreground">{p.subtitle}</p>
            </button>
          )
        })}
      </div>

      {/* Footer tip */}
      <div className="mt-10 flex flex-col items-center gap-1.5 text-center">
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <Sparkles size={12} className="text-violet-500" />
          The AI will think out loud before answering — watch the reasoning unfold live.
        </span>
        <span className="text-[11px] text-muted-foreground/70">
          Powered by NVIDIA Nemotron Nano 9B & LiquidAI LFM 2.5 (free, native reasoning) via OpenRouter.
          Switch between them using the model picker in the header.
        </span>
      </div>
    </div>
  )
}
