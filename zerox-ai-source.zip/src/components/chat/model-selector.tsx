'use client'

import * as React from 'react'
import { Cpu, ChevronDown, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { useChatStore } from '@/lib/store'
import { CHAT_MODELS, getChatModel } from '@/lib/types'

interface ModelSelectorProps {
  className?: string
}

/**
 * Model picker dropdown. Currently only one chat model is registered
 * (Llama 3.1 8B Instant) but the dropdown is kept so adding more models
 * in the future is a one-line change in CHAT_MODELS.
 */
export function ModelSelector({ className }: ModelSelectorProps) {
  const selectedId = useChatStore((s) => s.selectedChatModelId)
  const setSelected = useChatStore((s) => s.setSelectedChatModelId)
  const setThinkingEnabled = useChatStore((s) => s.setThinkingEnabled)
  const current = getChatModel(selectedId)

  const handleSelect = (id: string) => {
    setSelected(id)
    // Auto-enable thinking mode when the user picks a native-reasoning model
    // (so they immediately see the live thinking bubble by default).
    const m = CHAT_MODELS.find((c) => c.id === id)
    if (m?.supportsNativeReasoning) {
      setThinkingEnabled(true)
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn(
            'h-7 gap-1.5 rounded-full border-border/60 bg-card/60 px-2.5 text-[11px] font-medium',
            className,
          )}
          aria-label="Select chat model"
        >
          <Cpu size={12} />
          <span className="max-w-[100px] truncate sm:max-w-[140px]">{current.name}</span>
          <ChevronDown size={11} className="opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72">
        <div className="px-2 py-1.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
          Chat models · Groq
        </div>
        {CHAT_MODELS.map((m) => {
          const active = m.id === selectedId
          return (
            <DropdownMenuItem
              key={m.id}
              onClick={() => handleSelect(m.id)}
              className="flex flex-col items-start gap-1 py-2"
            >
              <div className="flex w-full items-center gap-2">
                <Cpu size={13} className="text-primary" />
                <span className="text-[13px] font-medium">{m.name}</span>
                {m.badge && (
                  <Badge variant="secondary" className="ml-auto bg-primary/10 text-[10px] text-primary">
                    {m.badge}
                  </Badge>
                )}
                {active && <Check size={13} className="ml-1 text-primary" />}
              </div>
              <p className="text-[11px] leading-relaxed text-muted-foreground">{m.description}</p>
              <p className="font-mono text-[10px] text-muted-foreground/70">{m.id}</p>
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
