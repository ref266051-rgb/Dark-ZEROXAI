'use client'

import * as React from 'react'
import { Search, ExternalLink, ChevronDown, ChevronUp, Globe } from 'lucide-react'
import type { SearchContext } from '@/lib/types'
import { cn } from '@/lib/utils'

interface SearchContextCardProps {
  context: SearchContext
  /** if true, render a slimmed-down "searching…" version */
  searching?: boolean
}

export function SearchContextCard({ context, searching }: SearchContextCardProps) {
  const [expanded, setExpanded] = React.useState(false)

  if (searching) {
    return (
      <div className="mb-3 rounded-xl border border-primary/30 bg-primary/5 px-3 py-2.5 text-xs">
        <div className="flex items-center gap-2 text-primary">
          <Search size={13} className="animate-pulse" />
          <span className="font-medium">Searching the web</span>
          <span className="text-muted-foreground">— looking up “{context.query}”…</span>
        </div>
      </div>
    )
  }

  const visibleResults = expanded ? context.results : context.results.slice(0, 3)
  const hiddenCount = context.results.length - visibleResults.length

  return (
    <div className="mb-3 overflow-hidden rounded-xl border border-primary/30 bg-primary/5 text-xs">
      <div className="flex items-center gap-2 border-b border-primary/20 bg-primary/10 px-3 py-2">
        <Search size={13} className="text-primary" />
        <span className="font-semibold text-primary">Web search results</span>
        <span className="text-muted-foreground">— {context.results.length} source{context.results.length === 1 ? '' : 's'} for “{context.query}”</span>
      </div>

      {context.instantAnswer && (
        <div className="border-b border-primary/15 px-3 py-2">
          <div className="mb-0.5 flex items-center gap-1 text-[10px] font-medium uppercase tracking-wide text-primary/80">
            <Globe size={10} /> DuckDuckGo Instant Answer
          </div>
          <p className="text-foreground/90">{context.instantAnswer}</p>
        </div>
      )}

      <ul className="divide-y divide-primary/10">
        {visibleResults.map((r, i) => (
          <li key={i} className="px-3 py-2">
            <a
              href={r.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-start gap-2"
            >
              <span className="mt-0.5 inline-flex h-5 min-w-[1.25rem] items-center justify-center rounded bg-primary/15 px-1 text-[10px] font-semibold text-primary">
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span className="truncate font-medium text-foreground group-hover:underline">
                    {r.title}
                  </span>
                  <ExternalLink
                    size={10}
                    className="shrink-0 text-muted-foreground opacity-0 transition group-hover:opacity-100"
                  />
                </div>
                <p className="truncate text-[10px] text-muted-foreground">{r.url}</p>
                <p className="mt-0.5 line-clamp-2 text-foreground/70">{r.snippet}</p>
                <span className="mt-0.5 inline-block rounded-full bg-muted px-1.5 py-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
                  {r.source}
                </span>
              </div>
            </a>
          </li>
        ))}
      </ul>

      {context.results.length > 3 && (
        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex w-full items-center justify-center gap-1 border-t border-primary/15 bg-primary/5 py-1.5 text-[11px] font-medium text-primary transition hover:bg-primary/10"
        >
          {expanded ? (
            <>
              <ChevronUp size={12} /> Show less
            </>
          ) : (
            <>
              <ChevronDown size={12} /> Show {hiddenCount} more
            </>
          )}
        </button>
      )}
    </div>
  )
}
